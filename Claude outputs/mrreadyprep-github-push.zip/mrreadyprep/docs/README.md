# 📊 MRReadyPrep - SEO Monitoring System

Complete production-ready SEO monitoring solution for TOEFL preparation platform with Google Search Console API, keyword ranking tracking, and backlink monitoring.

## ✨ Features

### Core Features
- **Google Search Console Integration** - Real-time search performance data
- **Keyword Ranking Tracking** - Daily tracking with position change detection
- **Backlink Monitoring** - Ahrefs API integration with domain authority scoring
- **Alert System** - Automatic notifications for ranking drops and new backlinks
- **Monthly Reports** - Comprehensive SEO reports with email distribution
- **SEO Dashboard** - Real-time metrics and interactive visualizations

### Technical Features
- **FastAPI Backend** - High-performance async Python API
- **React Frontend** - Modern React 19 dashboard component
- **PostgreSQL Database** - Production-grade data storage
- **Docker Support** - Easy containerization and deployment
- **Cron Jobs** - Automated daily syncing and reporting
- **CORS-enabled** - Frontend-backend integration ready

---

## 🚀 Quick Start

### Option 1: Docker (Recommended)
```bash
# Clone and navigate
git clone https://github.com/mehmetdisbudak/mrreadyprep.git
cd mrreadyprep/backend/seo_monitoring

# Start all services
docker-compose up -d

# Access
# Backend API: http://localhost:8000
# pgAdmin: http://localhost:5050
# Frontend: http://localhost:3000
```

### Option 2: Manual Setup
```bash
# Backend
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# Update .env with your credentials
python seo_monitoring.py

# Frontend (new terminal)
cd frontend
npm install
npm start
```

See [HIZLI_BASLA.md](./HIZLI_BASLA.md) for detailed quick start guide.

---

## 📋 API Endpoints

All endpoints return JSON responses. Base URL: `http://localhost:8000`

### Keywords
```bash
GET /api/seo/keywords?days=30&limit=20
```
Returns top keywords with rankings, impressions, and click data.

### Performance
```bash
GET /api/seo/performance?days=30
```
Returns monthly metrics: impressions, clicks, average position, CTR, and daily trends.

### Backlinks
```bash
GET /api/seo/backlinks?limit=50
```
Returns backlink data with domain authority and page authority scores.

### Alerts
```bash
GET /api/seo/alerts?limit=20&unread_only=false
POST /api/seo/alerts/{alert_id}/read
```
Manage system alerts for ranking drops and new backlinks.

### Monthly Report
```bash
GET /api/seo/report?month=2026-09
```
Returns comprehensive monthly SEO report.

### Manual Sync
```bash
POST /api/seo/sync
```
Manually trigger SEO data synchronization.

### Health Check
```bash
GET /health
```
System health status.

---

## 🗂️ Project Structure

```
backend/seo_monitoring/
├── seo_monitoring.py       # Main API + Database models
├── seo_cron.py            # Scheduled jobs
├── requirements.txt        # Python dependencies
├── Dockerfile             # Docker image
├── docker-compose.yml     # Development setup
├── render.yaml            # Production deployment
└── .env.example          # Configuration template

frontend/src/components/
├── SEODashboard.jsx       # Main dashboard component
└── ...

docs/
├── KURULUM_REHBERI.md     # Turkish setup guide
├── PROJE_YAPISI.md        # Architecture & database schema
├── HIZLI_BASLA.md         # 5-minute quick start
├── RENDER_KURULUM.md      # Production deployment guide
└── TESLIM_KONTROL_LISTESI.md # Delivery checklist
```

---

## 🔧 Configuration

### Environment Variables

Create `.env` file in backend folder:

```env
# Database
DATABASE_URL=postgresql://user:pass@localhost:5432/mrreadyprep_seo

# Google Search Console
GSC_PROPERTY_URL=https://mrreadyprep.com/
GSC_CREDENTIALS_FILE=credentials.json

# Ahrefs
AHREFS_API_KEY=your_api_key

# Email Reports
SMTP_SERVER=smtp.gmail.com
SMTP_USER=your_email@gmail.com
SMTP_PASSWORD=your_app_password
EMAIL_TO=admin@mrreadyprep.com

# Frontend API URL
REACT_APP_API_URL=http://localhost:8000
```

See [.env.example](.env.example) for all available options.

---

## 📅 Scheduled Jobs

The cron worker automatically runs:

| Time | Task | Frequency |
|------|------|-----------|
| 02:00 AM | Sync keyword rankings | Daily |
| 03:00 AM | Sync backlinks | Weekly (Sunday) |
| 04:00 AM | Generate monthly report | Monthly (1st) |
| 05:00 AM | Cleanup old data | Weekly (Monday) |

All times in UTC. Adjust for your timezone.

---

## 🗄️ Database Schema

### Tables
- **seo_keywords** - Keyword rankings history
- **seo_backlinks** - Backlink data and tracking
- **seo_alerts** - System alerts and notifications
- **seo_reports** - Monthly SEO reports

Automatic migrations on first run. PostgreSQL in production, SQLite for development.

---

## 🎨 Frontend Dashboard

The SEO Dashboard includes:
- **KPI Cards** - Impressions, Clicks, Position, CTR
- **Performance Charts** - Trend graphs (placeholder for data visualization)
- **Keywords Table** - Top keywords with rankings
- **Backlinks Panel** - Backlink quality and DA scores
- **Alert Management** - Track and manage system alerts
- **Navigation Sidebar** - Tab-based interface

All styled with inline CSS (no Tailwind). Fully responsive.

---

## 🚀 Deployment

### Render (Recommended)

```bash
# 1. Push to GitHub
git push origin main

# 2. Create Render services using render.yaml
# 3. Set environment variables
# 4. Deploy automatically on push
```

See [RENDER_KURULUM.md](./RENDER_KURULUM.md) for detailed deployment guide.

### Vercel (Frontend)

```bash
# 1. Connect GitHub repo to Vercel
# 2. Set REACT_APP_API_URL environment variable
# 3. Deploy automatically on push
```

### Docker

```bash
docker build -t mrreadyprep-seo:latest .
docker run -p 8000:8000 mrreadyprep-seo:latest
```

---

## 📚 Documentation

- **[KURULUM_REHBERI.md](./KURULUM_REHBERI.md)** - Complete Turkish setup guide
- **[PROJE_YAPISI.md](./PROJE_YAPISI.md)** - Architecture and technical details
- **[HIZLI_BASLA.md](./HIZLI_BASLA.md)** - Quick 5-minute start
- **[RENDER_KURULUM.md](./RENDER_KURULUM.md)** - Production deployment steps
- **[TESLIM_KONTROL_LISTESI.md](./TESLIM_KONTROL_LISTESI.md)** - Implementation checklist

---

## 🆘 Troubleshooting

### Common Issues

**Backend fails to start:**
```bash
# Check logs
tail -f seo_monitoring.log

# Verify database connection
psql $DATABASE_URL

# Install dependencies
pip install -r requirements.txt
```

**Frontend shows "Connection refused":**
```bash
# Update .env
REACT_APP_API_URL=http://localhost:8000

# Restart frontend
npm start
```

**Google API errors:**
```bash
# Verify credentials.json exists
ls -la credentials.json

# Check OAuth token
rm -f token.json
# Re-run, browser will open for re-authorization
```

**CORS errors:**
- Check if backend is running
- Verify REACT_APP_API_URL in frontend .env
- Restart both services

See detailed troubleshooting in documentation files.

---

## 🧪 Testing

```bash
# API health check
curl http://localhost:8000/health

# Fetch keywords
curl http://localhost:8000/api/seo/keywords

# Trigger sync
curl -X POST http://localhost:8000/api/seo/sync

# Manual database query
sqlite3 seo_monitoring.db "SELECT COUNT(*) FROM seo_keywords;"
```

---

## 🔐 Security

- **Credentials** - Store in environment variables, never commit
- **API Keys** - Use secrets manager for production
- **Database** - Use strong passwords, enable SSL
- **Authentication** - OAuth 2.0 for Google APIs
- **HTTPS** - Automatic with Render and Vercel

```bash
# Add to .gitignore
credentials.json
token.json
.env
seo_monitoring.db
```

---

## 📊 Performance

- **Response Time** - <100ms for most endpoints
- **Database** - Optimized indexes on keyword and date queries
- **Frontend** - Real-time updates every 5 minutes
- **Cron Jobs** - Non-blocking background processing

See [RENDER_KURULUM.md](./RENDER_KURULUM.md) for optimization tips.

---

## 🤝 Contributing

1. Fork the repository
2. Create feature branch: `git checkout -b feature/name`
3. Commit changes: `git commit -m "Add feature"`
4. Push to branch: `git push origin feature/name`
5. Open Pull Request

---

## 📝 License

This project is part of MRReadyPrep. See LICENSE file for details.

---

## 📞 Support

- **Email:** mehmet.disbudak03@hotmail.com
- **GitHub:** github.com/mehmetdisbudak/mrreadyprep
- **Issues:** github.com/mehmetdisbudak/mrreadyprep/issues

---

## 🎯 Roadmap

- [ ] Advanced analytics and predictions
- [ ] Competitor tracking
- [ ] Multi-domain support
- [ ] Team collaboration features
- [ ] Export to PDF/Excel
- [ ] Mobile app
- [ ] Slack integration
- [ ] Custom alerts and rules

---

## 📈 Stats

- **Backend:** 850+ lines of Python
- **Frontend:** 850+ lines of React
- **Documentation:** 2000+ lines of Turkish
- **Endpoints:** 8 REST API endpoints
- **Database Tables:** 4 production tables
- **Supported:** Python 3.8+, Node.js 16+

---

## ✅ Checklist

Before going live:
- [ ] All environment variables configured
- [ ] Google Search Console verified
- [ ] Ahrefs API key added
- [ ] Email configuration set
- [ ] Database created and migrated
- [ ] Backend tested locally
- [ ] Frontend tested locally
- [ ] Docker build successful
- [ ] Render services deployed
- [ ] Monitoring and alerts configured

---

## 🎉 Quick Links

- [Quick Start (Turkish)](./HIZLI_BASLA.md)
- [Setup Guide (Turkish)](./KURULUM_REHBERI.md)
- [Architecture Details (Turkish)](./PROJE_YAPISI.md)
- [Production Deploy (Turkish)](./RENDER_KURULUM.md)
- [Live Dashboard](#) (After deployment)
- [API Docs](#) (http://localhost:8000/docs)

---

**Built with ❤️ for MRReadyPrep**

Last Updated: 2026-09-27  
Version: 1.0.0  
Status: Production Ready ✅
