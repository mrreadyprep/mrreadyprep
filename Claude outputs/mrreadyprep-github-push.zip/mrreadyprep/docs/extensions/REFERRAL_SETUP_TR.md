# MRReadyPrep Referral Program - Kurulum Rehberi (Türkçe)

**Versiyon:** 1.0 | **Tarihi:** 26 Eylül 2026 | **Durum:** Production-Ready

## İçindekiler
1. [Genel Bakış](#genel-bakış)
2. [Sistem Gereksinimleri](#sistem-gereksinimleri)
3. [Veritabanı Kurulumu](#veritabanı-kurulumu)
4. [Backend Entegrasyonu](#backend-entegrasyonu)
5. [Frontend Entegrasyonu](#frontend-entegrasyonu)
6. [API Endpoints](#api-endpoints)
7. [Email Konfigürasyonu](#email-konfigürasyonu)
8. [Fraud Detection](#fraud-detection)
9. [Test Prosedürü](#test-prosedürü)
10. [Deployment](#deployment)
11. [Monitoring & Analytics](#monitoring--analytics)

---

## Genel Bakış

**Referral Program (Extension 6)** - MRReadyPrep'in viral growth loop sistemidir.

**Temel Özellikler:**
- 🎁 $5 credit her başarılı referral için
- 🏆 Referrer leaderboard
- 💰 Credit balance & payout sistemi
- 📊 Real-time analytics
- 🔒 Fraud detection
- 📧 Otomatik email notifications

**Ekonomik Model:**
```
User A → Referral Link → User B (signup)
         ↓
    User A: +$5 credit
    User B: -50% first month
```

---

## Sistem Gereksinimleri

### Backend
- Python 3.10+
- FastAPI 0.100+
- SQLAlchemy 2.0+
- PostgreSQL 14+
- Resend (email API)
- Stripe (payout sistemi - opsiyonel)

### Frontend
- React 19
- Vite 6
- lucide-react (icons)
- TypeScript (opsiyonel)

### Dış Servisler
- Resend API (email)
- Stripe (payouts)
- Render (hosting)
- Vercel (frontend)

---

## Veritabanı Kurulumu

### Adım 1: Migration Dosyasını Çalıştır

```bash
# PostgreSQL'e bağlan
psql -U postgres -d mrreadyprep

# Migration dosyasını çalıştır
\i migrations/001_create_referral_tables.sql
```

**Oluşturulan Tablolar:**
- `referrals` - Referral tracking
- `referral_credits` - Credit balance
- `referral_transactions` - Audit trail
- `referral_payouts` - Payout requests
- `referral_analytics` - Daily stats

### Adım 2: Veritabanı Doğrulaması

```sql
-- Tabloları kontrol et
\dt referral*

-- Indexes kontrol et
\di referral*

-- Sample veri ekle (test için)
INSERT INTO users (email, name, referral_code) 
VALUES ('test@example.com', 'Test User', 'TEST1234');
```

---

## Backend Entegrasyonu

### Adım 1: Dependencies Kur

```bash
cd backend

# requirements.txt'e ekle:
fastapi==0.100.0
sqlalchemy==2.0.21
python-qrcode==7.4.2
resend==3.0.0
stripe==7.0.0

pip install -r requirements.txt
```

### Adım 2: Models ve Routes Entegre Et

**`backend/models.py`:**
```bash
# Yeni models ekle
# Dosya: models.py satırı 1-250 (all referral models)
```

**`backend/main.py`:**
```python
# Referral routes'ı import et
from backend.referral_routes import router as referral_router

# Main app'a ekle
app.include_router(referral_router)

# CORS ayarları (var olan ayarların altına ekle)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["https://mrreadyprep.com", "http://localhost:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
```

### Adım 3: Environment Variables

**`.env` (Render dashboard'da):**
```bash
# Referral Configuration
REFERRAL_REWARD=5.00
REFERRAL_DISCOUNT_PERCENT=50
REFERRAL_DISCOUNT_DURATION_DAYS=30
MIN_PAYOUT_AMOUNT=20.00
REFERRAL_BASE_URL=https://mrreadyprep.com

# Email Configuration
RESEND_API_KEY=re_xxxxxxxxxxxxx  # Resend'den al

# Stripe (Payout için - opsiyonel)
STRIPE_SECRET_KEY=sk_live_xxxxxxxxxxxxx
STRIPE_PUBLIC_KEY=pk_live_xxxxxxxxxxxxx

# Webhook Security
REFERRAL_WEBHOOK_SECRET=your-secret-key-here

# Database
DATABASE_URL=postgresql://user:password@host/mrreadyprep
```

### Adım 4: Test Backend Endpoints

```bash
# JWT token al (existing user)
curl -X POST http://localhost:8000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"user@example.com","password":"password"}'

# Referral link oluştur
curl -X POST http://localhost:8000/api/referrals/generate-link \
  -H "Authorization: Bearer YOUR_TOKEN"

# Stats al
curl -X GET http://localhost:8000/api/referrals/stats \
  -H "Authorization: Bearer YOUR_TOKEN"

# Leaderboard al
curl -X GET http://localhost:8000/api/referrals/leaderboard?limit=10 \
  -H "Authorization: Bearer YOUR_TOKEN"
```

---

## Frontend Entegrasyonu

### Adım 1: React Components Ekle

**`src/components/referral/`** klasörü oluştur ve dosyaları ekle:
- `ReferralDashboard.jsx`
- `ReferralShareModal.jsx`
- `ReferralLeaderboard.jsx`
- `ReferralHistory.jsx`
- `RewardsTracker.jsx`

### Adım 2: App.jsx'e Route Ekle

```jsx
// src/App.jsx
import ReferralDashboard from './components/referral/ReferralDashboard';

function App() {
  return (
    <Routes>
      {/* ... existing routes ... */}
      <Route path="/dashboard/referrals" element={<ReferralDashboard />} />
    </Routes>
  );
}
```

### Adım 3: Signup Sayfasında Referral Validation

**`src/pages/Signup.jsx`:**
```jsx
import { useState } from 'react';

export default function Signup() {
  const [referralCode, setReferralCode] = useState('');
  const [referralValid, setReferralValid] = useState(false);

  const validateReferral = async () => {
    const res = await fetch(`/api/referrals/validate?code=${referralCode}`);
    const data = await res.json();
    
    if (data.is_valid) {
      setReferralValid(true);
      // Apply discount visually
      // Store referral_code in signup form
    }
  };

  return (
    <div>
      {/* ... existing signup form ... */}
      
      {/* Referral section */}
      <div className="referral-section">
        <input
          type="text"
          placeholder="Referral Code (Optional)"
          value={referralCode}
          onChange={(e) => setReferralCode(e.target.value)}
        />
        <button onClick={validateReferral}>Validate Code</button>
        
        {referralValid && (
          <p style={{color: '#10b981'}}>✓ 50% off applied!</p>
        )}
      </div>
    </div>
  );
}
```

### Adım 4: Navigation'a Link Ekle

**`src/components/Navigation.jsx`:**
```jsx
// Premium users için referral dashboard link
<NavLink to="/dashboard/referrals">
  💰 Earn Rewards
</NavLink>
```

---

## API Endpoints

### Authentication Gerekli (Bearer Token)

#### Referral Link Oluştur
```
POST /api/referrals/generate-link
Response:
{
  "referral_code": "ABC12345",
  "referral_url": "https://mrreadyprep.com?ref=ABC12345",
  "qr_code_url": "data:image/png;base64,...",
  "share_text": "Join MRReadyPrep..."
}
```

#### User Stats
```
GET /api/referrals/stats
Response:
{
  "total_referrals": 5,
  "converted_referrals": 3,
  "pending_referrals": 2,
  "total_earnings": 15.00,
  "available_credit": 15.00,
  "reserved_amount": 0.00,
  "conversion_rate": 60.0,
  "top_referrer_rank": 12,
  "referral_code": "ABC12345"
}
```

#### Referral History
```
GET /api/referrals/history?page=1&per_page=20&status_filter=converted
Response:
{
  "referrals": [
    {
      "id": "uuid",
      "referred_user_email": "friend@example.com",
      "status": "converted",
      "reward_amount": 5.00,
      "created_at": "2026-09-26T10:00:00Z",
      "conversion_date": "2026-09-26T10:30:00Z",
      "is_paid": false
    }
  ],
  "total_count": 5,
  "page": 1,
  "per_page": 20,
  "total_pages": 1
}
```

#### Leaderboard
```
GET /api/referrals/leaderboard?limit=10
Response:
{
  "entries": [
    {
      "rank": 1,
      "user_id": "uuid",
      "user_name": "Top Referrer",
      "user_avatar": "https://...",
      "total_referrals": 15,
      "total_earnings": 75.00,
      "conversion_rate": 100.0
    }
  ],
  "user_rank": 12,
  "user_earnings": 10.00,
  "generated_at": "2026-09-26T10:00:00Z"
}
```

#### Credit Balance
```
GET /api/referrals/balance
Response:
{
  "balance": 10.00,
  "reserved_amount": 5.00,
  "total_earned": 15.00,
  "total_redeemed": 0.00,
  "last_updated": "2026-09-26T10:00:00Z"
}
```

#### Payout Request
```
POST /api/referrals/request-payout
Body:
{
  "amount": 50.00,
  "payout_method": "stripe"  // stripe|paypal|bank_transfer|credit
}
Response:
{
  "id": "uuid",
  "amount": 50.00,
  "status": "pending",
  "payout_method": "stripe",
  "requested_at": "2026-09-26T10:00:00Z",
  "processed_at": null,
  "completed_at": null
}
```

### Public Endpoints (Authentication Yok)

#### Referral Validation
```
POST /api/referrals/validate?code=ABC12345
Response:
{
  "is_valid": true,
  "is_already_used": false,
  "referrer_name": "John Doe",
  "referrer_avatar": "https://...",
  "discount_amount": 50,
  "message": "Valid referral code!"
}
```

---

## Email Konfigürasyonu

### Adım 1: Resend Setup

```bash
# Resend API key al: https://resend.com/api-keys

# .env'ye ekle
RESEND_API_KEY=re_xxxxxxxxxxxxx
```

### Adım 2: Email Templates Test

```python
# backend/emails/test_emails.py
from referral_templates import ReferralEmailTemplates, send_referral_invitation

# Test invitation
send_referral_invitation(
    referrer={"name": "John", "email": "john@example.com"},
    referred_email="friend@example.com",
    referral_code="TEST1234"
)

# Test success
send_referral_success_email(
    referrer_email="john@example.com",
    referred_name="Friend",
    referred_email="friend@example.com",
    reward_amount=5.0
)
```

### Adım 3: Email Webhook (Opsiyonel)

Resend'den bounce/complaint handling için webhook setup yapabilirsin.

---

## Fraud Detection

### Implemented Checks

1. **Rapid Conversions**: 5+ referrals/saat
2. **Duplicate IPs**: 3+ referrals same IP
3. **Suspicious Patterns**: VM/proxy detection
4. **Email Validation**: Disposable email checks

### Configuration

```python
# backend/referral_routes.py

# Thresholds
MAX_REFERRALS_PER_DAY = 100
RAPID_CONVERSION_THRESHOLD = 5  # per hour
DUPLICATE_IP_THRESHOLD = 3
```

### Monitoring

```sql
-- Suspicious referrals kontrol et
SELECT * FROM referrals 
WHERE status = 'flagged' 
ORDER BY created_at DESC;

-- IP patterns
SELECT utm_source, COUNT(*) as count
FROM referrals
GROUP BY utm_source
HAVING COUNT(*) > 3;
```

---

## Test Prosedürü

### Otomatik Test Suite

```bash
cd backend

# Test install
pip install pytest pytest-asyncio httpx

# Tests çalıştır
pytest tests/test_referral_routes.py -v

# Coverage report
pytest --cov=backend.referral_routes tests/
```

### Manual Test Flow

```
1. User A (Referrer) açılır
   └─ Dashboard/Referrals → Generate Link
   └─ Copy referral code (e.g., ABC12345)

2. User B (Referred) signup olur
   └─ Signup page → "Referral Code?" input
   └─ ABC12345 gir
   └─ "✓ 50% off applied" görun

3. User B Premium plan buy et
   └─ Discount applied check et
   └─ Payment process complete

4. User A referrals dashboard kontrol et
   └─ Total referrals: 1
   └─ Status: Converted
   └─ Earnings: $5.00 added

5. User A leaderboard de görün
6. Email notifications kontrol et (inbox)
```

### Staging Environment Test

```bash
# Staging URL
https://staging-mrreadyprep.vercel.app

# Test accounts (email-based)
- Referrer: test-referrer@mrreadyprep.dev
- Referred: test-referred@mrreadyprep.dev

# Check database
psql -U postgres -d mrreadyprep_staging
SELECT * FROM referrals LIMIT 5;
```

---

## Deployment

### Backend Deployment (Render)

**1. Code Push:**
```bash
cd backend
git add .
git commit -m "feat: Add referral program (Extension 6)"
git push origin main
```

**2. Render Environment Variables:**
```
Dashboard → mrreadyprep-api → Environment
Ekle:
- REFERRAL_REWARD=5.00
- REFERRAL_DISCOUNT_PERCENT=50
- RESEND_API_KEY=re_xxxxx
- REFERRAL_WEBHOOK_SECRET=xxxxx
```

**3. Database Migration (Production):**
```bash
# Render shell access
render exec -s mrreadyprep-db psql

\i migrations/001_create_referral_tables.sql
```

**4. Redeploy:**
```
Dashboard → mrreadyprep-api → Manual Deploy
```

### Frontend Deployment (Vercel)

**1. Components ekle ve test et:**
```bash
npm run dev
# http://localhost:3000/dashboard/referrals

npm run build
# Build errors check et
```

**2. Deploy:**
```bash
git push origin main
# Vercel otomatik deploy
# https://mrreadyprep.com/dashboard/referrals
```

### Production Checklist

- [ ] Database migration başarılı
- [ ] Environment variables ayarlandı
- [ ] Email testing passed
- [ ] API endpoints tested
- [ ] Frontend components rendered
- [ ] Stripe webhook configured (payouts için)
- [ ] Monitoring setup (error tracking)
- [ ] Backups configured
- [ ] Analytics event tracking

---

## Monitoring & Analytics

### Real-time Metrics

```bash
# Database queries
SELECT 
  COUNT(*) as total_referrals,
  COUNT(CASE WHEN status='converted' THEN 1 END) as conversions,
  AVG(CAST(status='converted' AS INT)) * 100 as conversion_rate,
  SUM(CAST(reward_amount AS NUMERIC)) as total_distributed
FROM referrals
WHERE created_at > NOW() - INTERVAL '7 days';
```

### Grafana Dashboard (Opsiyonel)

```yaml
Dashboard: Referral Program Metrics
Panels:
  - Daily New Referrals
  - Conversion Rate Trend
  - Top Referrers
  - Total Credits Issued
  - Payout Queue
```

### Email Tracking

Resend dashboard:
- Sent: Ne kadar email gönderildi
- Opened: Open rate %
- Clicked: Click-through rate
- Bounced: Bounce emails

### Key Metrics

```
- Daily Active Referrers: N users
- Weekly Conversion Rate: X%
- Average Referrals per User: Y
- Program ROI: Z%
```

---

## Troubleshooting

### Issue: "Referral API 404"
```
✓ Check: Backend routes include et
✓ Check: CORS ayarları doğru
✓ Check: Token geçerli
```

### Issue: "Email not sending"
```
✓ Check: RESEND_API_KEY set
✓ Check: Email address valid
✓ Check: Resend quota not exceeded
```

### Issue: "QR Code not generating"
```bash
# qrcode kütüphanesi yüklü?
pip install python-qrcode pillow

# Test:
python -c "import qrcode; print('OK')"
```

### Issue: "Database connection error"
```bash
# Connection string doğru?
echo $DATABASE_URL

# PostgreSQL running?
pg_isready -h localhost
```

---

## Sonraki Adımlar

1. **Analytics Integration**: Referral funnels için GA4 events
2. **Automation**: Monthly payout automation (Stripe)
3. **Gamification**: Badges, tiers, milestone rewards
4. **API**: Public referral API for partner integrations
5. **A/B Testing**: Different referral incentives testing

---

## Support

**Questions/Issues?**
- Docs: https://github.com/mrreadyprep/docs
- Email: tech@mrreadyprep.com
- Slack: #engineering channel

---

**Program Live: September 26, 2026** ✅
