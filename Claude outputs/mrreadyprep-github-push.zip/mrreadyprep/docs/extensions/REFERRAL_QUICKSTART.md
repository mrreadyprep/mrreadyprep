# Referral Program - Quick Start (10 Dakika)

🚀 **Extension 6 Production Deployment Guide**

---

## TL;DR

```bash
# 1. Database (2 min)
psql -U postgres -d mrreadyprep < migrations/001_create_referral_tables.sql

# 2. Backend (3 min)
# - Copy models.py & referral_routes.py to backend/
# - pip install python-qrcode resend
# - Add to main.py: app.include_router(referral_router)
# - Set RESEND_API_KEY in Render env

# 3. Frontend (3 min)
# - Copy .jsx files to src/components/referral/
# - Add route: <Route path="/dashboard/referrals" element={<ReferralDashboard />} />
# - Add nav link

# 4. Test (2 min)
# - npm run dev
# - curl /api/referrals/generate-link
# - Manual end-to-end test
```

---

## File Checklist

### Backend Files
```
✓ backend/models.py                    # 250+ lines
✓ backend/referral_routes.py          # 500+ lines
✓ emails/referral_templates.py        # 200+ lines
✓ migrations/001_create_referral_tables.sql
```

### Frontend Files
```
✓ src/components/referral/ReferralDashboard.jsx      # 300 lines
✓ src/components/referral/ReferralShareModal.jsx     # 250 lines
✓ src/components/referral/ReferralLeaderboard.jsx    # 300 lines
✓ src/components/referral/ReferralHistory.jsx        # 350 lines
✓ src/components/referral/RewardsTracker.jsx         # 350 lines
```

### Documentation
```
✓ docs/SETUP_TR.md                    # Full Turkish guide
✓ DEPLOYMENT_CHECKLIST.md             # Phase-by-phase
✓ QUICKSTART.md                       # This file
```

---

## 1️⃣ Database Setup (2 min)

```bash
# Connect to production database
psql -U postgres -d mrreadyprep

# Run migration
\i /path/to/migrations/001_create_referral_tables.sql

# Verify
SELECT COUNT(*) FROM referrals;  -- Should return 0
SELECT COUNT(*) FROM referral_credits;  -- Should return 0
```

**Expected:** 11 tables created with indexes and triggers

---

## 2️⃣ Backend Setup (3 min)

### Step A: Copy Files
```bash
# Add referral models to your existing models.py
# Or create: backend/referral_models.py

# Copy endpoint file
cp referral_routes.py backend/

# Copy email templates
cp emails/referral_templates.py backend/emails/
```

### Step B: Update main.py
```python
# Add import
from backend.referral_routes import router as referral_router

# Include router
app.include_router(referral_router)

# Test
python -m pytest tests/test_referral_routes.py -v
```

### Step C: Environment Variables (Render Dashboard)
```bash
# Go to: Dashboard → mrreadyprep-api → Environment

REFERRAL_REWARD=5.00
REFERRAL_DISCOUNT_PERCENT=50
REFERRAL_DISCOUNT_DURATION_DAYS=30
MIN_PAYOUT_AMOUNT=20.00
REFERRAL_BASE_URL=https://mrreadyprep.com
RESEND_API_KEY=re_xxxxxxxxxxxxx
REFERRAL_WEBHOOK_SECRET=your-secret-key
```

### Step D: Deploy
```bash
git add backend/
git commit -m "feat: Add referral system (Extension 6)"
git push origin main

# Render auto-deploys
# Check: https://dashboard.render.com → mrreadyprep-api
```

---

## 3️⃣ Frontend Setup (3 min)

### Step A: Create Components Folder
```bash
mkdir -p src/components/referral
cd src/components/referral
```

### Step B: Copy React Components
```bash
# Copy all .jsx files
cp ReferralDashboard.jsx .
cp ReferralShareModal.jsx .
cp ReferralLeaderboard.jsx .
cp ReferralHistory.jsx .
cp RewardsTracker.jsx .
```

### Step C: Update App.jsx
```jsx
// src/App.jsx
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import ReferralDashboard from './components/referral/ReferralDashboard';

function App() {
  return (
    <Router>
      <Routes>
        {/* ... existing routes ... */}
        <Route path="/dashboard/referrals" element={<ReferralDashboard />} />
      </Routes>
    </Router>
  );
}
```

### Step D: Add Navigation Link
```jsx
// src/components/Navigation.jsx
<nav>
  {isLoggedIn && (
    <NavLink to="/dashboard/referrals" className="nav-link">
      💰 Earn Rewards
    </NavLink>
  )}
</nav>
```

### Step E: Test Locally
```bash
npm run dev
# Visit: http://localhost:3000/dashboard/referrals
```

### Step F: Deploy
```bash
npm run build
git add src/
git commit -m "feat: Add referral dashboard UI (Extension 6)"
git push origin main

# Vercel auto-deploys
# Check: https://vercel.com → mrreadyprep → Production
```

---

## 4️⃣ Testing (2 min)

### API Test
```bash
# Get token
TOKEN=$(curl -X POST http://localhost:8000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"user@example.com","password":"pass"}' | jq -r '.access_token')

# Generate link
curl http://localhost:8000/api/referrals/generate-link \
  -H "Authorization: Bearer $TOKEN"

# Expected response:
# {
#   "referral_code": "ABC12345",
#   "referral_url": "https://mrreadyprep.com?ref=ABC12345",
#   "qr_code_url": "data:image/png;base64,..."
# }
```

### Frontend Test
```bash
# 1. Open: http://localhost:3000/dashboard/referrals
# 2. Should see:
#    ✓ Header (title + subtitle)
#    ✓ Referral link with copy button
#    ✓ QR code
#    ✓ Share modal button
#    ✓ Stats cards (referrals, earnings, etc.)
#    ✓ Tabs (overview, leaderboard, history, rewards)

# 3. Click "Share with Friends"
#    ✓ Modal opens with social sharing options

# 4. Copy link
#    ✓ "Copied!" message appears
```

### End-to-End Test
```
1. User A: /dashboard/referrals → Copy link
2. User B: Sign up using referral code
3. User B: Pay for Premium (50% discount applied)
4. User A: Check stats (should show 1 conversion)
5. Check email: Both should receive confirmation
```

---

## 📊 Key API Endpoints

```
POST   /api/referrals/generate-link      # Create link
GET    /api/referrals/stats              # Get stats
GET    /api/referrals/leaderboard        # Top referrers
POST   /api/referrals/validate           # Validate code
POST   /api/referrals/claim-credit       # Apply discount
GET    /api/referrals/balance            # Credit balance
POST   /api/referrals/request-payout     # Request payout
```

---

## 🎯 Next Steps

1. **Deployment Done?**
   - [ ] Database migrated
   - [ ] Backend deployed
   - [ ] Frontend deployed
   - [ ] All tests passing

2. **Go-Live Checklist**
   - [ ] Monitor error logs
   - [ ] Track referral conversion rate
   - [ ] Review email deliverability
   - [ ] Process first payouts

3. **Optimization**
   - [ ] Analyze referral sources
   - [ ] A/B test incentive amounts
   - [ ] Optimize email templates
   - [ ] Add gamification (badges, tiers)

---

## 🆘 Quick Troubleshoot

| Problem | Solution |
|---------|----------|
| 404 on /api/referrals | Check referral_router included in main.py |
| "RESEND_API_KEY not found" | Add to Render env vars, not .env file |
| Components not rendering | Check React imports, lucide-react installed |
| Database connection error | Verify DATABASE_URL, psql running |
| QR code blank | `pip install python-qrcode pillow` |

---

## 📞 Support

**Full Guide:** `docs/SETUP_TR.md` (Turkish, 11 sections)
**Detailed Checklist:** `DEPLOYMENT_CHECKLIST.md`
**Email:** tech@mrreadyprep.com

---

**Status: PRODUCTION READY** ✅

Deployment Time: ~30-60 minutes (all phases)
Lines of Code: 3,500+
Components: Backend (3 files) + Frontend (5 components) + Database (1 migration)

**Let's go! 🚀**
