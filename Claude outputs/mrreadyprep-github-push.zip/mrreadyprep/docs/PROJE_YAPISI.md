# MRReadyPrep - SEO Monitoring Proje Yapısı

## 📁 Dizin Ağacı

```
mrreadyprep/
├── backend/
│   ├── seo_monitoring/
│   │   ├── seo_monitoring.py          # Ana API uygulaması
│   │   ├── seo_cron.py                # Cron job scheduler
│   │   ├── requirements.txt           # Python bağımlılıkları
│   │   ├── credentials.json           # Google API kimlik bilgileri (gitignore)
│   │   ├── token.json                 # Google OAuth token (gitignore)
│   │   ├── .env                       # Ortam değişkenleri (gitignore)
│   │   ├── .env.example               # .env şablonu
│   │   ├── Dockerfile                 # Docker yapılandırması
│   │   ├── docker-compose.yml         # Docker Compose (geliştirme)
│   │   ├── seo_monitoring.db          # SQLite database (geliştirme, gitignore)
│   │   └── seo_monitoring.log         # Log dosyası
│   └── ...
│
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── SEODashboard.jsx       # Ana SEO Dashboard bileşeni
│   │   │   └── ...
│   │   ├── pages/
│   │   │   └── ...
│   │   └── App.js
│   ├── .env                           # Frontend ortam değişkenleri (gitignore)
│   ├── .env.example                   # .env şablonu
│   ├── package.json
│   └── ...
│
├── docs/
│   ├── KURULUM_REHBERI.md            # Turkish setup guide
│   ├── PROJE_YAPISI.md               # Bu dosya
│   └── API_DOKUMENTASYONU.md         # API docs
│
├── .gitignore
├── README.md
└── ...
```

---

## 🔧 Backend Yapısı

### seo_monitoring.py

**Modüller:**
1. **Database Models** (SQLAlchemy ORM)
   - `SEOKeyword` - Anahtar kelime sıralamaları
   - `SEOBacklink` - Backlink verileri
   - `SEOAlert` - Sistem uyarıları
   - `SEOReport` - Aylık raporlar

2. **Google Search Console API**
   - `GoogleSearchConsoleAPI` sınıfı
   - OAuth 2.0 authentication
   - Arama performansı verilerini çekme

3. **Ahrefs API Integration**
   - `AhrefsAPI` sınıfı
   - Backlink takibi
   - Domain rating hesaplaması

4. **SEO Service**
   - `SEOService` sınıfı
   - Veri senkronizasyonu
   - Rapor oluşturma
   - Alert sistemi

5. **FastAPI Endpoints**
   - `GET /api/seo/keywords` - Anahtar kelimeler
   - `GET /api/seo/performance` - Performans metrikleri
   - `GET /api/seo/backlinks` - Backlink verileri
   - `GET /api/seo/alerts` - Sistem uyarıları
   - `GET /api/seo/report` - Aylık rapor
   - `POST /api/seo/sync` - Manuel senkronizasyon
   - `GET /health` - Sağlık kontrolü

---

## 📊 Frontend Yapısı

### SEODashboard.jsx

**Temel Bileşenler:**
1. **Sidebar Navigation**
   - Dashboard
   - Keywords
   - Backlinks
   - Reports
   - Alerts

2. **Header**
   - Sayfanın başlığı
   - Tarih aralığı seçimi
   - Senkronize etme butonu
   - Rapor oluşturma butonu

3. **Content Sections**
   - **Metrics Grid** - KPI kartları (Impressions, Clicks, Position, CTR)
   - **Charts** - Performans grafikleri
   - **Keywords Table** - Anahtar kelime sıralamaları tablosu
   - **Backlinks List** - Backlink listesi
   - **Alerts Panel** - Sistem uyarıları

4. **Styling**
   - Inline CSS only (Tailwind yok)
   - Responsive design
   - Dark/Light mode support (opsiyonel)

---

## 🔄 Veri Akışı

```
Google Search Console API
         ↓
    GoogleSearchConsoleAPI
         ↓
   SEOService.update_keyword_rankings()
         ↓
   Database (SEOKeyword table)
         ↓
   FastAPI Endpoints
         ↓
   React Components
         ↓
   SEO Dashboard UI
```

---

## 📅 Cron Job Schedule

```
seo_cron.py (APScheduler)
│
├── 02:00 AM (Daily)
│   └── sync_keywords()
│       └── Google Search Console'dan anahtar kelime verileri çekme
│
├── 03:00 AM (Sunday)
│   └── sync_backlinks()
│       └── Ahrefs'den backlink verileri çekme
│
├── 04:00 AM (1st of Month)
│   └── generate_monthly_report()
│       └── Aylık rapor oluşturma ve email gönderme
│
└── 05:00 AM (Monday)
    └── cleanup_old_data()
        └── 90 günden eski verileri silme
```

---

## 🗄️ Database Schema

### SEOKeyword Table
```sql
CREATE TABLE seo_keywords (
    id INTEGER PRIMARY KEY,
    keyword VARCHAR(255) NOT NULL,
    position INTEGER,
    impressions INTEGER DEFAULT 0,
    clicks INTEGER DEFAULT 0,
    ctr FLOAT DEFAULT 0.0,
    change INTEGER DEFAULT 0,
    tracked_date DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_keyword ON seo_keywords(keyword);
CREATE INDEX idx_tracked_date ON seo_keywords(tracked_date);
```

### SEOBacklink Table
```sql
CREATE TABLE seo_backlinks (
    id INTEGER PRIMARY KEY,
    domain VARCHAR(255) NOT NULL UNIQUE,
    anchor_text VARCHAR(255),
    domain_authority INTEGER,
    page_authority INTEGER,
    first_seen DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_seen DATETIME DEFAULT CURRENT_TIMESTAMP,
    is_active INTEGER DEFAULT 1
);

CREATE INDEX idx_domain ON seo_backlinks(domain);
CREATE INDEX idx_da ON seo_backlinks(domain_authority);
```

### SEOAlert Table
```sql
CREATE TABLE seo_alerts (
    id INTEGER PRIMARY KEY,
    alert_type VARCHAR(50),
    keyword VARCHAR(255),
    message TEXT,
    severity VARCHAR(20),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    is_read INTEGER DEFAULT 0
);

CREATE INDEX idx_alert_type ON seo_alerts(alert_type);
CREATE INDEX idx_created_at ON seo_alerts(created_at DESC);
```

### SEOReport Table
```sql
CREATE TABLE seo_reports (
    id INTEGER PRIMARY KEY,
    month VARCHAR(7) NOT NULL UNIQUE,
    data JSON,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_month ON seo_reports(month);
```

---

## 🔐 Ortam Değişkenleri

### Backend (.env)
```env
# GSC Configuration
GSC_PROPERTY_URL=https://mrreadyprep.com/
GSC_CREDENTIALS_FILE=credentials.json

# Ahrefs API
AHREFS_API_KEY=xxx

# Database
DATABASE_URL=postgresql://user:pass@host:5432/db

# Email
SMTP_SERVER=smtp.gmail.com
SMTP_USER=email@gmail.com
SMTP_PASSWORD=app_password
EMAIL_TO=admin@mrreadyprep.com

# API
REACT_APP_API_URL=http://localhost:8000

# Alerts
ALERT_THRESHOLD_POSITION_DROP=3
ALERT_THRESHOLD_DA_MINIMUM=40

# Logging
LOG_LEVEL=INFO
LOG_FILE=seo_monitoring.log
```

### Frontend (.env)
```env
REACT_APP_API_URL=http://localhost:8000
```

---

## 🚀 Kurulum Adımları Özeti

### 1. Repository Klonlama
```bash
git clone https://github.com/mehmetdisbudak/mrreadyprep.git
cd mrreadyprep/backend/seo_monitoring
```

### 2. Backend Kurulumu
```bash
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
# .env dosyasını düzenleyin
python seo_monitoring.py
```

### 3. Frontend Kurulumu
```bash
cd ../../frontend
cp .env.example .env
npm install
npm start
```

### 4. Docker ile (Opsiyonel)
```bash
cd ../backend/seo_monitoring
docker-compose up -d
```

### 5. Google API Yetkilendirmesi
```bash
# İlk çalıştırmada tarayıcı açılır
# Google hesabınızla giriş yapın
# token.json oluşturulur
```

---

## 📡 API Dökümentasyonu

### Anahtar Kelimeler Endpoint
```
GET /api/seo/keywords
Parameters:
  - days: int (default: 30)
  - limit: int (default: 20)

Response:
{
  "keywords": [
    {
      "keyword": "TOEFL preparation",
      "position": 3,
      "change": 1,
      "impressions": 3245,
      "clicks": 612,
      "ctr": 18.85
    }
  ],
  "total": 20
}
```

### Performans Endpoint
```
GET /api/seo/performance
Parameters:
  - days: int (default: 30)

Response:
{
  "metrics": {
    "impressions": 12458,
    "clicks": 2341,
    "avg_position": 8.4,
    "ctr": 18.8
  },
  "daily_data": {
    "2026-09-27": {
      "impressions": 415,
      "clicks": 78
    }
  }
}
```

### Backlinks Endpoint
```
GET /api/seo/backlinks
Parameters:
  - limit: int (default: 50)

Response:
{
  "backlinks": [
    {
      "domain": "edublogs.org",
      "anchor": "TOEFL prep",
      "da": 42,
      "pa": 38,
      "first_seen": "2026-09-20T10:30:00"
    }
  ],
  "total": 50,
  "high_quality": 12
}
```

---

## 🛠️ Geliştirme İpuçları

### Local Testing
```bash
# Backend test et
pytest tests/

# Frontend test et
npm test

# API manual test
curl http://localhost:8000/api/seo/keywords
```

### Database Sorguları
```bash
# SQLite
sqlite3 seo_monitoring.db
SELECT * FROM seo_keywords LIMIT 10;

# PostgreSQL
psql -U user -d database
SELECT COUNT(*) FROM seo_keywords;
```

### Log Kontrolü
```bash
# Gerçek zamanlı loglar
tail -f seo_monitoring.log

# Hata logları
grep ERROR seo_monitoring.log
```

---

## 🔄 CI/CD Pipeline

**GitHub Actions (.github/workflows/deploy.yml):**
```yaml
name: Deploy SEO Monitoring

on:
  push:
    branches: [main, production]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Deploy to Render
        run: |
          curl -X POST ${{ secrets.RENDER_WEBHOOK }}
```

---

## 📝 Versiyonlama

- **v1.0.0** - İlk sürüm
  - Google Search Console entegrasyonu
  - Ahrefs backlink takibi
  - Aylık rapor sistemi
  - Alert mekanizması

---

## 🤝 Katkıda Bulunma

1. Feature branch oluşturun: `git checkout -b feature/new-feature`
2. Değişiklikleri commit edin: `git commit -m "Add new feature"`
3. Branch'i push edin: `git push origin feature/new-feature`
4. Pull Request açın

---

**Son Güncellenme:** 2026-09-27
**Maintained by:** Mehmet Disbudak
