# 🚀 SEO Monitoring - Hızlı Başlangıç (5 Dakika)

## Seçenek A: Docker ile (En Kolay)

```bash
# 1. Docker Compose başlatın
docker-compose up -d

# 2. Backend'in hazır olmasını bekleyin (30 saniye)
docker logs mrreadyprep-seo-api

# 3. Tarayıcıda açın
# Backend: http://localhost:8000
# pgAdmin: http://localhost:5050
# Frontend: http://localhost:3000
```

**İşte bu kadar!** ✅

---

## Seçenek B: Yerel Kurulum (Manual)

### Backend Kurulumu (3 dakika)

```bash
# 1. Python sanal ortamı
python -m venv venv
source venv/bin/activate  # Linux/Mac
# veya: venv\Scripts\activate  # Windows

# 2. Bağımlılıkları yükle
pip install -r requirements.txt

# 3. .env oluştur
cp .env.example .env
# Sadece bu değerleri düzenle:
# - AHREFS_API_KEY=your_key
# - SMTP_USER=your_email@gmail.com

# 4. Başlat
python seo_monitoring.py
```

✅ Backend çalışıyor: `http://localhost:8000`

### Frontend Kurulumu (2 dakika)

```bash
# 1. Frontend klasörüne git
cd ../frontend

# 2. Bağımlılıkları yükle
npm install

# 3. .env oluştur
echo "REACT_APP_API_URL=http://localhost:8000" > .env

# 4. Başlat
npm start
```

✅ Frontend çalışıyor: `http://localhost:3000`

---

## Google Search Console Bağlantısı (2 dakika)

### İlk Kurulum

```bash
# 1. Tarayıcı otomatik açılacak
# 2. Google hesabınızla giriş yapın
# 3. İzinleri onaylayın
# 4. token.json oluşturulacak

# Tamamlandı! ✅
```

**Not:** `credentials.json` dosyasını Google Cloud Console'dan indirip backend klasörüne koymalısınız (bir kez).

---

## Test Edin

### API Test
```bash
# Terminal açın ve çalıştırın:
curl http://localhost:8000/api/seo/keywords

# Yanıt almalısınız (boş olsa bile):
# {"keywords": [], "total": 0}
```

### Dashboard Açın
```
http://localhost:3000
```

Dashboard görünüyor mu? **Tebrikler!** 🎉

---

## Sık Sorunlar

### ❌ "Connection refused"
→ Backend sunucusunun çalıştığını kontrol edin: `http://localhost:8000/health`

### ❌ "No module named 'google'"
→ `pip install -r requirements.txt` çalıştırın

### ❌ "credentials.json not found"
→ Google Cloud Console'dan indirip backend klasörüne yerleştirin

### ❌ "CORS error"
→ Frontend'deki `.env` dosyasında `REACT_APP_API_URL` doğru mu kontrol edin

---

## Sonraki Adımlar

1. **Ahrefs API Anahtarı Ekle**
   - ahrefs.com → Settings → API
   - Anahtarı `.env`'ye ekle

2. **Email Konfigürasyonu (İsteğe Bağlı)**
   - Gmail app password oluştur
   - `.env`'de ayarla

3. **Aylık Rapor Ayarla**
   - Cron job başlat: `python seo_cron.py`
   - Veya Docker Compose kullan (otomatik)

4. **Üretim Deploy**
   - Render.com'a git
   - GitHub repo'yu bağla
   - Ortam değişkenleri ekle

---

## Yararlı Komutlar

```bash
# Log göster
tail -f seo_monitoring.log

# Database açın
sqlite3 seo_monitoring.db
SELECT COUNT(*) FROM seo_keywords;

# Docker durumunu kontrol et
docker-compose ps

# Docker'ı durdur
docker-compose down

# Fresh start (veri kaybedilir!)
docker-compose down -v
docker-compose up -d
```

---

## Dashboard Kullanımı

1. **Metrics Kartları** - Ana KPI'lar gösterir
2. **Performance Charts** - Grafikleri görüntüle
3. **Keywords Tablosu** - Sıralamaları kontrol et
4. **Backlinks Paneli** - Link profili izle
5. **Alerts** - Uyarıları yönet

**Her 5 dakikada otomatik yenilenir** ↻

---

## Sonraki Konfigürasyon (Opsiyonel)

### SSL Sertifikası (Üretim)
```bash
# Render'da otomatik HTTP → HTTPS yönlendirmesi
```

### Custom Domain
```bash
# Render → Settings → Custom Domain
your-domain.com → mrreadyprep-seo-api.onrender.com
```

### Database Yedekleme
```bash
# Düzenli SQL dump al
pg_dump database > backup.sql
```

---

## Yardım İhtiyacı?

- **Kurulum:** Bkz. `KURULUM_REHBERI.md`
- **API Docs:** Bkz. `PROJE_YAPISI.md`
- **GitHub Issues:** github.com/mehmetdisbudak/mrreadyprep/issues

---

**Enjoy! 🚀**
