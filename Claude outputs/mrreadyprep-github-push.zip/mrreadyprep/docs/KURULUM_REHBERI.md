# MRReadyPrep - SEO Monitoring Sistemi Kurulum Rehberi

## 📋 İçindekiler
1. [Ön Gereksinimler](#ön-gereksinimler)
2. [Adım 1: Google Search Console Bağlantısı](#adım-1-google-search-console-bağlantısı)
3. [Adım 2: Backend Kurulumu](#adım-2-backend-kurulumu)
4. [Adım 3: Frontend Kurulumu](#adım-3-frontend-kurulumu)
5. [Adım 4: Cron Job Ayarları](#adım-4-cron-job-ayarları)
6. [Adım 5: Deployment](#adım-5-deployment)
7. [Sorun Giderme](#sorun-giderme)

---

## Ön Gereksinimler

### Kurulu Olması Gereken
- Python 3.8 veya üstü
- Node.js 16 veya üstü (npm/yarn)
- PostgreSQL (üretim için)
- Git

### Hesaplar
- Google Cloud Console erişimi
- Ahrefs API anahtarı (backlink takibi için)
- Gmail hesabı (email raporları için)

---

## Adım 1: Google Search Console Bağlantısı

### 1.1 Google Cloud Proje Oluşturma

1. [Google Cloud Console](https://console.cloud.google.com) sayfasını açın
2. Yeni proje oluşturun
3. "Search Console API" araması yapın
4. API'yi etkinleştirin

### 1.2 OAuth 2.0 Kimlik Bilgileri

1. **Kimlik Bilgileri** → **Oluştur** → **OAuth 2.0 İstemci Kimliği**
2. **Uygulama türü**: Masaüstü uygulaması
3. İndir → `credentials.json` dosyasını backend klasörüne yerleştirin

### 1.3 Google Search Console İçin Site Doğrulama

1. [Google Search Console](https://search.google.com/search-console) sayfasına gidin
2. `mrreadyprep.com` ekleyin
3. Siteminizi doğrulayın (DNS, HTML dosyası veya meta tag ile)

---

## Adım 2: Backend Kurulumu

### 2.1 Repository Klonlama ve Hazırlık

```bash
# Repo klonlayın
cd mrreadyprep
git clone https://github.com/mehmetdisbudak/mrreadyprep.git

# Backend klasörü oluşturun
mkdir -p backend/seo_monitoring
cd backend/seo_monitoring
```

### 2.2 Sanal Ortam Kurulumu

```bash
# Python sanal ortamı oluşturun
python -m venv venv

# Sanal ortamı etkinleştirin
# Linux/Mac:
source venv/bin/activate

# Windows:
venv\Scripts\activate

# Bağımlılıkları yükleyin
pip install -r requirements.txt
```

### 2.3 .env Dosyası Ayarları

```bash
# .env dosyasını oluşturun
cp .env.example .env

# Aşağıdaki değerleri düzenleyin
nano .env
```

**Gerekli değişkenler:**
```env
# Google Search Console
GSC_PROPERTY_URL=https://mrreadyprep.com/
GSC_CREDENTIALS_FILE=credentials.json

# Ahrefs (backlink takibi)
AHREFS_API_KEY=your_api_key_here

# Database (geliştirme: SQLite, üretim: PostgreSQL)
DATABASE_URL=sqlite:///./seo_monitoring.db

# Email (raporlar için)
SMTP_USER=your_email@gmail.com
SMTP_PASSWORD=app_password_here
EMAIL_TO=your_email@gmail.com

# API
REACT_APP_API_URL=http://localhost:8000
```

### 2.4 Database Başlatma

```bash
# Database migrationları çalıştırın
python -c "from seo_monitoring import Base, engine; Base.metadata.create_all(bind=engine)"

# Başarı mesajı göreceksiniz
```

### 2.5 Backend Sunucusunu Başlatın

```bash
# Geliştirme modunda
uvicorn seo_monitoring:app --reload --host 0.0.0.0 --port 8000

# Üretim modunda (Render için)
gunicorn -w 4 -k uvicorn.workers.UvicornWorker seo_monitoring:app --bind 0.0.0.0:8000
```

**Kontrol:** `http://localhost:8000/health` ziyaret edin

---

## Adım 3: Frontend Kurulumu

### 3.1 React Projesi Hazırlığı

```bash
# Frontend klasörüne gidin
cd ../../frontend

# SEO Dashboard bileşeni ekleyin
# src/components/SEODashboard.jsx dosyasını yerleştirin
cp SEODashboard.jsx src/components/

# .env dosyasını ayarlayın
echo "REACT_APP_API_URL=http://localhost:8000" > .env
```

### 3.2 Bileşeni Entegre Edin

**`src/App.js` veya `src/pages/Dashboard.js`:**

```jsx
import SEODashboard from './components/SEODashboard';

function App() {
  return (
    <div>
      <SEODashboard />
    </div>
  );
}

export default App;
```

### 3.3 Frontend Başlatın

```bash
# Bağımlılıkları yükleyin
npm install

# Geliştirme sunucusunu başlatın
npm start

# Üretim build (Vercel için)
npm run build
```

---

## Adım 4: Cron Job Ayarları

### 4.1 Otomatik Senkronizasyon

```bash
# seo_cron.py dosyasını backend klasörüne yerleştirin
cd backend/seo_monitoring

# Cron job sunucusunu başlatın
python seo_cron.py
```

**Zamanlama:**
- **2:00 AM** - Günlük anahtar kelime sıralaması senkronizasyonu
- **3:00 AM (Pazarlar)** - Backlink senkronizasyonu
- **4:00 AM (Ayın 1'i)** - Aylık rapor oluşturma
- **5:00 AM (Pazartesi)** - Eski verileri temizleme

### 4.2 Render veya Heroku'da Cron Job Ayarı

**Render Dashboard:**
1. Yeni bir "Background Worker" oluşturun
2. Komut: `python seo_cron.py`
3. Environment variables'ı ekleyin

---

## Adım 5: Deployment

### 5.1 Backend Deployment (Render)

```bash
# 1. Render.com'a gidin
# 2. Yeni Web Service oluşturun
# 3. GitHub repo'nuzla bağlayın

# Environment variables ekleyin:
AHREFS_API_KEY=...
GSC_CREDENTIALS_FILE=credentials.json
DATABASE_URL=postgresql://...
```

**render.yaml:**
```yaml
services:
  - type: web
    name: mrreadyprep-seo-api
    env: python
    buildCommand: pip install -r requirements.txt
    startCommand: gunicorn -w 4 -k uvicorn.workers.UvicornWorker seo_monitoring:app

  - type: background-worker
    name: mrreadyprep-seo-cron
    env: python
    buildCommand: pip install -r requirements.txt
    startCommand: python seo_cron.py
```

### 5.2 Frontend Deployment (Vercel)

```bash
# 1. Vercel'e gidin
# 2. GitHub repo'nuzla bağlayın
# 3. Environment variable ekleyin:
REACT_APP_API_URL=https://your-backend.onrender.com
```

---

## Adım 6: Google Search Console API İlk Kurulumu

İlk kez çalıştırdığınızda:

```bash
python seo_monitoring.py

# İnternet tarayıcısı açılacak
# Google hesabınızla giriş yapın
# İzinleri onaylayın
# token.json oluşturulacak (güvenli tutun!)
```

---

## API Endpoints Rehberi

### Anahtar Kelime Sıralamaları
```bash
curl http://localhost:8000/api/seo/keywords?days=30&limit=20
```

**Yanıt:**
```json
{
  "keywords": [
    {
      "keyword": "TOEFL preparation course",
      "position": 3,
      "change": 1,
      "impressions": 3245,
      "clicks": 612,
      "ctr": 18.85
    }
  ],
  "total": 20
}
```

### Performans Metrikleri
```bash
curl http://localhost:8000/api/seo/performance?days=30
```

### Backlink Verileri
```bash
curl http://localhost:8000/api/seo/backlinks?limit=50
```

### Uyarılar
```bash
curl http://localhost:8000/api/seo/alerts?limit=20

# Uyarıyı okundu olarak işaretle
curl -X POST http://localhost:8000/api/seo/alerts/1/read
```

### Manuel Senkronizasyon
```bash
curl -X POST http://localhost:8000/api/seo/sync
```

---

## Sorun Giderme

### Problem: Google Search Console Bağlantısı Başarısız

**Çözüm:**
```bash
# credentials.json dosyasını kontrol edin
ls -la credentials.json

# Token dosyasını sıfırlayın
rm -f token.json

# Yeniden çalıştırın ve yetkilendirin
python seo_monitoring.py
```

### Problem: Database Hatası

```bash
# SQLite veritabanını sıfırlayın
rm -f seo_monitoring.db

# Yeniden başlatın
python -c "from seo_monitoring import Base, engine; Base.metadata.create_all(bind=engine)"
```

### Problem: Ahrefs API Yanıt Vermiyor

```bash
# API anahtarını kontrol edin
echo $AHREFS_API_KEY

# Ahrefs'de API kotasını kontrol edin
# (Ahrefs Dashboard → Settings → API)
```

### Problem: Email Raporu Göndermiyor

```bash
# Gmail uygulama parolası oluşturun:
# 1. myaccount.google.com
# 2. Security → App Passwords
# 3. Mail seçin
# 4. Generated password'u kopyalayın
# 5. .env dosyasında SMTP_PASSWORD olarak ayarlayın
```

### Problem: CORS Hatası Frontend'de

**Çözüm:** Backend başlatma komutu şöyle olmalı:
```bash
# Geliştirilmiş CORS desteği ile
uvicorn seo_monitoring:app --reload --host 0.0.0.0 --port 8000 --ws-ping-interval 20
```

### Log Kontrol Etme

```bash
# Tüm logları görün
tail -f seo_monitoring.log

# Cron job logları
tail -f seo_cron.py.log

# Docker'da çalışıyorsa
docker logs -f container_name
```

---

## Güvenlik En İyi Uygulamaları

1. **Kimlik Bilgilerini Saklayın**
   ```bash
   # Never commit these files
   echo "credentials.json" >> .gitignore
   echo "token.json" >> .gitignore
   echo ".env" >> .gitignore
   ```

2. **Database Şifresi**
   - Üretimde güçlü PostgreSQL şifresi kullanın
   - DATABASE_URL ortam değişkeni olarak ayarlayın

3. **API Anahtarı Döndürme**
   - 3 ayda bir Ahrefs API anahtarını güncelleyin
   - Google OAuth token'larını düzenli olarak yenileyin

4. **Rate Limiting**
   ```python
   # seo_monitoring.py'da ekleyin
   from slowapi import Limiter
   limiter = Limiter(key_func=get_remote_address)
   ```

---

## Monitoring ve Alerting

### Health Check
```bash
# Düzenli olarak kontrol edin
curl http://localhost:8000/health
```

### Veritabanı Boyutu
```bash
# SQLite
du -sh seo_monitoring.db

# PostgreSQL
psql -U user -d database -c "SELECT pg_size_pretty(pg_database_size('database'));"
```

### API Response Time
```bash
# Yanıt süresini ölçün
curl -w "@curl-format.txt" -o /dev/null -s http://localhost:8000/api/seo/keywords
```

---

## İletişim ve Destek

- **GitHub Issues:** github.com/mehmetdisbudak/mrreadyprep/issues
- **Email:** mehmet.disbudak03@hotmail.com

---

**Son Güncelleme:** 2026-09-27
**Versiyon:** 1.0.0
