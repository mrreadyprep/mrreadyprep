# MRReadyPrep Video Content Strategy System - Kurulum Rehberi

**Versiyon:** 1.0.0  
**Dil:** Türkçe  
**Son Güncelleme:** 2026-09-27  

---

## İçindekiler

1. [Sistem Özeti](#sistem-özeti)
2. [Gereksinimler](#gereksinimler)
3. [YouTube Kanal Bağlantısı](#youtube-kanal-bağlantısı)
4. [Backend Kurulumu](#backend-kurulumu)
5. [Frontend Kurulumu](#frontend-kurulumu)
6. [Veritabanı Kurulumu](#veritabanı-kurulumu)
7. [Environment Ayarları](#environment-ayarları)
8. [Deployment](#deployment)
9. [Sık Sorulan Sorular](#ssk)
10. [Sorun Giderme](#sorun-giderme)

---

## Sistem Özeti

MRReadyPrep Video Content Strategy System, TOEFL iBT 2026 hazırlık platformu için YouTube video yönetimi ve otomasyonunu sağlayan kapsamlı bir sistemdir.

### Temel Özellikler

- **📹 Video Yönetimi**: Drag-drop video upload, metadata yönetimi
- **📅 Yayın Otomasyonu**: 4 video/ay (haftalık 1 video) otomatik yayın planlaması
- **📊 Analytics Dashboard**: YouTube analytics entegrasyonu, performans takibi
- **🔄 OAuth2 Entegrasyonu**: YouTube Data API v3 ile güvenli bağlantı
- **⏰ Zamanlanmış Yayın**: Belirli tarihte otomatik video yayınlama
- **📧 Email Bildirimleri**: Upload hatırlatması, yayın bildirimi, haftalık rapor
- **📋 İçerik Takvimi**: Aylık planlama ve görsel takvim

---

## Gereksinimler

### Yazılım Gereksinimleri

- **Python 3.9+**
- **Node.js 18+** (npm veya yarn)
- **PostgreSQL 13+**
- **Redis** (opsiyonel, cache için)

### Dış Servisler

- **Google YouTube Data API v3** (OAuth2 kimlik doğrulaması)
- **Gmail SMTP** (e-mail bildirimleri için)

### İşletim Sistemi

- Linux (Ubuntu 20.04+)
- macOS 12+
- Windows 11 (WSL2 ile)

---

## YouTube Kanal Bağlantısı

### Adım 1: Google Cloud Console'de Proje Oluşturun

1. [Google Cloud Console](https://console.cloud.google.com/) adresine gidin
2. Yeni bir proje oluşturun: **MRReadyPrep-VideoManagement**
3. Proje seçildikten sonra API'leri etkinleştirin

### Adım 2: YouTube Data API v3'ü Etkinleştirin

1. Sol menüden **APIs & Services** → **Library**
2. "YouTube Data API v3" araması yapın
3. **Enable** butonunu tıklayın
4. API başarıyla etkinleştirildi

### Adım 3: OAuth2 Kimlik Bilgilerini Oluşturun

1. **APIs & Services** → **Credentials**
2. **+ Create Credentials** → **OAuth Client ID**
3. Uygulama tipi seçin: **Web Application**
4. Kimlik bilgilerini yapılandırın:

```
İsim: MRReadyPrep Video Manager
Yetkilendirilmiş JavaScript kaynakları:
  - http://localhost:3000
  - http://localhost:8000
  - https://yourdomain.com (production)

Yetkilendirilmiş redirect URI'ları:
  - http://localhost:8000/api/videos/oauth-callback
  - https://yourdomain.com/api/videos/oauth-callback
```

5. **Create** butonunu tıklayın
6. **Client ID** ve **Client Secret**'i kaydedin (`.env` dosyası için gerekli)

### Adım 4: Gmail SMTP Ayarları

Video yükleme hatırlatması ve analytics raporları için Gmail SMTP kullanılır.

1. [Gmail Account Settings](https://myaccount.google.com/security) açın
2. **Security** sekmesi → **App passwords**
3. İşletim sistemi ve tarayıcı seçin
4. Oluşturulan **App Password**'ü kaydedin (16 karakterlik şifre)
5. Bu şifreyi `.env` dosyasına `SMTP_PASSWORD` olarak girin

**Not:** Gmail'de 2FA (Two-Factor Authentication) etkinleştirilmiş olması gerekir.

---

## Backend Kurulumu

### Adım 1: Proje Klasörünü Oluşturun

```bash
mkdir mrreadyprep-video-system
cd mrreadyprep-video-system

# Python virtual environment oluşturun
python3 -m venv venv
source venv/bin/activate  # Linux/macOS
# veya
venv\Scripts\activate  # Windows
```

### Adım 2: Gerekli Paketleri Yükleyin

```bash
# Dosyaları uygun yerlere koyun:
# - backend_models.py → app/models.py
# - backend_youtube_service.py → app/services/youtube_service.py
# - backend_video_routes.py → app/routes/videos.py
# - backend_scheduler_service.py → app/services/scheduler_service.py
# - backend_email_service.py → app/services/email_service.py
# - backend_database.py → app/database.py
# - backend_main.py → app/main.py
# - backend_schemas.py → app/schemas.py
# - backend_requirements.txt → requirements.txt

pip install -r requirements.txt
```

### Adım 3: Klasör Yapısını Oluşturun

```
backend/
├── app/
│   ├── __init__.py
│   ├── main.py
│   ├── database.py
│   ├── models.py
│   ├── schemas.py
│   ├── routes/
│   │   ├── __init__.py
│   │   └── videos.py
│   └── services/
│       ├── __init__.py
│       ├── youtube_service.py
│       ├── email_service.py
│       └── scheduler_service.py
├── uploads/
│   └── videos/
├── requirements.txt
├── .env
└── .gitignore
```

### Adım 4: .env Dosyasını Oluşturun

```bash
# Backend .env dosyası (backend/.env)

# Database
DATABASE_URL=postgresql://user:password@localhost:5432/mrreadyprep_videos

# YouTube API
YOUTUBE_CLIENT_ID=your-client-id.apps.googleusercontent.com
YOUTUBE_CLIENT_SECRET=your-client-secret
YOUTUBE_REDIRECT_URI=http://localhost:8000/api/videos/oauth-callback

# Gmail SMTP
SMTP_EMAIL=your-email@gmail.com
SMTP_PASSWORD=your-app-password

# Frontend URL
FRONTEND_URL=http://localhost:3000

# Server
HOST=0.0.0.0
PORT=8000
DEBUG=True
```

### Adım 5: Backend'i Başlatın

```bash
cd backend

# Development mode
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000

# Production mode (Render üzerinde)
# .env dosyasında DEBUG=False
gunicorn app.main:app --workers 4 --worker-class uvicorn.workers.UvicornWorker
```

Backend başarıyla başlatılırsa http://localhost:8000 adresinde çalışıyor olmalıdır.

---

## Frontend Kurulumu

### Adım 1: React Projesini Oluşturun

```bash
npx create-react-app frontend
cd frontend

# Gerekli paketleri yükleyin
npm install
```

### Adım 2: Bileşenleri Yükleyin

Aşağıdaki dosyaları `src/components/` dizinine yerleştirin:

```
src/
├── components/
│   ├── VideoUploadForm.jsx
│   ├── VideoScheduler.jsx
│   ├── VideoAnalyticsDashboard.jsx
│   ├── VideoList.jsx
│   └── ContentCalendar.jsx
├── pages/
│   └── VideoManagement.jsx
├── App.jsx
├── index.css
└── .env
```

### Adım 3: Frontend .env Dosyasını Oluşturun

```bash
# frontend/.env

REACT_APP_API_URL=http://localhost:8000
```

### Adım 4: Frontend'i Başlatın

```bash
npm start
```

Frontend başarıyla başlatılırsa http://localhost:3000 adresinde açılmalıdır.

---

## Veritabanı Kurulumu

### Adım 1: PostgreSQL Veritabanını Oluşturun

```bash
# PostgreSQL bağlantısı
psql -U postgres

# Veritabanı oluşturun
CREATE DATABASE mrreadyprep_videos;
CREATE USER mrreadyprep WITH PASSWORD 'secure_password';
ALTER ROLE mrreadyprep SET client_encoding TO 'utf8';
ALTER ROLE mrreadyprep SET default_transaction_isolation TO 'read committed';
ALTER ROLE mrreadyprep SET default_transaction_deferrable TO on;
ALTER ROLE mrreadyprep SET search_path TO public;
GRANT ALL PRIVILEGES ON DATABASE mrreadyprep_videos TO mrreadyprep;
\q
```

### Adım 2: Tabloları Oluşturun

Backend başlatıldığında, SQLAlchemy otomatik olarak tabloları oluşturur. İstemersen manuel olarak da yapabilirsin:

```bash
python3 -c "from app.database import create_tables; create_tables()"
```

### Adım 3: Veritabanını Sıfırlayın (İsteğe bağlı)

```bash
python3 -c "from app.database import reset_database; reset_database()"
```

---

## Environment Ayarları

### Production Ayarları (Render)

#### Backend Environment Variables (Render)

```env
DATABASE_URL=postgresql://user:password@host:5432/dbname
YOUTUBE_CLIENT_ID=your-prod-client-id
YOUTUBE_CLIENT_SECRET=your-prod-secret
YOUTUBE_REDIRECT_URI=https://yourdomain.com/api/videos/oauth-callback
SMTP_EMAIL=your-email@gmail.com
SMTP_PASSWORD=your-app-password
FRONTEND_URL=https://yourdomain.com
HOST=0.0.0.0
PORT=8000
DEBUG=False
```

#### Build Command (Render)

```bash
pip install -r requirements.txt
python -c "from app.database import create_tables; create_tables()"
```

#### Start Command (Render)

```bash
gunicorn app.main:app --workers 4 --worker-class uvicorn.workers.UvicornWorker --bind 0.0.0.0:$PORT
```

#### Frontend Environment Variables (Vercel)

```env
REACT_APP_API_URL=https://api.yourdomain.com
```

---

## Deployment

### Render'a Backend Deployment

1. [Render.com](https://render.com/) adresine gidin ve kayıt olun
2. **New +** → **Web Service**
3. GitHub repository'yi bağlayın
4. Ayarları yapılandırın:
   - **Name:** mrreadyprep-video-api
   - **Environment:** Python 3
   - **Build Command:** `pip install -r requirements.txt`
   - **Start Command:** `gunicorn app.main:app --workers 4 --worker-class uvicorn.workers.UvicornWorker --bind 0.0.0.0:$PORT`
5. Environment variables'ları ekleyin
6. **Deploy** butonunu tıklayın

### Vercel'e Frontend Deployment

1. [Vercel.com](https://vercel.com/) adresine gidin ve kayıt olun
2. **New Project** → GitHub repo seçin
3. Ayarları yapılandırın:
   - **Framework Preset:** Create React App
   - **Build Command:** `npm run build`
   - **Output Directory:** `build`
4. Environment variables'ları ekleyin:
   - `REACT_APP_API_URL=https://your-backend-url.com`
5. **Deploy** butonunu tıklayın

---

## Kullanım Kılavuzu

### Video Yükleme Süreci

1. **Dashboard**'da **+ Yeni Video Yükle** butonuna tıklayın
2. Video dosyasını sürükleyip bırakın veya seçin
3. Video başlığı, açıklama ve etiketleri girin
4. (İsteğe bağlı) Planlanan yayın tarihini seçin
5. **Yükle ve Planla** butonunu tıklayın

### Otomatik Yayın Planlaması

- **Hedef:** 4 video/ay (haftalık 1 video)
- **Sistem:** APScheduler ile otomatik yayın
- **Takvim:** Takvim görüntüsünde planlanan günleri görebilirsiniz

### Analytics Izleme

1. **Analytics** sekmesine gidin
2. Kanal istatistiklerini görüntüleyin
3. Bu ayın performansını izleyin
4. Video bazlı analytics için **Tüm Videolar** → **Analytics** tıklayın

### Email Bildirimleri

Sistem otomatik olarak aşağıdaki durumlarda email gönderir:

- ✅ **Video Upload Hatırlatması**: Video yüklendikten hemen sonra
- ✅ **Yayın Bildirimi**: Video YouTube'a yayınlandığında
- ✅ **Haftalık Analytics Raporu**: Her Pazartesi sabahı 09:00
- ✅ **Aylık Planlama Hatırlatması**: Her ayın 1. günü 08:00

---

## SSS (Sık Sorulan Sorular)

### S: YouTube kanal bağlantısında OAuth hatası alıyorum

**C:** 
1. Redirect URI'ların doğru olup olmadığını kontrol edin
2. Google Cloud Console'de Client Secret'ı doğrulayın
3. Browser cache'i temizleyin ve tekrar deneyin

### S: Video upload çok yavaş, sorun mu var?

**C:** 
- Video dosya boyutunu kontrol edin (YouTube limiti 128GB)
- İnternet bağlantısını kontrol edin
- Console'daki hata mesajlarını kontrol edin

### S: Email bildirimleri gelmiyorsa ne yapmalıyım?

**C:** 
1. Gmail SMTP şifresini (.env dosyasında) kontrol edin
2. Gmail hesabında 2FA etkinleştirilmiş olduğundan emin olun
3. Logs'ta "SMTP connection refused" gibi hatalar olup olmadığını kontrol edin

### S: Analytics verileri güncellenmiyorsa?

**C:** 
- YouTube'a yayınlamadan sonra 24-48 saat bekleyin
- Video'yu dashboard'dan **Analytics** butonuyla manually sync etmeyi deneyin
- API quotaları kontrol edin (Google Cloud Console)

### S: 4 video/ay sınırını nasıl değiştirebilirim?

**C:** 
Backend'de `app/models.py` dosyasından `PublishSchedule` modelini düzenleyebilir veya env variable'ı kullanabilirsiniz:

```python
# models.py'de
target_count = Column(Integer, default=4)

# Veya env'den
VIDEOS_PER_MONTH = 4
```

### S: Veritabanını reset etmek istiyorum

**C:** 
```bash
python3 -c "from app.database import reset_database; reset_database()"
```

**Uyarı:** Bu işlem TÜM verileri siler!

---

## Sorun Giderme

### Backend Hataları

#### "ModuleNotFoundError: No module named 'app'"

```bash
# Virtual environment etkinleştirilmiş olduğundan emin olun
source venv/bin/activate

# Paketleri tekrar yükleyin
pip install -r requirements.txt
```

#### "Database connection refused"

```bash
# PostgreSQL'in çalışıp çalışmadığını kontrol edin
psql -U postgres

# .env dosyasındaki DATABASE_URL'yi kontrol edin
```

#### "SMTP authentication failed"

```bash
# Gmail App Password'ü kontrol edin (16 karakter)
# 2FA'nın etkin olduğundan emin olun
# .env dosyasındaki SMTP_PASSWORD'ü doğrulayın
```

### Frontend Hataları

#### "CORS error: Access-Control-Allow-Origin"

Backend'de `.env` dosyasındaki `FRONTEND_URL` doğru olduğundan emin olun:

```env
FRONTEND_URL=http://localhost:3000
# Production'da
FRONTEND_URL=https://yourdomain.com
```

#### "API request failed"

1. Backend'in çalışıp çalışmadığını kontrol edin
2. `.env` dosyasındaki `REACT_APP_API_URL` doğru olduğundan emin olun
3. Network tab'ını kontrol edin (F12 → Network)

### Veritabanı Hataları

#### "Column does not exist"

Veritabanını reset edin:

```bash
python3 -c "from app.database import reset_database; reset_database()"
```

---

## Destek ve İletişim

Sorularınız veya sorunlarınız olursa:

- GitHub Issues: [mrreadyprep/mrreadyprep/issues](https://github.com/mehmetdisbudak/mrreadyprep/issues)
- Email: mehmet.disbudak03@hotmail.com

---

**Son Güncelleme:** 2026-09-27  
**Versiyon:** 1.0.0  
**Yazarı:** Mehmet Disbudak  
**Lisans:** MIT
