# MRReadyPrep Video Management API - Dokumentasyon

**Versiyon:** 1.0.0  
**Base URL:** `http://localhost:8000` (Development) / `https://api.yourdomain.com` (Production)  
**Format:** JSON  
**Kimlik Doğrulama:** OAuth2 (YouTube) 

---

## İçindekiler

1. [Genel Bilgiler](#genel-bilgiler)
2. [Authentication](#authentication)
3. [Endpoints](#endpoints)
4. [Hata Kodları](#hata-kodları)
5. [Örnekler](#örnekler)

---

## Genel Bilgiler

### Başlıklar (Headers)

Tüm istekler aşağıdaki başlığı içermelidir:

```
Content-Type: application/json
```

### Yanıt Formatı

Tüm API yanıtları aşağıdaki formatı kullanır:

```json
{
  "success": true,
  "data": {},
  "message": "İşlem başarılı",
  "timestamp": "2026-09-27T10:30:00Z"
}
```

### Pagination

Liste dönen endpoint'ler aşağıdaki parametreleri destekler:

```
?skip=0&limit=20
```

---

## Authentication

### 1. OAuth2 Login URL Alma

Kullanıcıyı YouTube login'ine yönlendirmek için kullanılır.

**Endpoint:**
```
POST /api/videos/oauth-url
```

**Response:**
```json
{
  "success": true,
  "auth_url": "https://accounts.google.com/o/oauth2/auth?..."
}
```

**Kullanım:**
```javascript
// Frontend'de
const response = await fetch(`${API_URL}/api/videos/oauth-url`);
const data = await response.json();
window.location.href = data.auth_url;
```

---

### 2. OAuth2 Callback

YouTube kimlik doğrulamasından sonra çağrılır. Token'ı kaydeder.

**Endpoint:**
```
POST /api/videos/oauth-callback?code={authorization_code}
```

**Query Parameters:**
- `code` (string, required): Google'ın sağladığı authorization code

**Response:**
```json
{
  "success": true,
  "channel": {
    "channel_id": "UCxxxxxx",
    "channel_name": "MRReadyPrep",
    "subscriber_count": 1000,
    "video_count": 50,
    "view_count": 50000
  },
  "message": "Channel başarıyla bağlandı"
}
```

---

## Endpoints

### Video Yönetimi

#### 1. Video Upload

Video dosyasını yükle ve metadatasını kaydet.

**Endpoint:**
```
POST /api/videos/upload
```

**Content-Type:** `multipart/form-data`

**Form Data:**
```
file: <video_file> (required)
title: "TOEFL Reading Tips" (required)
description: "Bu videoda TOEFL Reading bölümü..." (required)
tags: "toefl,reading,tips" (required)
scheduled_date: "2026-10-01T14:00:00" (optional)
```

**Response:**
```json
{
  "success": true,
  "video_id": "550e8400-e29b-41d4-a716-446655440000",
  "status": "draft",
  "message": "Video başarıyla yüklendi"
}
```

**cURL Örneği:**
```bash
curl -X POST http://localhost:8000/api/videos/upload \
  -F "file=@video.mp4" \
  -F "title=TOEFL Reading Tips" \
  -F "description=Tips for TOEFL reading section" \
  -F "tags=toefl,reading"
```

---

#### 2. Video Listesi

Tüm video'ları listele.

**Endpoint:**
```
GET /api/videos/list?status=published&skip=0&limit=20
```

**Query Parameters:**
- `status` (string, optional): `draft`, `scheduled`, `published`, `archived`
- `skip` (integer, default: 0): Kaç video atlanacak
- `limit` (integer, default: 20): Kaç video döndürülecek

**Response:**
```json
{
  "success": true,
  "videos": [
    {
      "id": "550e8400-e29b-41d4-a716-446655440000",
      "title": "TOEFL Reading Tips",
      "description": "Bu videoda...",
      "tags": "toefl,reading",
      "status": "published",
      "youtube_id": "dQw4w9WgXcQ",
      "view_count": 1250,
      "like_count": 45,
      "comment_count": 12,
      "like_ratio": 3.6,
      "watch_time_hours": 125.5,
      "average_view_duration": 180,
      "scheduled_publish_date": "2026-09-27T14:00:00",
      "actual_publish_date": "2026-09-27T14:00:00",
      "created_at": "2026-09-20T10:00:00",
      "updated_at": "2026-09-27T10:30:00"
    }
  ],
  "total": 45,
  "skip": 0,
  "limit": 20
}
```

---

#### 3. Video Detayı

Tek bir video'nun detaylarını al.

**Endpoint:**
```
GET /api/videos/{video_id}
```

**Path Parameters:**
- `video_id` (string, required): Video UUID

**Response:**
```json
{
  "success": true,
  "video": {
    "id": "550e8400-e29b-41d4-a716-446655440000",
    "title": "TOEFL Reading Tips",
    ...
  }
}
```

---

#### 4. Video Planlama

Video'yu belirli bir tarihte yayınlanmak üzere planla.

**Endpoint:**
```
POST /api/videos/schedule
```

**Request Body:**
```json
{
  "video_id": "550e8400-e29b-41d4-a716-446655440000",
  "publish_date": "2026-10-05T14:00:00"
}
```

**Response:**
```json
{
  "success": true,
  "video_id": "550e8400-e29b-41d4-a716-446655440000",
  "scheduled_date": "2026-10-05T14:00:00",
  "message": "Video başarıyla planlandı"
}
```

**Hata (Quota Aşılırsa):**
```json
{
  "success": false,
  "error": "Bu ayın yayın kotası doldu (4/4)",
  "status_code": 400
}
```

---

#### 5. Video Yayınla

Video'yu hemen YouTube'a yayınla.

**Endpoint:**
```
POST /api/videos/{video_id}/publish
```

**Path Parameters:**
- `video_id` (string, required): Video UUID

**Response:**
```json
{
  "success": true,
  "video_id": "550e8400-e29b-41d4-a716-446655440000",
  "status": "publishing",
  "message": "Video yayınlanıyor..."
}
```

---

### Analytics

#### 1. Video Analytics

Belirli bir video'nun analytics'ini al.

**Endpoint:**
```
GET /api/videos/analytics/{video_id}
```

**Path Parameters:**
- `video_id` (string, required): Video UUID

**Response:**
```json
{
  "success": true,
  "video_id": "550e8400-e29b-41d4-a716-446655440000",
  "analytics": {
    "title": "TOEFL Reading Tips",
    "view_count": 1250,
    "like_count": 45,
    "comment_count": 12,
    "like_ratio": 3.6,
    "watch_time_hours": 125.5,
    "average_view_duration": 180,
    "last_synced": "2026-09-27T10:30:00"
  }
}
```

---

#### 2. Channel Analytics

Tüm kanal istatistiklerini al.

**Endpoint:**
```
GET /api/videos/channel/analytics
```

**Response:**
```json
{
  "success": true,
  "channel": {
    "name": "MRReadyPrep",
    "subscriber_count": 5000,
    "video_count": 50,
    "total_view_count": 250000
  },
  "this_month": {
    "total_views": 12400,
    "total_watch_time": 8340,
    "average_like_ratio": 3.8,
    "total_videos": 4
  }
}
```

---

### Yayın Takvimi

#### 1. Aylık Yayın Takvimi

Belirli bir ayın yayın planını al.

**Endpoint:**
```
GET /api/videos/calendar/{year}/{month}
```

**Path Parameters:**
- `year` (integer, required): Yıl (örn: 2026)
- `month` (integer, required): Ay (1-12)

**Response:**
```json
{
  "success": true,
  "month": "2026-09",
  "target_count": 4,
  "published_count": 3,
  "scheduled_count": 1,
  "scheduled_dates": [
    {
      "date": "2026-09-07T14:00:00",
      "title": "TOEFL Reading Tips Part 1",
      "status": "published",
      "video_id": "550e8400-e29b-41d4-a716-446655440000"
    },
    {
      "date": "2026-09-14T14:00:00",
      "title": "TOEFL Writing Templates",
      "status": "published",
      "video_id": "550e8400-e29b-41d4-a716-446655440010"
    },
    {
      "date": "2026-09-28T14:00:00",
      "title": "Speaking Practice Guide",
      "status": "scheduled",
      "video_id": "550e8400-e29b-41d4-a716-446655440020"
    }
  ]
}
```

---

### Sistem Bilgisi

#### 1. Sistem Durumu

API ve sistem durumunu kontrol et.

**Endpoint:**
```
GET /api/system/info
```

**Response:**
```json
{
  "status": "ok",
  "system": {
    "video_count": 50,
    "published_videos": 40,
    "scheduled_videos": 5,
    "channel_connected": true,
    "channel_name": "MRReadyPrep"
  },
  "scheduler": {
    "running": true,
    "jobs": 8
  },
  "timestamp": "2026-09-27T10:30:00Z"
}
```

---

#### 2. Health Check

API sağlıklı mı kontrol et.

**Endpoint:**
```
GET /health
```

**Response:**
```json
{
  "status": "healthy",
  "service": "video-management",
  "timestamp": "2026-09-27T10:30:00Z"
}
```

---

## Hata Kodları

| Kod | Anlamı | Çözüm |
|-----|--------|-------|
| 200 | OK | İstek başarılı |
| 400 | Bad Request | Geçersiz parametre veya request body |
| 404 | Not Found | Video veya kanal bulunamadı |
| 500 | Internal Server Error | Sunucu hatası - logs kontrol edin |

### Hata Yanıtları

```json
{
  "success": false,
  "error": "Açıklayıcı hata mesajı",
  "timestamp": "2026-09-27T10:30:00Z"
}
```

---

## Örnekler

### JavaScript (Fetch API)

```javascript
// 1. Video Upload
async function uploadVideo(file, title, description, tags) {
  const formData = new FormData();
  formData.append('file', file);
  formData.append('title', title);
  formData.append('description', description);
  formData.append('tags', tags);

  const response = await fetch(`${API_URL}/api/videos/upload`, {
    method: 'POST',
    body: formData,
  });

  return response.json();
}

// 2. Video Listesi Alma
async function getVideos(status = null, skip = 0, limit = 20) {
  let url = `${API_URL}/api/videos/list?skip=${skip}&limit=${limit}`;
  if (status) url += `&status=${status}`;

  const response = await fetch(url);
  return response.json();
}

// 3. Video Planlama
async function scheduleVideo(videoId, publishDate) {
  const response = await fetch(`${API_URL}/api/videos/schedule`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      video_id: videoId,
      publish_date: publishDate,
    }),
  });

  return response.json();
}

// 4. Analytics Alma
async function getVideoAnalytics(videoId) {
  const response = await fetch(
    `${API_URL}/api/videos/analytics/${videoId}`
  );
  return response.json();
}
```

### Python (Requests)

```python
import requests
import json

API_URL = "http://localhost:8000"

# 1. Video Listesi
def get_videos(status=None, skip=0, limit=20):
    params = {'skip': skip, 'limit': limit}
    if status:
        params['status'] = status
    
    response = requests.get(f"{API_URL}/api/videos/list", params=params)
    return response.json()

# 2. Video Planlama
def schedule_video(video_id, publish_date):
    data = {
        'video_id': video_id,
        'publish_date': publish_date
    }
    response = requests.post(
        f"{API_URL}/api/videos/schedule",
        json=data
    )
    return response.json()

# 3. Analytics Alma
def get_analytics(video_id):
    response = requests.get(
        f"{API_URL}/api/videos/analytics/{video_id}"
    )
    return response.json()
```

### cURL Örnekleri

```bash
# 1. Video Listesi
curl -X GET "http://localhost:8000/api/videos/list?status=published&limit=10"

# 2. Video Planlama
curl -X POST http://localhost:8000/api/videos/schedule \
  -H "Content-Type: application/json" \
  -d '{
    "video_id": "550e8400-e29b-41d4-a716-446655440000",
    "publish_date": "2026-10-05T14:00:00"
  }'

# 3. Channel Analytics
curl -X GET "http://localhost:8000/api/videos/channel/analytics"

# 4. Takvim
curl -X GET "http://localhost:8000/api/videos/calendar/2026/10"
```

---

## Rate Limiting

Şu anda rate limiting uygulanmamaktadır. Production ortamında implementasyon yapılması önerilir.

---

## Versioning

API versiyonu URL'de belirtilmez. Breaking changes'ler yeni endpoint'ler olarak eklenecektir.

---

**Son Güncelleme:** 2026-09-27  
**Versiyonu:** 1.0.0
