import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// Fix: Ensure Vite config is properly set up to handle import.meta
// This configuration ensures import.meta.env is available in all modules
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    strictPort: false,
  },
  build: {
    outDir: 'dist',
    sourcemap: false,
  },
  // Fix: Ensure environment variables are properly loaded
  define: {
    'process.env': {},
  },
})
