-- Referral Program Database Schema
-- Deploy to PostgreSQL production database

-- 1. Add referral columns to users table (if not exists)
ALTER TABLE users ADD COLUMN IF NOT EXISTS referral_code VARCHAR(12) UNIQUE NOT NULL DEFAULT '';
ALTER TABLE users ADD COLUMN IF NOT EXISTS referred_by_user_id UUID REFERENCES users(id) ON DELETE SET NULL;
ALTER TABLE users ADD COLUMN IF NOT EXISTS referral_discount_claimed BOOLEAN DEFAULT FALSE;
ALTER TABLE users ADD COLUMN IF NOT EXISTS referral_discount_expires_at TIMESTAMP DEFAULT NULL;
ALTER TABLE users ADD COLUMN IF NOT EXISTS total_referrals_count INT DEFAULT 0;
ALTER TABLE users ADD COLUMN IF NOT EXISTS total_referral_earnings DECIMAL(10, 2) DEFAULT 0.00;

-- 2. Create referrals table
CREATE TABLE IF NOT EXISTS referrals (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    referrer_user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    referred_user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    referral_code VARCHAR(12) NOT NULL UNIQUE,
    status VARCHAR(50) DEFAULT 'pending', -- pending, converted, paid
    conversion_date TIMESTAMP,
    reward_amount DECIMAL(10, 2) DEFAULT 5.00,
    is_paid BOOLEAN DEFAULT FALSE,
    paid_date TIMESTAMP,
    utm_source VARCHAR(100),
    utm_medium VARCHAR(100),
    utm_campaign VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_referrer_user_id (referrer_user_id),
    INDEX idx_referred_user_id (referred_user_id),
    INDEX idx_status (status),
    INDEX idx_referral_code (referral_code),
    INDEX idx_created_at (created_at)
);

-- 3. Create referral_credits table (credit balance tracking)
CREATE TABLE IF NOT EXISTS referral_credits (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
    balance DECIMAL(10, 2) DEFAULT 0.00,
    reserved_amount DECIMAL(10, 2) DEFAULT 0.00, -- awaiting payout
    total_earned DECIMAL(10, 2) DEFAULT 0.00,
    total_redeemed DECIMAL(10, 2) DEFAULT 0.00,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 4. Create referral_transactions table (audit trail)
CREATE TABLE IF NOT EXISTS referral_transactions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    referral_id UUID REFERENCES referrals(id) ON DELETE SET NULL,
    type VARCHAR(50), -- 'credit', 'redemption', 'payout', 'adjustment'
    amount DECIMAL(10, 2) NOT NULL,
    description TEXT,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_type (type),
    INDEX idx_created_at (created_at)
);

-- 5. Create referral_payouts table (for manual/automatic payouts)
CREATE TABLE IF NOT EXISTS referral_payouts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    amount DECIMAL(10, 2) NOT NULL,
    status VARCHAR(50) DEFAULT 'pending', -- pending, processing, completed, failed
    payout_method VARCHAR(50), -- 'stripe', 'bank_transfer', 'paypal', 'credit'
    stripe_payout_id VARCHAR(100),
    notes TEXT,
    requested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    processed_at TIMESTAMP,
    completed_at TIMESTAMP,
    error_message TEXT,
    INDEX idx_user_id (user_id),
    INDEX idx_status (status)
);

-- 6. Create referral_analytics table
CREATE TABLE IF NOT EXISTS referral_analytics (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    date DATE DEFAULT CURRENT_DATE,
    total_referrals INT DEFAULT 0,
    new_conversions INT DEFAULT 0,
    total_credits_issued DECIMAL(10, 2) DEFAULT 0.00,
    total_discounts_used DECIMAL(10, 2) DEFAULT 0.00,
    unique_referrers INT DEFAULT 0,
    conversion_rate DECIMAL(5, 2) DEFAULT 0.00,
    average_referrals_per_user DECIMAL(10, 2) DEFAULT 0.00,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(date)
);

-- 7. Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_referrals_status_created ON referrals(status, created_at);
CREATE INDEX IF NOT EXISTS idx_referral_credits_user ON referral_credits(user_id);
CREATE INDEX IF NOT EXISTS idx_referral_transactions_user ON referral_transactions(user_id, created_at);
CREATE INDEX IF NOT EXISTS idx_referral_payouts_status ON referral_payouts(status, requested_at);
CREATE INDEX IF NOT EXISTS idx_users_referral_code ON users(referral_code);

-- 8. Create function to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_referral_timestamp()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- 9. Create trigger for referrals table
CREATE TRIGGER referral_update_timestamp
BEFORE UPDATE ON referrals
FOR EACH ROW
EXECUTE FUNCTION update_referral_timestamp();

-- 10. Create function to generate unique referral code
CREATE OR REPLACE FUNCTION generate_referral_code(user_id UUID)
RETURNS VARCHAR(12) AS $$
DECLARE
    code VARCHAR(12);
    exists_count INT;
BEGIN
    LOOP
        -- Generate a random code: 3 letters + user ID hash + 2 random chars
        code := UPPER(SUBSTR(md5(user_id::TEXT || random()::TEXT), 1, 3)) ||
                UPPER(SUBSTR(md5(user_id::TEXT), 1, 4)) ||
                UPPER(SUBSTR(md5(random()::TEXT), 1, 2));

        -- Check if code already exists
        SELECT COUNT(*) INTO exists_count FROM users WHERE referral_code = code;

        EXIT WHEN exists_count = 0;
    END LOOP;

    RETURN code;
END;
$$ LANGUAGE plpgsql;

-- Schema complete
COMMIT;
