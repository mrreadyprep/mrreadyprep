# backend/app/schemas.py
from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import datetime


class VideoCreate(BaseModel):
    title: str = Field(..., min_length=1, max_length=100)
    description: str = Field(..., min_length=1, max_length=5000)
    tags: str = Field(..., description="Comma-separated tags")
    scheduled_publish_date: Optional[datetime] = None

    class Config:
        from_attributes = True


class VideoUpdate(BaseModel):
    title: Optional[str] = None
    description: Optional[str] = None
    tags: Optional[str] = None
    scheduled_publish_date: Optional[datetime] = None

    class Config:
        from_attributes = True


class VideoResponse(BaseModel):
    id: str
    title: str
    description: str
    tags: str
    status: str
    youtube_id: Optional[str] = None
    view_count: int
    like_count: int
    comment_count: int
    like_ratio: Optional[float] = None
    watch_time_hours: float
    average_view_duration: Optional[float] = None
    scheduled_publish_date: Optional[datetime] = None
    actual_publish_date: Optional[datetime] = None
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class AnalyticsResponse(BaseModel):
    video_id: str
    title: str
    view_count: int
    like_count: int
    comment_count: int
    like_ratio: float
    watch_time_hours: float
    average_view_duration: float
    subscriber_gain: int
    last_synced: Optional[datetime] = None

    class Config:
        from_attributes = True


class YouTubeChannelResponse(BaseModel):
    id: str
    channel_id: str
    channel_name: str
    channel_url: str
    subscriber_count: int
    video_count: int
    view_count: int
    is_connected: bool
    connected_at: datetime

    class Config:
        from_attributes = True


class PublishScheduleResponse(BaseModel):
    id: str
    month: str
    target_count: int
    published_count: int
    scheduled_dates: Optional[List[dict]] = None

    class Config:
        from_attributes = True


class NotificationLogResponse(BaseModel):
    id: str
    video_id: str
    notification_type: str
    recipient_email: str
    subject: str
    sent_at: datetime
    status: str

    class Config:
        from_attributes = True
