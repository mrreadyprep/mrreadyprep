# backend/app/services/email_service.py
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime
from typing import List, Optional
import logging

logger = logging.getLogger(__name__)


class EmailService:
    def __init__(self, smtp_email: str, smtp_password: str):
        self.smtp_email = smtp_email
        self.smtp_password = smtp_password
        self.smtp_server = "smtp.gmail.com"
        self.smtp_port = 587

    def send_email(self, to_email: str, subject: str, html_content: str) -> bool:
        """Email gönder"""
        try:
            # Gmail SMTP bağlantısı
            server = smtplib.SMTP(self.smtp_server, self.smtp_port)
            server.starttls()
            server.login(self.smtp_email, self.smtp_password)

            # Email oluştur
            message = MIMEMultipart("alternative")
            message["Subject"] = subject
            message["From"] = self.smtp_email
            message["To"] = to_email

            # HTML kısmı
            part = MIMEText(html_content, "html")
            message.attach(part)

            # Gönder
            server.sendmail(self.smtp_email, to_email, message.as_string())
            server.quit()

            logger.info(f"Email gönderildi: {to_email}")
            return True

        except Exception as e:
            logger.error(f"Email gönderme hatası: {str(e)}")
            return False

    def send_upload_reminder(self, video_title: str, scheduled_date: str) -> bool:
        """Video yükleme hatırlatması"""
        subject = f"Video Yüklendi: {video_title}"

        html_content = f"""
        <html style="font-family: Arial, sans-serif;">
        <body style="background-color: #f5f5f5; margin: 0; padding: 20px;">
            <div style="max-width: 600px; margin: 0 auto; background-color: white; border-radius: 10px; padding: 30px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
                <h2 style="color: #1e3c72; margin-top: 0;">🎥 Video Başarıyla Yüklendi</h2>

                <p style="color: #333; line-height: 1.6;">
                    <strong>{video_title}</strong> başlıklı video'unuz MRReadyPrep sistemine başarıyla yüklendi.
                </p>

                <div style="background-color: #f0f8ff; border-left: 4px solid #4a9eff; padding: 15px; margin: 20px 0;">
                    <p style="margin: 5px 0; color: #333;"><strong>Video Adı:</strong> {video_title}</p>
                    <p style="margin: 5px 0; color: #333;"><strong>Planlanan Yayın Tarihi:</strong> {scheduled_date}</p>
                    <p style="margin: 5px 0; color: #666; font-size: 13px;">Video dashboard'dan yönetebilirsiniz.</p>
                </div>

                <p style="color: #666; font-size: 14px;">
                    Sistem, planlanan tarihte video'u otomatik olarak YouTube'a yayınlayacaktır.
                </p>

                <div style="margin-top: 30px; border-top: 1px solid #e0e0e0; padding-top: 20px; color: #999; font-size: 12px;">
                    <p style="margin: 5px 0;">MRReadyPrep Video Content Management System</p>
                    <p style="margin: 5px 0;">TOEFL iBT 2026 Prep Platform</p>
                </div>
            </div>
        </body>
        </html>
        """

        return self.send_email(self.smtp_email, subject, html_content)

    def send_publish_notification(self, video_title: str, youtube_url: str) -> bool:
        """Video yayın bildirimi"""
        subject = f"Video Yayınlandı: {video_title}"

        html_content = f"""
        <html style="font-family: Arial, sans-serif;">
        <body style="background-color: #f5f5f5; margin: 0; padding: 20px;">
            <div style="max-width: 600px; margin: 0 auto; background-color: white; border-radius: 10px; padding: 30px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
                <h2 style="color: #1e3c72; margin-top: 0;">✅ Video Başarıyla Yayınlandı</h2>

                <p style="color: #333; line-height: 1.6;">
                    <strong>{video_title}</strong> başlıklı video'unuz YouTube'da yayına alındı!
                </p>

                <div style="background-color: #f0f8ff; border-left: 4px solid #4a9eff; padding: 15px; margin: 20px 0;">
                    <p style="margin: 5px 0; color: #333;"><strong>Video Adı:</strong> {video_title}</p>
                    <p style="margin: 5px 0; color: #333;"><strong>Yayın Saati:</strong> {datetime.now().strftime('%d.%m.%Y %H:%M')}</p>
                </div>

                <div style="margin: 30px 0; text-align: center;">
                    <a href="{youtube_url}"
                       style="background-color: #4a9eff; color: white; padding: 12px 30px; text-decoration: none; border-radius: 6px; display: inline-block; font-weight: bold;">
                        YouTube'da Görüntüle
                    </a>
                </div>

                <p style="color: #666; font-size: 14px;">
                    Video analytics'i dashboard'dan izleyebilirsiniz. İzleme sayısı, like oranı ve izleme süresi gibi metrikler gerçek zamanlı olarak güncellenecektir.
                </p>

                <div style="margin-top: 30px; border-top: 1px solid #e0e0e0; padding-top: 20px; color: #999; font-size: 12px;">
                    <p style="margin: 5px 0;">MRReadyPrep Video Content Management System</p>
                    <p style="margin: 5px 0;">TOEFL iBT 2026 Prep Platform</p>
                </div>
            </div>
        </body>
        </html>
        """

        return self.send_email(self.smtp_email, subject, html_content)

    def send_analytics_report(
        self,
        video_count: int,
        total_views: int,
        total_watch_time: float,
        average_like_ratio: float,
        videos: List,
    ) -> bool:
        """Haftalık analytics raporu"""
        subject = f"Haftalık Video Analytics Raporu - {datetime.now().strftime('%d.%m.%Y')}"

        video_list_html = ""
        for video in videos[:5]:  # Top 5 videos
            video_list_html += f"""
            <tr style="border-bottom: 1px solid #e0e0e0;">
                <td style="padding: 12px; color: #333;">{video.title[:40]}...</td>
                <td style="padding: 12px; text-align: center; color: #333;">{video.view_count:,}</td>
                <td style="padding: 12px; text-align: center; color: #333;">{video.like_count:,}</td>
                <td style="padding: 12px; text-align: center; color: #4a9eff;">{video.like_ratio or 0:.1f}%</td>
            </tr>
            """

        html_content = f"""
        <html style="font-family: Arial, sans-serif;">
        <body style="background-color: #f5f5f5; margin: 0; padding: 20px;">
            <div style="max-width: 700px; margin: 0 auto; background-color: white; border-radius: 10px; padding: 30px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
                <h2 style="color: #1e3c72; margin-top: 0;">📊 Haftalık Video Analytics Raporu</h2>
                <p style="color: #999; margin-top: -10px; font-size: 13px;">Son 7 gün</p>

                <div style="display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 15px; margin: 25px 0;">
                    <div style="background-color: #f0f8ff; padding: 15px; border-radius: 8px; text-align: center;">
                        <p style="color: #999; font-size: 12px; margin: 0;">Toplam İzleme</p>
                        <p style="color: #1e3c72; font-size: 28px; font-weight: bold; margin: 10px 0;">{total_views:,}</p>
                    </div>
                    <div style="background-color: #f0f8ff; padding: 15px; border-radius: 8px; text-align: center;">
                        <p style="color: #999; font-size: 12px; margin: 0;">İzleme Saati</p>
                        <p style="color: #1e3c72; font-size: 28px; font-weight: bold; margin: 10px 0;">{total_watch_time:,.0f}s</p>
                    </div>
                    <div style="background-color: #f0f8ff; padding: 15px; border-radius: 8px; text-align: center;">
                        <p style="color: #999; font-size: 12px; margin: 0;">Ort. Like Oranı</p>
                        <p style="color: #1e3c72; font-size: 28px; font-weight: bold; margin: 10px 0;">{average_like_ratio:.1f}%</p>
                    </div>
                </div>

                <h3 style="color: #333; margin-top: 30px;">En İyi Performans Gösteren Videolar</h3>
                <table style="width: 100%; border-collapse: collapse;">
                    <thead style="background-color: #f0f8ff;">
                        <tr>
                            <th style="padding: 12px; text-align: left; color: #1e3c72; font-weight: 600;">Video Adı</th>
                            <th style="padding: 12px; text-align: center; color: #1e3c72; font-weight: 600;">İzleme</th>
                            <th style="padding: 12px; text-align: center; color: #1e3c72; font-weight: 600;">Like</th>
                            <th style="padding: 12px; text-align: center; color: #1e3c72; font-weight: 600;">Like %</th>
                        </tr>
                    </thead>
                    <tbody>
                        {video_list_html}
                    </tbody>
                </table>

                <div style="margin-top: 30px; border-top: 1px solid #e0e0e0; padding-top: 20px; color: #999; font-size: 12px;">
                    <p style="margin: 5px 0;">Bu rapor otomatik olarak her Pazartesi sabahı gönderilir.</p>
                    <p style="margin: 5px 0;">MRReadyPrep Video Content Management System</p>
                </div>
            </div>
        </body>
        </html>
        """

        return self.send_email(self.smtp_email, subject, html_content)

    def send_monthly_planning_reminder(self, videos_needed: int, next_deadline: datetime) -> bool:
        """Aylık planlama hatırlatması"""
        subject = "Aylık Video İçerik Planlaması Hatırlatması"

        deadline_str = next_deadline.strftime("%d.%m.%Y")

        html_content = f"""
        <html style="font-family: Arial, sans-serif;">
        <body style="background-color: #f5f5f5; margin: 0; padding: 20px;">
            <div style="max-width: 600px; margin: 0 auto; background-color: white; border-radius: 10px; padding: 30px; box-shadow: 0 2px 8px rgba(0,0,0,0.1);">
                <h2 style="color: #1e3c72; margin-top: 0;">📅 Aylık Video Planlama Hatırlatması</h2>

                <div style="background-color: #fff8e1; border-left: 4px solid #ffc107; padding: 15px; margin: 20px 0;">
                    <p style="margin: 0; color: #856404; font-weight: bold;">Bu ay için {videos_needed} video yayınlamanız gerekiyor!</p>
                </div>

                <h3 style="color: #333; margin-top: 25px;">Yapılacaklar:</h3>
                <ul style="color: #333; line-height: 1.8;">
                    <li>Video konsepti planla ve script yaz</li>
                    <li>Video'yu çek ve düzenle</li>
                    <li>Thumbnail oluştur</li>
                    <li>YouTube metadatası hazırla (başlık, açıklama, etiketler)</li>
                    <li>Yayın takvimini güncelle</li>
                </ul>

                <div style="background-color: #f0f8ff; border-left: 4px solid #4a9eff; padding: 15px; margin: 20px 0;">
                    <p style="margin: 0; color: #333;"><strong>Hedef Tarih:</strong> {deadline_str}</p>
                    <p style="margin: 8px 0 0 0; color: #666; font-size: 13px;">Başarılı bir ay için zamanında planlama yapınız.</p>
                </div>

                <div style="margin-top: 30px; border-top: 1px solid #e0e0e0; padding-top: 20px; color: #999; font-size: 12px;">
                    <p style="margin: 5px 0;">Bu hatırlatma her ayın birinci günü gönderilir.</p>
                    <p style="margin: 5px 0;">MRReadyPrep Video Content Management System</p>
                </div>
            </div>
        </body>
        </html>
        """

        return self.send_email(self.smtp_email, subject, html_content)
