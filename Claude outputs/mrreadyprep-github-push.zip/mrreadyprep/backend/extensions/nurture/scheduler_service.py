# backend/app/services/scheduler_service.py
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.date import DateTrigger
from datetime import datetime, timedelta
from typing import List, Optional
import uuid
from sqlalchemy.orm import Session
from app.models import Video, VideoStatus, NotificationLog
from app.services.youtube_service import YouTubeService
from app.services.email_service import EmailService
import logging

logger = logging.getLogger(__name__)


class VideoSchedulerService:
    def __init__(self):
        self.scheduler = BackgroundScheduler()
        self.youtube_service = None
        self.email_service = None

    def initialize(self, youtube_service: YouTubeService, email_service: EmailService):
        """Servisleri initialize et"""
        self.youtube_service = youtube_service
        self.email_service = email_service

        if not self.scheduler.running:
            self.scheduler.start()

    def schedule_video_upload(
        self,
        video_id: str,
        file_path: str,
        title: str,
        description: str,
        tags: List[str],
        publish_date: datetime,
        channel_id: str,
        access_token: str,
        refresh_token: Optional[str],
        db: Session,
    ):
        """Video upload'ını belirli tarihte planla"""
        try:
            # Create a job for this video
            job_id = f"video_upload_{video_id}"

            def upload_task():
                self.upload_to_youtube(
                    video_id=video_id,
                    file_path=file_path,
                    title=title,
                    description=description,
                    tags=tags,
                    channel_id=channel_id,
                    access_token=access_token,
                    refresh_token=refresh_token,
                    db=db,
                )

            # Schedule at specific time
            self.scheduler.add_job(
                upload_task,
                trigger=DateTrigger(run_date=publish_date),
                id=job_id,
                name=f"Upload: {title}",
                replace_existing=True,
            )

            logger.info(f"Video upload planlandı: {video_id} - {publish_date}")

        except Exception as e:
            logger.error(f"Video scheduling hatası: {str(e)}")

    def upload_to_youtube(
        self,
        video_id: str,
        file_path: str,
        title: str,
        description: str,
        tags: List[str],
        channel_id: str,
        access_token: str,
        refresh_token: Optional[str],
        db: Session,
    ):
        """Video'yu YouTube'a yükle"""
        try:
            video = db.query(Video).filter(Video.id == video_id).first()
            if not video:
                logger.error(f"Video bulunamadı: {video_id}")
                return

            # Upload to YouTube
            result = self.youtube_service.upload_video(
                file_path=file_path,
                title=title,
                description=description,
                tags=tags,
                access_token=access_token,
                refresh_token=refresh_token,
                privacy_status="public",
            )

            if result['success']:
                # Update video record
                video.youtube_id = result['video_id']
                video.status = VideoStatus.PUBLISHED.value
                video.actual_publish_date = datetime.utcnow()
                db.commit()

                # Send notification
                self.email_service.send_publish_notification(
                    video_title=title,
                    youtube_url=f"https://youtu.be/{result['video_id']}",
                )

                logger.info(f"Video başarıyla yüklendi: {video_id}")
            else:
                logger.error(f"YouTube upload hatası: {result.get('error')}")

        except Exception as e:
            logger.error(f"Upload işlemi hatası: {str(e)}")

    def schedule_analytics_report(self, db: Session):
        """Haftalık analytics raporu planla"""
        try:
            job_id = "weekly_analytics_report"

            def report_task():
                self.send_weekly_analytics_report(db)

            # Every Monday at 9:00 AM
            self.scheduler.add_job(
                report_task,
                trigger='cron',
                day_of_week=0,  # Monday
                hour=9,
                minute=0,
                id=job_id,
                name="Weekly Analytics Report",
                replace_existing=True,
            )

            logger.info("Haftalık analytics raporu planlandı")

        except Exception as e:
            logger.error(f"Analytics raporu scheduling hatası: {str(e)}")

    def send_weekly_analytics_report(self, db: Session):
        """Haftalık analytics raporu gönder"""
        try:
            # Son 7 günün videoları
            last_week = datetime.utcnow() - timedelta(days=7)
            videos = db.query(Video).filter(
                Video.status == VideoStatus.PUBLISHED.value,
                Video.actual_publish_date >= last_week
            ).all()

            if not videos:
                return

            # Calculate metrics
            total_views = sum(v.view_count for v in videos)
            total_watch_time = sum(v.watch_time_hours for v in videos)
            avg_like_ratio = (sum(v.like_ratio or 0 for v in videos) / len(videos)) if videos else 0

            # Send report
            self.email_service.send_analytics_report(
                video_count=len(videos),
                total_views=total_views,
                total_watch_time=total_watch_time,
                average_like_ratio=avg_like_ratio,
                videos=videos,
            )

            logger.info(f"Analytics raporu gönderildi: {len(videos)} video")

        except Exception as e:
            logger.error(f"Analytics raporu gönderme hatası: {str(e)}")

    def schedule_monthly_planning_reminder(self, db: Session):
        """Aylık planlama hatırlatması"""
        try:
            job_id = "monthly_planning_reminder"

            def reminder_task():
                self.send_monthly_planning_reminder(db)

            # First day of month at 8:00 AM
            self.scheduler.add_job(
                reminder_task,
                trigger='cron',
                day=1,
                hour=8,
                minute=0,
                id=job_id,
                name="Monthly Planning Reminder",
                replace_existing=True,
            )

            logger.info("Aylık planlama hatırlatması planlandı")

        except Exception as e:
            logger.error(f"Monthly reminder scheduling hatası: {str(e)}")

    def send_monthly_planning_reminder(self, db: Session):
        """Aylık planlama hatırlatması gönder"""
        try:
            self.email_service.send_monthly_planning_reminder(
                videos_needed=4,
                next_deadline=datetime.utcnow() + timedelta(days=30),
            )

            logger.info("Aylık planlama hatırlatması gönderildi")

        except Exception as e:
            logger.error(f"Monthly reminder gönderme hatası: {str(e)}")

    def schedule_automatic_publish(self, video_id: str, publish_date: datetime, db: Session):
        """Otomatik yayın planla"""
        job_id = f"auto_publish_{video_id}"

        def publish_task():
            try:
                video = db.query(Video).filter(Video.id == video_id).first()
                if video and video.youtube_id:
                    # Mark as published
                    video.status = VideoStatus.PUBLISHED.value
                    video.actual_publish_date = datetime.utcnow()
                    db.commit()

                    logger.info(f"Video otomatik olarak yayınlandı: {video_id}")
            except Exception as e:
                logger.error(f"Otomatik yayın hatası: {str(e)}")

        self.scheduler.add_job(
            publish_task,
            trigger=DateTrigger(run_date=publish_date),
            id=job_id,
            name=f"Auto Publish: {video_id}",
            replace_existing=True,
        )

    def get_scheduled_jobs(self):
        """Planlanmış işleri al"""
        return [
            {
                "id": job.id,
                "name": job.name,
                "next_run_time": job.next_run_time.isoformat() if job.next_run_time else None,
                "trigger": str(job.trigger),
            }
            for job in self.scheduler.get_jobs()
        ]

    def remove_scheduled_job(self, job_id: str):
        """Planlanmış işi kaldır"""
        try:
            self.scheduler.remove_job(job_id)
            logger.info(f"Scheduled job kaldırıldı: {job_id}")
            return True
        except Exception as e:
            logger.error(f"Job kaldırma hatası: {str(e)}")
            return False

    def shutdown(self):
        """Scheduler'ı kapat"""
        if self.scheduler.running:
            self.scheduler.shutdown()
