"""
SEO Monitoring - Automated Cron Jobs
Handles scheduled keyword tracking, backlink updates, and report generation
"""

import os
import logging
from datetime import datetime, timedelta
from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
import asyncio
from sqlalchemy.orm import Session
from seo_monitoring import (
    SessionLocal, SEOService, engine, Base, SEOAlert, SEOReport
)
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from jinja2 import Template
import json

# Logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize database
Base.metadata.create_all(bind=engine)

class SEOCronJobs:
    """Scheduled jobs for SEO monitoring"""

    def __init__(self):
        self.scheduler = BackgroundScheduler()
        self.seo_service = SEOService()

    def sync_keywords(self):
        """Sync keyword rankings - runs daily at 2 AM"""
        logger.info("🔄 Starting keyword sync...")
        db = SessionLocal()
        try:
            asyncio.run(self.seo_service.update_keyword_rankings(db))
            logger.info("✓ Keyword sync completed")
        except Exception as e:
            logger.error(f"✗ Keyword sync error: {e}")
            alert = SEOAlert(
                alert_type="sync_error",
                message=f"Keyword sync failed: {str(e)}",
                severity="warning",
            )
            db.add(alert)
            db.commit()
        finally:
            db.close()

    def sync_backlinks(self):
        """Sync backlinks - runs every Sunday at 3 AM"""
        logger.info("🔗 Starting backlink sync...")
        db = SessionLocal()
        try:
            asyncio.run(self.seo_service.update_backlinks(db))
            logger.info("✓ Backlink sync completed")
        except Exception as e:
            logger.error(f"✗ Backlink sync error: {e}")
            alert = SEOAlert(
                alert_type="sync_error",
                message=f"Backlink sync failed: {str(e)}",
                severity="warning",
            )
            db.add(alert)
            db.commit()
        finally:
            db.close()

    def generate_monthly_report(self):
        """Generate monthly report - runs on 1st of month at 4 AM"""
        logger.info("📊 Generating monthly SEO report...")
        db = SessionLocal()
        try:
            # Get last month
            today = datetime.now()
            first_day = today.replace(day=1)
            last_month = (first_day - timedelta(days=1)).strftime("%Y-%m")

            report_data = asyncio.run(
                self.seo_service.generate_monthly_report(db, last_month)
            )

            # Send email report
            self._send_email_report(report_data)
            logger.info(f"✓ Monthly report generated for {last_month}")
        except Exception as e:
            logger.error(f"✗ Report generation error: {e}")
        finally:
            db.close()

    def cleanup_old_data(self):
        """Cleanup old data - runs weekly on Monday at 5 AM"""
        logger.info("🧹 Cleaning up old data...")
        db = SessionLocal()
        try:
            # Keep 90 days of keyword data
            cutoff_date = datetime.utcnow() - timedelta(days=90)
            from seo_monitoring import SEOKeyword

            deleted_count = db.query(SEOKeyword).filter(
                SEOKeyword.tracked_date < cutoff_date
            ).delete()
            db.commit()

            logger.info(f"✓ Deleted {deleted_count} old keyword records")
        except Exception as e:
            logger.error(f"✗ Cleanup error: {e}")
        finally:
            db.close()

    def _send_email_report(self, report_data):
        """Send monthly report via email"""
        try:
            smtp_server = os.getenv("SMTP_SERVER", "smtp.gmail.com")
            smtp_port = int(os.getenv("SMTP_PORT", 587))
            smtp_user = os.getenv("SMTP_USER")
            smtp_password = os.getenv("SMTP_PASSWORD")
            email_from = os.getenv("EMAIL_FROM")
            email_to = os.getenv("EMAIL_TO")

            if not all([smtp_user, smtp_password, email_from, email_to]):
                logger.warning("Email configuration incomplete, skipping report email")
                return

            # Create email
            msg = MIMEMultipart("alternative")
            msg["Subject"] = f"SEO Monthly Report - {report_data['month']}"
            msg["From"] = email_from
            msg["To"] = email_to

            # HTML email template
            html_template = """
            <html>
              <body style="font-family: Arial, sans-serif; color: #333;">
                <h2>SEO Monthly Report - {month}</h2>

                <h3>Key Metrics</h3>
                <table border="1" cellpadding="10" style="border-collapse: collapse;">
                  <tr style="background-color: #f0f0f0;">
                    <td><strong>Metric</strong></td>
                    <td><strong>Value</strong></td>
                  </tr>
                  <tr>
                    <td>Total Impressions</td>
                    <td>{impressions:,}</td>
                  </tr>
                  <tr>
                    <td>Total Clicks</td>
                    <td>{clicks:,}</td>
                  </tr>
                  <tr>
                    <td>Average Position</td>
                    <td>{avg_position}</td>
                  </tr>
                  <tr>
                    <td>Average CTR</td>
                    <td>{avg_ctr}%</td>
                  </tr>
                  <tr>
                    <td>Backlink Count</td>
                    <td>{backlink_count}</td>
                  </tr>
                  <tr>
                    <td>High Quality Backlinks (DA 40+)</td>
                    <td>{high_quality_backlinks}</td>
                  </tr>
                </table>

                <h3>Top 5 Keywords</h3>
                <table border="1" cellpadding="10" style="border-collapse: collapse; margin-top: 10px;">
                  <tr style="background-color: #f0f0f0;">
                    <td><strong>Keyword</strong></td>
                    <td><strong>Position</strong></td>
                    <td><strong>Impressions</strong></td>
                    <td><strong>Clicks</strong></td>
                  </tr>
                  {keywords_rows}
                </table>

                <p style="margin-top: 20px; font-size: 12px; color: #666;">
                  This is an automated report generated by MRReadyPrep SEO Monitoring System.
                </p>
              </body>
            </html>
            """

            # Build keywords table rows
            keywords_rows = ""
            for kw in report_data["metrics"].get("top_keywords", [])[:5]:
                keywords_rows += f"""
                <tr>
                  <td>{kw['keyword']}</td>
                  <td>{kw['position']}</td>
                  <td>{kw['impressions']:,}</td>
                  <td>{kw['clicks']:,}</td>
                </tr>
                """

            metrics = report_data.get("metrics", {})
            html_content = html_template.format(
                month=report_data.get("month"),
                impressions=metrics.get("total_impressions", 0),
                clicks=metrics.get("total_clicks", 0),
                avg_position=metrics.get("avg_position", 0),
                avg_ctr=metrics.get("avg_ctr", 0),
                backlink_count=metrics.get("backlink_count", 0),
                high_quality_backlinks=metrics.get("high_quality_backlinks", 0),
                keywords_rows=keywords_rows,
            )

            msg.attach(MIMEText(html_content, "html"))

            # Send email
            with smtplib.SMTP(smtp_server, smtp_port) as server:
                server.starttls()
                server.login(smtp_user, smtp_password)
                server.send_message(msg)

            logger.info(f"✓ Report email sent to {email_to}")
        except Exception as e:
            logger.error(f"✗ Email sending error: {e}")

    def start(self):
        """Start all scheduled jobs"""
        # Keyword sync - Daily at 2 AM
        self.scheduler.add_job(
            self.sync_keywords,
            CronTrigger(hour=2, minute=0),
            id="sync_keywords",
            name="Sync Keywords",
            replace_existing=True,
        )

        # Backlink sync - Sunday at 3 AM
        self.scheduler.add_job(
            self.sync_backlinks,
            CronTrigger(day_of_week=6, hour=3, minute=0),  # Sunday
            id="sync_backlinks",
            name="Sync Backlinks",
            replace_existing=True,
        )

        # Monthly report - 1st of month at 4 AM
        self.scheduler.add_job(
            self.generate_monthly_report,
            CronTrigger(day=1, hour=4, minute=0),
            id="generate_monthly_report",
            name="Generate Monthly Report",
            replace_existing=True,
        )

        # Weekly cleanup - Monday at 5 AM
        self.scheduler.add_job(
            self.cleanup_old_data,
            CronTrigger(day_of_week=0, hour=5, minute=0),  # Monday
            id="cleanup_old_data",
            name="Cleanup Old Data",
            replace_existing=True,
        )

        self.scheduler.start()
        logger.info("✓ SEO Cron Jobs started")

    def stop(self):
        """Stop scheduler"""
        self.scheduler.shutdown()
        logger.info("SEO Cron Jobs stopped")


# Standalone runner
if __name__ == "__main__":
    import signal

    cron_jobs = SEOCronJobs()
    cron_jobs.start()

    def signal_handler(sig, frame):
        logger.info("\nShutting down...")
        cron_jobs.stop()
        exit(0)

    signal.signal(signal.SIGINT, signal_handler)

    logger.info("SEO Cron Jobs server running. Press Ctrl+C to stop.")
    try:
        while True:
            pass
    except KeyboardInterrupt:
        cron_jobs.stop()
