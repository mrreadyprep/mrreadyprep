"""
SEO Monitoring System for MRReadyPrep
- Google Search Console API integration
- Keyword ranking tracking
- Backlink monitoring (ahrefs)
- Monthly SEO reports
"""

import os
import json
import logging
from datetime import datetime, timedelta
from typing import Optional, List, Dict
import asyncio
import aiohttp
from sqlalchemy import Column, String, Integer, Float, DateTime, JSON, create_engine
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
from fastapi import FastAPI, HTTPException, Depends
from fastapi.responses import JSONResponse
import requests
from google.oauth2.credentials import Credentials
from google.auth.transport.requests import Request
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
import jinja2

# Logging setup
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Database setup
DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./seo_monitoring.db")
engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False} if "sqlite" in DATABASE_URL else {})
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# ============= Database Models =============

class SEOKeyword(Base):
    """Track keyword rankings over time"""
    __tablename__ = "seo_keywords"

    id = Column(Integer, primary_key=True, index=True)
    keyword = Column(String, index=True)
    position = Column(Integer)
    impressions = Column(Integer, default=0)
    clicks = Column(Integer, default=0)
    ctr = Column(Float, default=0.0)
    change = Column(Integer, default=0)  # Position change vs last tracking
    tracked_date = Column(DateTime, default=datetime.utcnow, index=True)

class SEOBacklink(Base):
    """Track backlinks"""
    __tablename__ = "seo_backlinks"

    id = Column(Integer, primary_key=True, index=True)
    domain = Column(String, index=True, unique=True)
    anchor_text = Column(String)
    domain_authority = Column(Integer)
    page_authority = Column(Integer)
    first_seen = Column(DateTime, default=datetime.utcnow)
    last_seen = Column(DateTime, default=datetime.utcnow)
    is_active = Column(Integer, default=1)

class SEOAlert(Base):
    """Track SEO alerts"""
    __tablename__ = "seo_alerts"

    id = Column(Integer, primary_key=True, index=True)
    alert_type = Column(String)  # "ranking_drop", "new_backlink", etc.
    keyword = Column(String, nullable=True)
    message = Column(String)
    severity = Column(String)  # "info", "warning", "critical"
    created_at = Column(DateTime, default=datetime.utcnow)
    is_read = Column(Integer, default=0)

class SEOReport(Base):
    """Store monthly SEO reports"""
    __tablename__ = "seo_reports"

    id = Column(Integer, primary_key=True, index=True)
    month = Column(String, unique=True)
    data = Column(JSON)
    created_at = Column(DateTime, default=datetime.utcnow)

# Create tables
Base.metadata.create_all(bind=engine)

# ============= Google Search Console Integration =============

class GoogleSearchConsoleAPI:
    """Wrapper for Google Search Console API"""

    SCOPES = ['https://www.googleapis.com/auth/webmasters.readonly']

    def __init__(self, credentials_file: str = "credentials.json"):
        self.credentials_file = credentials_file
        self.service = None
        self.property_url = os.getenv("GSC_PROPERTY_URL", "https://mrreadyprep.com/")

    def authenticate(self):
        """Authenticate with Google Search Console API"""
        try:
            creds = None
            if os.path.exists("token.json"):
                creds = Credentials.from_authorized_user_file("token.json", self.SCOPES)

            if not creds or not creds.valid:
                if creds and creds.expired and creds.refresh_token:
                    creds.refresh(Request())
                else:
                    flow = InstalledAppFlow.from_client_secrets_file(
                        self.credentials_file, self.SCOPES
                    )
                    creds = flow.run_local_server(port=0)

                with open("token.json", "w") as token:
                    token.write(creds.to_json())

            self.service = build("webmasters", "v3", credentials=creds)
            logger.info("✓ Google Search Console authenticated")
            return True
        except Exception as e:
            logger.error(f"✗ GSC Authentication failed: {e}")
            return False

    def get_search_performance(self, days: int = 30) -> List[Dict]:
        """Fetch search performance data from GSC"""
        try:
            end_date = datetime.now().date()
            start_date = end_date - timedelta(days=days)

            body = {
                "startDate": start_date.isoformat(),
                "endDate": end_date.isoformat(),
                "dimensions": ["query", "page", "device"],
                "rowLimit": 25000,
            }

            response = self.service.searchanalytics().query(
                siteUrl=self.property_url, body=body
            ).execute()

            return response.get("rows", [])
        except Exception as e:
            logger.error(f"✗ Error fetching GSC data: {e}")
            return []

    def get_top_keywords(self, limit: int = 10) -> List[Dict]:
        """Get top performing keywords"""
        try:
            end_date = datetime.now().date()
            start_date = end_date - timedelta(days=30)

            body = {
                "startDate": start_date.isoformat(),
                "endDate": end_date.isoformat(),
                "dimensions": ["query"],
                "rowLimit": limit,
                "orderBy": [{"direction": "descending", "columnName": "impressions"}],
            }

            response = self.service.searchanalytics().query(
                siteUrl=self.property_url, body=body
            ).execute()

            return response.get("rows", [])
        except Exception as e:
            logger.error(f"✗ Error fetching top keywords: {e}")
            return []

# ============= Backlink Monitoring (Ahrefs API) =============

class AhrefsAPI:
    """Wrapper for Ahrefs API"""

    def __init__(self, api_key: str = None):
        self.api_key = api_key or os.getenv("AHREFS_API_KEY")
        self.base_url = "https://api.ahrefs.com/v3"

    async def get_backlinks(self, target: str = "mrreadyprep.com") -> List[Dict]:
        """Fetch backlinks for domain"""
        if not self.api_key:
            logger.warning("⚠ Ahrefs API key not configured")
            return []

        try:
            async with aiohttp.ClientSession() as session:
                url = f"{self.base_url}/backlinks"
                params = {
                    "target": target,
                    "token": self.api_key,
                    "limit": 100,
                    "order_by": "domain_rating:desc",
                }

                async with session.get(url, params=params, timeout=10) as response:
                    if response.status == 200:
                        data = await response.json()
                        return data.get("backlinks", [])
                    else:
                        logger.error(f"Ahrefs API error: {response.status}")
                        return []
        except Exception as e:
            logger.error(f"✗ Error fetching backlinks: {e}")
            return []

    async def get_domain_rating(self, domain: str = "mrreadyprep.com") -> Optional[int]:
        """Get domain rating"""
        if not self.api_key:
            return None

        try:
            async with aiohttp.ClientSession() as session:
                url = f"{self.base_url}/metrics"
                params = {
                    "target": domain,
                    "token": self.api_key,
                }

                async with session.get(url, params=params, timeout=10) as response:
                    if response.status == 200:
                        data = await response.json()
                        return data.get("domain_rating")
        except Exception as e:
            logger.error(f"Error getting domain rating: {e}")
        return None

# ============= SEO Service =============

class SEOService:
    """Main SEO monitoring service"""

    def __init__(self):
        self.gsc = GoogleSearchConsoleAPI()
        self.ahrefs = AhrefsAPI()

    async def update_keyword_rankings(self, db: Session):
        """Fetch latest keyword rankings from GSC"""
        if not self.gsc.authenticate():
            return

        keywords = self.gsc.get_top_keywords(limit=20)

        for kw_data in keywords:
            query = kw_data.get("keys", [None])[0]
            if not query:
                continue

            # Get last position for change calculation
            last_keyword = db.query(SEOKeyword).filter(
                SEOKeyword.keyword == query
            ).order_by(SEOKeyword.tracked_date.desc()).first()

            position = kw_data.get("position", 0)
            change = 0
            if last_keyword:
                change = last_keyword.position - position

                # Create alert for significant drops
                if change < -3:
                    alert = SEOAlert(
                        alert_type="ranking_drop",
                        keyword=query,
                        message=f"Keyword '{query}' dropped from {last_keyword.position} to {position}",
                        severity="critical",
                    )
                    db.add(alert)

            # Add new keyword record
            keyword = SEOKeyword(
                keyword=query,
                position=position,
                impressions=kw_data.get("impressions", 0),
                clicks=kw_data.get("clicks", 0),
                ctr=kw_data.get("ctr", 0.0),
                change=change,
            )
            db.add(keyword)

        db.commit()
        logger.info(f"✓ Updated {len(keywords)} keyword rankings")

    async def update_backlinks(self, db: Session):
        """Fetch latest backlinks"""
        backlinks = await self.ahrefs.get_backlinks()

        for backlink in backlinks:
            existing = db.query(SEOBacklink).filter(
                SEOBacklink.domain == backlink.get("source_domain")
            ).first()

            if existing:
                existing.last_seen = datetime.utcnow()
            else:
                new_backlink = SEOBacklink(
                    domain=backlink.get("source_domain"),
                    anchor_text=backlink.get("anchor"),
                    domain_authority=backlink.get("domain_rating", 0),
                    page_authority=backlink.get("page_rating", 0),
                )
                db.add(new_backlink)

                # Alert for new high-quality backlinks
                if backlink.get("domain_rating", 0) >= 40:
                    alert = SEOAlert(
                        alert_type="new_backlink",
                        message=f"New high-quality backlink from {backlink.get('source_domain')} (DA: {backlink.get('domain_rating')})",
                        severity="info",
                    )
                    db.add(alert)

        db.commit()
        logger.info(f"✓ Updated {len(backlinks)} backlinks")

    async def generate_monthly_report(self, db: Session, month: str = None) -> Dict:
        """Generate monthly SEO report"""
        if not month:
            month = datetime.now().strftime("%Y-%m")

        # Get monthly metrics
        start_date = datetime.strptime(f"{month}-01", "%Y-%m-%d")
        if month.endswith("-12"):
            end_date = datetime(int(month.split("-")[0]) + 1, 1, 1)
        else:
            end_date = datetime(int(month.split("-")[0]), int(month.split("-")[1]) + 1, 1)

        keywords = db.query(SEOKeyword).filter(
            SEOKeyword.tracked_date >= start_date,
            SEOKeyword.tracked_date < end_date
        ).all()

        backlinks = db.query(SEOBacklink).filter(
            SEOBacklink.is_active == 1
        ).all()

        # Calculate metrics
        total_impressions = sum(k.impressions for k in keywords)
        total_clicks = sum(k.clicks for k in keywords)
        avg_position = sum(k.position for k in keywords) / len(keywords) if keywords else 0
        avg_ctr = total_clicks / total_impressions * 100 if total_impressions > 0 else 0

        top_keywords = sorted(keywords, key=lambda x: x.impressions, reverse=True)[:5]
        high_da_backlinks = [b for b in backlinks if b.domain_authority >= 40]

        report_data = {
            "month": month,
            "metrics": {
                "total_impressions": total_impressions,
                "total_clicks": total_clicks,
                "avg_position": round(avg_position, 1),
                "avg_ctr": round(avg_ctr, 2),
                "backlink_count": len(backlinks),
                "high_quality_backlinks": len(high_da_backlinks),
            },
            "top_keywords": [
                {
                    "keyword": k.keyword,
                    "position": k.position,
                    "impressions": k.impressions,
                    "clicks": k.clicks,
                }
                for k in top_keywords
            ],
            "backlinks_sample": [
                {
                    "domain": b.domain,
                    "da": b.domain_authority,
                    "pa": b.page_authority,
                }
                for b in backlinks[:10]
            ],
        }

        # Save report to database
        existing_report = db.query(SEOReport).filter(SEOReport.month == month).first()
        if existing_report:
            existing_report.data = report_data
        else:
            report = SEOReport(month=month, data=report_data)
            db.add(report)

        db.commit()
        return report_data

# ============= FastAPI App =============

app = FastAPI(title="SEO Monitoring API", version="1.0.0")
seo_service = SEOService()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# ============= API Endpoints =============

@app.on_event("startup")
async def startup_event():
    """Initialize on startup"""
    logger.info("SEO Monitoring API starting...")

@app.get("/api/seo/keywords")
async def get_keywords(days: int = 30, limit: int = 20, db: Session = Depends(get_db)):
    """Get top keywords with rankings"""
    end_date = datetime.utcnow()
    start_date = end_date - timedelta(days=days)

    keywords = db.query(SEOKeyword).filter(
        SEOKeyword.tracked_date >= start_date
    ).order_by(
        SEOKeyword.impressions.desc()
    ).limit(limit).all()

    return {
        "keywords": [
            {
                "keyword": k.keyword,
                "position": k.position,
                "change": k.change,
                "impressions": k.impressions,
                "clicks": k.clicks,
                "ctr": round(k.ctr, 2),
            }
            for k in keywords
        ],
        "total": len(keywords),
    }

@app.get("/api/seo/performance")
async def get_performance(days: int = 30, db: Session = Depends(get_db)):
    """Get monthly performance metrics"""
    end_date = datetime.utcnow()
    start_date = end_date - timedelta(days=days)

    keywords = db.query(SEOKeyword).filter(
        SEOKeyword.tracked_date >= start_date
    ).all()

    total_impressions = sum(k.impressions for k in keywords)
    total_clicks = sum(k.clicks for k in keywords)
    avg_position = sum(k.position for k in keywords) / len(keywords) if keywords else 0
    ctr = total_clicks / total_impressions * 100 if total_impressions > 0 else 0

    # Group by date for trend
    daily_data = {}
    for k in keywords:
        date = k.tracked_date.date().isoformat()
        if date not in daily_data:
            daily_data[date] = {"impressions": 0, "clicks": 0}
        daily_data[date]["impressions"] += k.impressions
        daily_data[date]["clicks"] += k.clicks

    return {
        "metrics": {
            "impressions": total_impressions,
            "clicks": total_clicks,
            "avg_position": round(avg_position, 1),
            "ctr": round(ctr, 2),
        },
        "daily_data": daily_data,
    }

@app.get("/api/seo/backlinks")
async def get_backlinks(limit: int = 50, db: Session = Depends(get_db)):
    """Get backlink data"""
    backlinks = db.query(SEOBacklink).filter(
        SEOBacklink.is_active == 1
    ).order_by(
        SEOBacklink.domain_authority.desc()
    ).limit(limit).all()

    high_quality = len([b for b in backlinks if b.domain_authority >= 40])

    return {
        "backlinks": [
            {
                "domain": b.domain,
                "anchor": b.anchor_text,
                "da": b.domain_authority,
                "pa": b.page_authority,
                "first_seen": b.first_seen.isoformat(),
            }
            for b in backlinks
        ],
        "total": len(backlinks),
        "high_quality": high_quality,
    }

@app.get("/api/seo/alerts")
async def get_alerts(limit: int = 20, unread_only: bool = False, db: Session = Depends(get_db)):
    """Get SEO alerts"""
    query = db.query(SEOAlert)

    if unread_only:
        query = query.filter(SEOAlert.is_read == 0)

    alerts = query.order_by(SEOAlert.created_at.desc()).limit(limit).all()

    return {
        "alerts": [
            {
                "id": a.id,
                "type": a.alert_type,
                "keyword": a.keyword,
                "message": a.message,
                "severity": a.severity,
                "created_at": a.created_at.isoformat(),
                "is_read": a.is_read == 1,
            }
            for a in alerts
        ],
        "total": len(alerts),
    }

@app.post("/api/seo/alerts/{alert_id}/read")
async def mark_alert_read(alert_id: int, db: Session = Depends(get_db)):
    """Mark alert as read"""
    alert = db.query(SEOAlert).filter(SEOAlert.id == alert_id).first()
    if not alert:
        raise HTTPException(status_code=404, detail="Alert not found")

    alert.is_read = 1
    db.commit()
    return {"status": "success"}

@app.get("/api/seo/report")
async def get_report(month: str = None, db: Session = Depends(get_db)):
    """Get monthly SEO report"""
    if not month:
        month = datetime.now().strftime("%Y-%m")

    report = db.query(SEOReport).filter(SEOReport.month == month).first()

    if not report:
        # Generate if not exists
        report_data = await seo_service.generate_monthly_report(db, month)
        return {"month": month, **report_data}

    return {"month": month, **report.data}

@app.post("/api/seo/sync")
async def sync_seo_data(db: Session = Depends(get_db)):
    """Manually trigger SEO data sync"""
    try:
        await seo_service.update_keyword_rankings(db)
        await seo_service.update_backlinks(db)

        return {
            "status": "success",
            "message": "SEO data synced successfully",
            "timestamp": datetime.utcnow().isoformat(),
        }
    except Exception as e:
        logger.error(f"Sync error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "timestamp": datetime.utcnow().isoformat()}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
