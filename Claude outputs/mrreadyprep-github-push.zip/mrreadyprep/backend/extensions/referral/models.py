"""
Referral Program Models (SQLAlchemy + Pydantic)
Add to backend/models.py or create as separate file
"""

from datetime import datetime
from typing import Optional, List
from decimal import Decimal
from uuid import UUID
from sqlalchemy import Column, String, Integer, Boolean, DateTime, Numeric, ForeignKey, Text, Date, JSON, Index, UniqueConstraint
from sqlalchemy.dialects.postgresql import UUID as PG_UUID
from sqlalchemy.orm import relationship
import uuid
import random
import string
from pydantic import BaseModel, Field


# ==================== SQLAlchemy Models ====================

class Referral(Base):
    """Referral tracking model"""
    __tablename__ = "referrals"

    id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    referrer_user_id = Column(PG_UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    referred_user_id = Column(PG_UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), index=True)
    referral_code = Column(String(12), unique=True, nullable=False, index=True)
    status = Column(String(50), default="pending", index=True)  # pending, converted, paid
    conversion_date = Column(DateTime, nullable=True)
    reward_amount = Column(Numeric(10, 2), default=Decimal("5.00"))
    is_paid = Column(Boolean, default=False)
    paid_date = Column(DateTime, nullable=True)
    utm_source = Column(String(100), nullable=True)
    utm_medium = Column(String(100), nullable=True)
    utm_campaign = Column(String(100), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, index=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Relationships
    referrer = relationship("User", foreign_keys=[referrer_user_id], backref="referrals_created")
    referred = relationship("User", foreign_keys=[referred_user_id], backref="referrals_received")

    __table_args__ = (
        Index('idx_referrals_status_created', 'status', 'created_at'),
    )


class ReferralCredit(Base):
    """Referral credit balance tracking"""
    __tablename__ = "referral_credits"

    id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(PG_UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, unique=True, index=True)
    balance = Column(Numeric(10, 2), default=Decimal("0.00"))
    reserved_amount = Column(Numeric(10, 2), default=Decimal("0.00"))
    total_earned = Column(Numeric(10, 2), default=Decimal("0.00"))
    total_redeemed = Column(Numeric(10, 2), default=Decimal("0.00"))
    last_updated = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    user = relationship("User", backref="referral_credit")


class ReferralTransaction(Base):
    """Transaction audit trail for referral credits"""
    __tablename__ = "referral_transactions"

    id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(PG_UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    referral_id = Column(PG_UUID(as_uuid=True), ForeignKey("referrals.id", ondelete="SET NULL"), nullable=True)
    type = Column(String(50), index=True)  # credit, redemption, payout, adjustment
    amount = Column(Numeric(10, 2), nullable=False)
    description = Column(Text, nullable=True)
    metadata = Column(JSON, default={})
    created_at = Column(DateTime, default=datetime.utcnow, index=True)

    user = relationship("User", backref="referral_transactions")
    referral = relationship("Referral", backref="transactions")

    __table_args__ = (
        Index('idx_referral_transactions_user', 'user_id', 'created_at'),
    )


class ReferralPayout(Base):
    """Payout requests and tracking"""
    __tablename__ = "referral_payouts"

    id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(PG_UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    amount = Column(Numeric(10, 2), nullable=False)
    status = Column(String(50), default="pending", index=True)  # pending, processing, completed, failed
    payout_method = Column(String(50))  # stripe, bank_transfer, paypal, credit
    stripe_payout_id = Column(String(100), nullable=True)
    notes = Column(Text, nullable=True)
    requested_at = Column(DateTime, default=datetime.utcnow)
    processed_at = Column(DateTime, nullable=True)
    completed_at = Column(DateTime, nullable=True)
    error_message = Column(Text, nullable=True)

    user = relationship("User", backref="referral_payouts")

    __table_args__ = (
        Index('idx_referral_payouts_status', 'status', 'requested_at'),
    )


class ReferralAnalytics(Base):
    """Daily analytics snapshot"""
    __tablename__ = "referral_analytics"

    id = Column(PG_UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    date = Column(Date, default=datetime.utcnow().date(), unique=True)
    total_referrals = Column(Integer, default=0)
    new_conversions = Column(Integer, default=0)
    total_credits_issued = Column(Numeric(10, 2), default=Decimal("0.00"))
    total_discounts_used = Column(Numeric(10, 2), default=Decimal("0.00"))
    unique_referrers = Column(Integer, default=0)
    conversion_rate = Column(Numeric(5, 2), default=Decimal("0.00"))
    average_referrals_per_user = Column(Numeric(10, 2), default=Decimal("0.00"))
    created_at = Column(DateTime, default=datetime.utcnow)


# ==================== Pydantic Schemas ====================

class ReferralBase(BaseModel):
    """Base referral schema"""
    reward_amount: Decimal = Decimal("5.00")
    utm_source: Optional[str] = None
    utm_medium: Optional[str] = None
    utm_campaign: Optional[str] = None


class ReferralCreate(ReferralBase):
    """Create referral link"""
    pass


class ReferralResponse(ReferralBase):
    """Referral response"""
    id: UUID
    referrer_user_id: UUID
    referred_user_id: Optional[UUID]
    referral_code: str
    status: str
    conversion_date: Optional[datetime]
    is_paid: bool
    paid_date: Optional[datetime]
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True


class ReferralStatsResponse(BaseModel):
    """User referral statistics"""
    total_referrals: int
    converted_referrals: int
    pending_referrals: int
    total_earnings: Decimal
    available_credit: Decimal
    reserved_amount: Decimal
    conversion_rate: float
    top_referrer_rank: Optional[int]
    referral_code: str

    class Config:
        json_encoders = {Decimal: float}


class ReferralHistoryItem(BaseModel):
    """Individual referral in history"""
    id: UUID
    referred_user_email: Optional[str]
    status: str
    reward_amount: Decimal
    created_at: datetime
    conversion_date: Optional[datetime]
    is_paid: bool

    class Config:
        from_attributes = True
        json_encoders = {Decimal: float}


class ReferralHistoryResponse(BaseModel):
    """Referral history with pagination"""
    referrals: List[ReferralHistoryItem]
    total_count: int
    page: int
    per_page: int
    total_pages: int


class LeaderboardEntry(BaseModel):
    """Leaderboard entry"""
    rank: int
    user_id: UUID
    user_name: str
    user_avatar: Optional[str]
    total_referrals: int
    total_earnings: Decimal
    conversion_rate: float

    class Config:
        json_encoders = {Decimal: float}


class LeaderboardResponse(BaseModel):
    """Leaderboard response"""
    entries: List[LeaderboardEntry]
    user_rank: Optional[int]
    user_earnings: Decimal
    generated_at: datetime

    class Config:
        json_encoders = {Decimal: float}


class ReferralValidationResponse(BaseModel):
    """Validation response"""
    is_valid: bool
    is_already_used: bool
    referrer_name: Optional[str]
    referrer_avatar: Optional[str]
    discount_amount: Decimal
    message: str

    class Config:
        json_encoders = {Decimal: float}


class ReferralLinkResponse(BaseModel):
    """Generated referral link response"""
    referral_code: str
    referral_url: str
    qr_code_url: str
    share_text: str


class ReferralCreditBalance(BaseModel):
    """Credit balance response"""
    balance: Decimal
    reserved_amount: Decimal
    total_earned: Decimal
    total_redeemed: Decimal
    last_updated: datetime

    class Config:
        json_encoders = {Decimal: float}


class ReferralTransactionResponse(BaseModel):
    """Transaction response"""
    id: UUID
    type: str
    amount: Decimal
    description: Optional[str]
    created_at: datetime

    class Config:
        from_attributes = True
        json_encoders = {Decimal: float}


class PayoutRequestCreate(BaseModel):
    """Payout request"""
    amount: Decimal
    payout_method: str = "stripe"  # stripe, bank_transfer, paypal, credit


class PayoutResponse(BaseModel):
    """Payout response"""
    id: UUID
    amount: Decimal
    status: str
    payout_method: str
    requested_at: datetime
    processed_at: Optional[datetime]
    completed_at: Optional[datetime]
    error_message: Optional[str]

    class Config:
        from_attributes = True
        json_encoders = {Decimal: float}


class ReferralAnalyticsResponse(BaseModel):
    """Analytics data"""
    date: str
    total_referrals: int
    new_conversions: int
    total_credits_issued: Decimal
    total_discounts_used: Decimal
    unique_referrers: int
    conversion_rate: Decimal
    average_referrals_per_user: Decimal

    class Config:
        json_encoders = {Decimal: float}


class AnomalyFlagData(BaseModel):
    """Fraud detection anomaly"""
    user_id: UUID
    referral_id: Optional[UUID]
    anomaly_type: str  # duplicate_ip, rapid_conversions, proxy_usage, suspicious_pattern
    severity: str  # low, medium, high
    details: dict
    flagged_at: datetime
