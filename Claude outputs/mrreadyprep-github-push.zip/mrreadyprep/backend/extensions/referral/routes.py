"""
Referral Program API Routes (FastAPI)
Add to backend/main.py or create as blueprint

Endpoints:
- POST /api/referrals/generate-link - Create referral link
- GET /api/referrals/stats - User referral stats
- GET /api/referrals/history - Referral history with pagination
- POST /api/referrals/validate - Validate referral code
- GET /api/referrals/leaderboard - Top referrers
- POST /api/referrals/claim-credit - Claim and apply credit
- GET /api/referrals/balance - Credit balance
- GET /api/referrals/transactions - Transaction history
- POST /api/referrals/request-payout - Request payout
- GET /api/referrals/analytics - Referral analytics
- POST /api/referrals/webhook/conversion - Conversion webhook (internal)
"""

from fastapi import APIRouter, Depends, HTTPException, status, Query, Header
from sqlalchemy.orm import Session
from sqlalchemy import func, and_, or_, desc
from decimal import Decimal
from datetime import datetime, timedelta
from typing import Optional
import uuid
import hashlib
import qrcode
import io
import base64
from urllib.parse import urlencode
import httpx

from .models import (
    Referral, ReferralCredit, ReferralTransaction, ReferralPayout,
    ReferralAnalytics, User
)
from .schemas import (
    ReferralLinkResponse, ReferralStatsResponse, ReferralHistoryResponse,
    ReferralValidationResponse, LeaderboardResponse, LeaderboardEntry,
    ReferralCreditBalance, ReferralTransactionResponse, PayoutResponse,
    ReferralAnalyticsResponse
)
from .database import get_db
from .auth import get_current_user

router = APIRouter(prefix="/api/referrals", tags=["referrals"])

# Constants
REFERRAL_REWARD = Decimal("5.00")
REFERRAL_DISCOUNT_PERCENT = 50
REFERRAL_DISCOUNT_DURATION_DAYS = 30
MIN_PAYOUT_AMOUNT = Decimal("20.00")
MAX_REFERRALS_PER_DAY = 100
REFERRAL_BASE_URL = "https://mrreadyprep.com"


def generate_referral_code() -> str:
    """Generate unique referral code"""
    code = ''.join([str(uuid.uuid4().hex[:8]).upper()])
    return code


def generate_qr_code(url: str) -> str:
    """Generate QR code and return as base64"""
    try:
        qr = qrcode.QRCode(version=1, box_size=10, border=4)
        qr.add_data(url)
        qr.make(fit=True)

        img = qr.make_image(fill_color="black", back_color="white")
        img_io = io.BytesIO()
        img.save(img_io, format='PNG')
        img_io.seek(0)

        qr_base64 = base64.b64encode(img_io.getvalue()).decode()
        return f"data:image/png;base64,{qr_base64}"
    except Exception as e:
        return ""


def detect_fraud_anomaly(db: Session, user_id: uuid.UUID, ip_address: str) -> Optional[dict]:
    """
    Detect potential fraud patterns
    Returns dict if anomaly detected, None otherwise
    """

    # Check 1: Rapid conversions from same IP
    recent_referrals = db.query(Referral).filter(
        and_(
            Referral.referrer_user_id == user_id,
            Referral.created_at > datetime.utcnow() - timedelta(hours=1)
        )
    ).count()

    if recent_referrals > 5:  # More than 5 referrals in 1 hour
        return {
            "type": "rapid_conversions",
            "severity": "high",
            "details": {"conversions_in_1h": recent_referrals}
        }

    # Check 2: Duplicate IPs across different users
    referrals_same_ip = db.query(Referral).filter(
        and_(
            Referral.referrer_user_id != user_id,
            Referral.utm_source == ip_address
        )
    ).count()

    if referrals_same_ip > 3:
        return {
            "type": "duplicate_ip",
            "severity": "medium",
            "details": {"referrals_from_ip": referrals_same_ip}
        }

    # Check 3: Same referral link converted multiple times (unlikely)
    # This would be checked at conversion time

    return None


# ==================== Endpoints ====================

@router.post("/generate-link", response_model=ReferralLinkResponse)
async def generate_referral_link(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Generate unique referral link for authenticated user"""

    # Check if user already has a referral code
    if current_user.referral_code:
        code = current_user.referral_code
    else:
        # Generate new code
        code = generate_referral_code()

        # Ensure uniqueness
        while db.query(User).filter(User.referral_code == code).first():
            code = generate_referral_code()

        current_user.referral_code = code
        db.commit()

    # Build referral URL
    referral_url = f"{REFERRAL_BASE_URL}?ref={code}"

    # Generate QR code
    qr_code_url = generate_qr_code(referral_url)

    # Default share text
    share_text = f"Join MRReadyPrep TOEFL prep! Use my referral code and get 50% off. {referral_url}"

    return ReferralLinkResponse(
        referral_code=code,
        referral_url=referral_url,
        qr_code_url=qr_code_url,
        share_text=share_text
    )


@router.get("/stats", response_model=ReferralStatsResponse)
async def get_referral_stats(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Get user's referral statistics"""

    # Query stats
    total_referrals = db.query(Referral).filter(
        Referral.referrer_user_id == current_user.id
    ).count()

    converted_referrals = db.query(Referral).filter(
        and_(
            Referral.referrer_user_id == current_user.id,
            Referral.status == "converted"
        )
    ).count()

    pending_referrals = total_referrals - converted_referrals

    # Get credit balance
    credit_record = db.query(ReferralCredit).filter(
        ReferralCredit.user_id == current_user.id
    ).first()

    if not credit_record:
        credit_record = ReferralCredit(user_id=current_user.id)
        db.add(credit_record)
        db.commit()

    # Calculate conversion rate
    conversion_rate = (converted_referrals / total_referrals * 100) if total_referrals > 0 else 0.0

    # Get leaderboard rank
    top_referrers = db.query(
        Referral.referrer_user_id,
        func.count(Referral.id).label('count')
    ).filter(
        Referral.status == "converted"
    ).group_by(Referral.referrer_user_id).order_by(desc('count')).all()

    user_rank = None
    for idx, (user_id, count) in enumerate(top_referrers, 1):
        if user_id == current_user.id:
            user_rank = idx
            break

    return ReferralStatsResponse(
        total_referrals=total_referrals,
        converted_referrals=converted_referrals,
        pending_referrals=pending_referrals,
        total_earnings=credit_record.total_earned,
        available_credit=credit_record.balance,
        reserved_amount=credit_record.reserved_amount,
        conversion_rate=conversion_rate,
        top_referrer_rank=user_rank,
        referral_code=current_user.referral_code or ""
    )


@router.get("/history", response_model=ReferralHistoryResponse)
async def get_referral_history(
    page: int = Query(1, ge=1),
    per_page: int = Query(20, ge=1, le=100),
    status_filter: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Get referral history with pagination"""

    query = db.query(Referral).filter(
        Referral.referrer_user_id == current_user.id
    )

    if status_filter and status_filter in ["pending", "converted", "paid"]:
        query = query.filter(Referral.status == status_filter)

    total_count = query.count()

    referrals = query.order_by(desc(Referral.created_at)).offset(
        (page - 1) * per_page
    ).limit(per_page).all()

    from .schemas import ReferralHistoryItem

    history_items = []
    for ref in referrals:
        referred_user = db.query(User).filter(User.id == ref.referred_user_id).first()
        history_items.append(ReferralHistoryItem(
            id=ref.id,
            referred_user_email=referred_user.email if referred_user else None,
            status=ref.status,
            reward_amount=ref.reward_amount,
            created_at=ref.created_at,
            conversion_date=ref.conversion_date,
            is_paid=ref.is_paid
        ))

    total_pages = (total_count + per_page - 1) // per_page

    return ReferralHistoryResponse(
        referrals=history_items,
        total_count=total_count,
        page=page,
        per_page=per_page,
        total_pages=total_pages
    )


@router.post("/validate", response_model=ReferralValidationResponse)
async def validate_referral_code(
    code: str = Query(..., min_length=1),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Validate referral code during signup"""

    # Check if code exists
    referrer = db.query(User).filter(User.referral_code == code).first()

    if not referrer:
        return ReferralValidationResponse(
            is_valid=False,
            is_already_used=False,
            message="Invalid referral code"
        )

    # Check if current user already used a referral
    if current_user.referred_by_user_id:
        return ReferralValidationResponse(
            is_valid=False,
            is_already_used=True,
            message="You already have a referral discount"
        )

    # Check if referrer is the current user
    if referrer.id == current_user.id:
        return ReferralValidationResponse(
            is_valid=False,
            is_already_used=False,
            message="Cannot use your own referral code"
        )

    # Calculate discount
    discount_amount = Decimal(50)  # 50% off

    return ReferralValidationResponse(
        is_valid=True,
        is_already_used=False,
        referrer_name=referrer.name or "A MRReadyPrep User",
        referrer_avatar=referrer.avatar_url or None,
        discount_amount=discount_amount,
        message="Referral code valid! 50% off applied to your order."
    )


@router.post("/claim-credit")
async def claim_referral_credit(
    referral_code: str = Query(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """
    Apply referral code and set discount for current user
    Called after successful payment/signup
    """

    # Validate code
    referrer = db.query(User).filter(User.referral_code == referral_code).first()

    if not referrer or referrer.id == current_user.id:
        raise HTTPException(status_code=400, detail="Invalid referral code")

    if current_user.referred_by_user_id:
        raise HTTPException(status_code=400, detail="Already have a referral")

    try:
        # Create referral record
        referral = Referral(
            referrer_user_id=referrer.id,
            referred_user_id=current_user.id,
            referral_code=referral_code,
            status="converted",
            conversion_date=datetime.utcnow(),
            reward_amount=REFERRAL_REWARD
        )
        db.add(referral)

        # Update current user with referral info
        current_user.referred_by_user_id = referrer.id
        current_user.referral_discount_claimed = True
        current_user.referral_discount_expires_at = datetime.utcnow() + timedelta(days=REFERRAL_DISCOUNT_DURATION_DAYS)

        # Add credit to referrer
        referrer_credit = db.query(ReferralCredit).filter(
            ReferralCredit.user_id == referrer.id
        ).first()

        if not referrer_credit:
            referrer_credit = ReferralCredit(user_id=referrer.id)
            db.add(referrer_credit)

        referrer_credit.balance += REFERRAL_REWARD
        referrer_credit.total_earned += REFERRAL_REWARD
        referrer.total_referrals_count = (referrer.total_referrals_count or 0) + 1
        referrer.total_referral_earnings = (referrer.total_referral_earnings or Decimal("0")) + REFERRAL_REWARD

        # Log transaction
        transaction = ReferralTransaction(
            user_id=referrer.id,
            referral_id=referral.id,
            type="credit",
            amount=REFERRAL_REWARD,
            description=f"Referral credit from new user {current_user.email}"
        )
        db.add(transaction)

        db.commit()

        return {
            "success": True,
            "message": f"Referral applied! ${REFERRAL_REWARD} credit added to referrer",
            "referrer_id": str(referrer.id),
            "discount_duration_days": REFERRAL_DISCOUNT_DURATION_DAYS
        }

    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error claiming referral: {str(e)}")


@router.get("/leaderboard", response_model=LeaderboardResponse)
async def get_leaderboard(
    limit: int = Query(10, ge=1, le=100),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Get top referrers leaderboard"""

    # Query top referrers
    top_referrers = db.query(
        User.id,
        User.name,
        User.avatar_url,
        func.count(Referral.id).label('referral_count'),
        func.sum(Referral.reward_amount).label('total_earnings')
    ).join(
        Referral, Referral.referrer_user_id == User.id
    ).filter(
        Referral.status == "converted"
    ).group_by(User.id).order_by(
        desc('total_earnings')
    ).limit(limit).all()

    entries = []
    user_rank = None
    user_earnings = Decimal("0")

    for idx, (user_id, name, avatar, count, earnings) in enumerate(top_referrers, 1):
        conversion_rate = 0.0  # Can be enhanced with additional query

        entries.append(LeaderboardEntry(
            rank=idx,
            user_id=user_id,
            user_name=name or "MRReadyPrep User",
            user_avatar=avatar,
            total_referrals=count or 0,
            total_earnings=Decimal(earnings) if earnings else Decimal("0"),
            conversion_rate=conversion_rate
        ))

        if user_id == current_user.id:
            user_rank = idx
            user_earnings = Decimal(earnings) if earnings else Decimal("0")

    return LeaderboardResponse(
        entries=entries,
        user_rank=user_rank,
        user_earnings=user_earnings,
        generated_at=datetime.utcnow()
    )


@router.get("/balance", response_model=ReferralCreditBalance)
async def get_credit_balance(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Get user's credit balance"""

    credit_record = db.query(ReferralCredit).filter(
        ReferralCredit.user_id == current_user.id
    ).first()

    if not credit_record:
        credit_record = ReferralCredit(user_id=current_user.id)
        db.add(credit_record)
        db.commit()

    return ReferralCreditBalance(
        balance=credit_record.balance,
        reserved_amount=credit_record.reserved_amount,
        total_earned=credit_record.total_earned,
        total_redeemed=credit_record.total_redeemed,
        last_updated=credit_record.last_updated
    )


@router.get("/transactions")
async def get_transactions(
    page: int = Query(1, ge=1),
    per_page: int = Query(20, ge=1, le=100),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Get user's transaction history"""

    total_count = db.query(ReferralTransaction).filter(
        ReferralTransaction.user_id == current_user.id
    ).count()

    transactions = db.query(ReferralTransaction).filter(
        ReferralTransaction.user_id == current_user.id
    ).order_by(desc(ReferralTransaction.created_at)).offset(
        (page - 1) * per_page
    ).limit(per_page).all()

    return {
        "transactions": [
            ReferralTransactionResponse.from_orm(t) for t in transactions
        ],
        "total_count": total_count,
        "page": page,
        "per_page": per_page,
        "total_pages": (total_count + per_page - 1) // per_page
    }


@router.post("/request-payout", response_model=PayoutResponse)
async def request_payout(
    request: dict,  # {"amount": Decimal, "payout_method": "stripe"}
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Request payout of referral credits"""

    amount = Decimal(str(request.get("amount", 0)))
    payout_method = request.get("payout_method", "stripe")

    # Validate amount
    if amount < MIN_PAYOUT_AMOUNT:
        raise HTTPException(
            status_code=400,
            detail=f"Minimum payout amount is ${MIN_PAYOUT_AMOUNT}"
        )

    # Check balance
    credit_record = db.query(ReferralCredit).filter(
        ReferralCredit.user_id == current_user.id
    ).first()

    if not credit_record or credit_record.balance < amount:
        raise HTTPException(status_code=400, detail="Insufficient balance")

    try:
        # Create payout request
        payout = ReferralPayout(
            user_id=current_user.id,
            amount=amount,
            payout_method=payout_method,
            status="pending"
        )
        db.add(payout)

        # Reserve amount
        credit_record.reserved_amount += amount
        credit_record.balance -= amount

        db.commit()

        # TODO: Queue payout processing job (Stripe, PayPal, etc.)

        return PayoutResponse.from_orm(payout)

    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=f"Error requesting payout: {str(e)}")


@router.get("/analytics")
async def get_referral_analytics(
    days: int = Query(30, ge=1, le=365),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Get referral program analytics"""

    start_date = datetime.utcnow().date() - timedelta(days=days)

    analytics = db.query(ReferralAnalytics).filter(
        ReferralAnalytics.date >= start_date
    ).order_by(ReferralAnalytics.date).all()

    return {
        "analytics": [
            ReferralAnalyticsResponse.from_orm(a) for a in analytics
        ],
        "period_days": days,
        "generated_at": datetime.utcnow()
    }


@router.post("/webhook/conversion")
async def webhook_conversion(
    payload: dict,
    x_webhook_secret: str = Header(None),
    db: Session = Depends(get_db)
):
    """
    Internal webhook for conversion tracking
    Called when user completes purchase/subscription
    """

    # Verify webhook secret
    webhook_secret = "your-webhook-secret-key"  # Move to env
    if x_webhook_secret != webhook_secret:
        raise HTTPException(status_code=401, detail="Unauthorized")

    user_id = payload.get("user_id")
    subscription_type = payload.get("subscription_type")

    if not user_id:
        raise HTTPException(status_code=400, detail="Missing user_id")

    # Mark pending referrals as converted
    pending_referrals = db.query(Referral).filter(
        and_(
            Referral.referred_user_id == user_id,
            Referral.status == "pending"
        )
    ).all()

    for ref in pending_referrals:
        ref.status = "converted"
        ref.conversion_date = datetime.utcnow()

    db.commit()

    return {"success": True, "conversions": len(pending_referrals)}


# Health check
@router.get("/health")
async def health_check():
    """Health check endpoint"""
    return {"status": "ok", "service": "referral-api"}
