# backend/app/routes/videos.py
from fastapi import APIRouter, UploadFile, File, Form, Depends, HTTPException, BackgroundTasks
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session
from datetime import datetime, timedelta
from typing import List, Optional
import uuid
import os
import shutil
from app.database import get_db
from app.models import Video, YouTubeChannel, VideoStatus, PublishSchedule, NotificationLog, AnalyticsSnapshot
from app.services.youtube_service import YouTubeService
from app.services.email_service import EmailService
from app.services.scheduler_service import VideoSchedulerService
from app.schemas import VideoCreate, VideoUpdate, VideoResponse, AnalyticsResponse

router = APIRouter(prefix="/api/videos", tags=["videos"])

# Environment variables
YOUTUBE_CLIENT_ID = os.getenv("YOUTUBE_CLIENT_ID")
YOUTUBE_CLIENT_SECRET = os.getenv("YOUTUBE_CLIENT_SECRET")
YOUTUBE_REDIRECT_URI = os.getenv("YOUTUBE_REDIRECT_URI", "http://localhost:8000/api/videos/oauth-callback")
UPLOAD_DIR = os.getenv("UPLOAD_DIR", "./uploads/videos")
SMTP_EMAIL = os.getenv("SMTP_EMAIL")
SMTP_PASSWORD = os.getenv("SMTP_PASSWORD")

youtube_service = YouTubeService(YOUTUBE_CLIENT_ID, YOUTUBE_CLIENT_SECRET, YOUTUBE_REDIRECT_URI)
email_service = EmailService(SMTP_EMAIL, SMTP_PASSWORD)
scheduler_service = VideoSchedulerService()

# Ensure upload directory exists
os.makedirs(UPLOAD_DIR, exist_ok=True)


@router.post("/oauth-url")
def get_oauth_url():
    """OAuth login URL'sini al"""
    try:
        flow = youtube_service.get_oauth_flow()
        auth_uri, _ = flow.authorization_url(prompt='consent')
        return {
            "success": True,
            "auth_url": auth_uri,
        }
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/oauth-callback")
def oauth_callback(code: str, db: Session = Depends(get_db)):
    """OAuth callback ve token'ı kaydet"""
    try:
        flow = youtube_service.get_oauth_flow()
        flow.fetch_token(code=code)
        credentials = flow.credentials

        # Channel info al
        channel_info = youtube_service.get_channel_info(credentials.token, credentials.refresh_token)

        if not channel_info['success']:
            raise HTTPException(status_code=400, detail="Channel info alınamadı")

        # Veya existing channel varsa güncelle
        existing = db.query(YouTubeChannel).filter_by(
            channel_id=channel_info['channel_id']
        ).first()

        if existing:
            existing.access_token = credentials.token
            existing.refresh_token = credentials.refresh_token
            existing.token_expiry = datetime.utcnow() + timedelta(hours=1)
            existing.last_synced = datetime.utcnow()
        else:
            new_channel = YouTubeChannel(
                id=str(uuid.uuid4()),
                channel_id=channel_info['channel_id'],
                channel_name=channel_info['channel_name'],
                channel_url=channel_info.get('channel_url', ''),
                access_token=credentials.token,
                refresh_token=credentials.refresh_token,
                token_expiry=datetime.utcnow() + timedelta(hours=1),
                subscriber_count=channel_info['subscriber_count'],
                video_count=channel_info['video_count'],
                view_count=channel_info['view_count'],
            )
            db.add(new_channel)

        db.commit()

        return {
            "success": True,
            "channel": channel_info,
            "message": "Channel başarıyla bağlandı",
        }

    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/upload")
async def upload_video(
    file: UploadFile = File(...),
    title: str = Form(...),
    description: str = Form(...),
    tags: str = Form(...),
    scheduled_date: Optional[str] = Form(None),
    db: Session = Depends(get_db),
    background_tasks: BackgroundTasks = BackgroundTasks(),
):
    """Video yükle ve metadatası kaydet"""
    try:
        # YouTube channel check
        channel = db.query(YouTubeChannel).filter_by(is_connected=True).first()
        if not channel:
            raise HTTPException(status_code=400, detail="YouTube channel bağlı değil")

        # File save
        video_id = str(uuid.uuid4())
        file_extension = file.filename.split('.')[-1]
        file_path = os.path.join(UPLOAD_DIR, f"{video_id}.{file_extension}")

        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)

        # Parse scheduled date
        publish_date = None
        status = VideoStatus.DRAFT
        if scheduled_date:
            publish_date = datetime.fromisoformat(scheduled_date)
            status = VideoStatus.SCHEDULED

        # Database record
        video = Video(
            id=video_id,
            title=title,
            description=description,
            tags=tags,
            status=status.value,
            file_path=file_path,
            scheduled_publish_date=publish_date,
            created_at=datetime.utcnow(),
        )
        db.add(video)
        db.commit()
        db.refresh(video)

        # Schedule YouTube upload if date provided
        if scheduled_date:
            background_tasks.add_task(
                scheduler_service.schedule_video_upload,
                video_id=video_id,
                file_path=file_path,
                title=title,
                description=description,
                tags=tags.split(','),
                publish_date=publish_date,
                channel_id=channel.id,
                access_token=channel.access_token,
                refresh_token=channel.refresh_token,
                db=db,
            )

        # Upload reminder email
        background_tasks.add_task(
            email_service.send_upload_reminder,
            video_title=title,
            scheduled_date=scheduled_date or "Planlanmadı",
        )

        return {
            "success": True,
            "video_id": video_id,
            "status": status.value,
            "message": "Video başarıyla yüklendi",
        }

    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/list")
def list_videos(
    status: Optional[str] = None,
    skip: int = 0,
    limit: int = 20,
    db: Session = Depends(get_db),
):
    """Video'ları listele"""
    try:
        query = db.query(Video)

        if status:
            query = query.filter(Video.status == status)

        videos = query.order_by(Video.created_at.desc()).offset(skip).limit(limit).all()
        total = query.count()

        return {
            "success": True,
            "videos": [VideoResponse.from_orm(v).dict() for v in videos],
            "total": total,
            "skip": skip,
            "limit": limit,
        }

    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/{video_id}")
def get_video(video_id: str, db: Session = Depends(get_db)):
    """Tek video detayı al"""
    try:
        video = db.query(Video).filter(Video.id == video_id).first()
        if not video:
            raise HTTPException(status_code=404, detail="Video bulunamadı")

        return {
            "success": True,
            "video": VideoResponse.from_orm(video).dict(),
        }

    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/schedule")
def schedule_video(
    video_id: str,
    publish_date: str,
    db: Session = Depends(get_db),
    background_tasks: BackgroundTasks = BackgroundTasks(),
):
    """Video'yu belirli tarihte yayınlanmak üzere planla"""
    try:
        video = db.query(Video).filter(Video.id == video_id).first()
        if not video:
            raise HTTPException(status_code=404, detail="Video bulunamadı")

        publish_datetime = datetime.fromisoformat(publish_date)
        channel = db.query(YouTubeChannel).filter_by(is_connected=True).first()

        if not channel:
            raise HTTPException(status_code=400, detail="YouTube channel bağlı değil")

        video.scheduled_publish_date = publish_datetime
        video.status = VideoStatus.SCHEDULED.value

        # Check monthly quota (4 videos/month)
        month_key = publish_datetime.strftime("%Y-%m")
        month_schedule = db.query(PublishSchedule).filter_by(month=month_key).first()

        if month_schedule:
            if month_schedule.published_count >= month_schedule.target_count:
                raise HTTPException(
                    status_code=400,
                    detail=f"Bu ayın yayın kotası doldu (4/4)"
                )
        else:
            month_schedule = PublishSchedule(
                id=str(uuid.uuid4()),
                month=month_key,
                target_count=4,
                published_count=0,
                scheduled_dates=[publish_datetime.isoformat()],
            )
            db.add(month_schedule)

        db.commit()

        # Background task: schedule upload
        background_tasks.add_task(
            scheduler_service.schedule_video_upload,
            video_id=video_id,
            file_path=video.file_path,
            title=video.title,
            description=video.description,
            tags=video.tags.split(','),
            publish_date=publish_datetime,
            channel_id=channel.id,
            access_token=channel.access_token,
            refresh_token=channel.refresh_token,
            db=db,
        )

        return {
            "success": True,
            "video_id": video_id,
            "scheduled_date": publish_date,
            "message": "Video başarıyla planlandı",
        }

    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/analytics/{video_id}")
def get_video_analytics(
    video_id: str,
    db: Session = Depends(get_db),
    background_tasks: BackgroundTasks = BackgroundTasks(),
):
    """Video analytics'i al"""
    try:
        video = db.query(Video).filter(Video.id == video_id).first()
        if not video:
            raise HTTPException(status_code=404, detail="Video bulunamadı")

        if not video.youtube_id:
            raise HTTPException(status_code=400, detail="Video YouTube'da yayınlanmadı")

        channel = db.query(YouTubeChannel).filter_by(is_connected=True).first()
        if not channel:
            raise HTTPException(status_code=400, detail="YouTube channel bağlı değil")

        # Get analytics from YouTube
        analytics = youtube_service.get_video_analytics(
            video_id=video.youtube_id,
            access_token=channel.access_token,
            refresh_token=channel.refresh_token,
        )

        if analytics['success']:
            # Save snapshot
            snapshot = AnalyticsSnapshot(
                id=str(uuid.uuid4()),
                video_id=video_id,
                youtube_id=video.youtube_id,
                view_count=analytics['view_count'],
                watch_time_hours=analytics.get('watch_time_hours', 0),
                average_view_duration=analytics.get('average_view_duration', 0),
                like_count=analytics['like_count'],
                comment_count=analytics['comment_count'],
                subscriber_gain=analytics.get('subscriber_gain', 0),
            )
            db.add(snapshot)

            # Update video model
            video.view_count = analytics['view_count']
            video.like_count = analytics['like_count']
            video.comment_count = analytics['comment_count']
            video.last_analytics_sync = datetime.utcnow()

            if video.view_count > 0:
                video.like_ratio = (analytics['like_count'] / analytics['view_count']) * 100

            db.commit()

        return {
            "success": True,
            "video_id": video_id,
            "analytics": {
                "title": video.title,
                "view_count": video.view_count,
                "like_count": video.like_count,
                "comment_count": video.comment_count,
                "like_ratio": video.like_ratio or 0,
                "watch_time_hours": video.watch_time_hours,
                "average_view_duration": video.average_view_duration,
                "last_synced": video.last_analytics_sync.isoformat() if video.last_analytics_sync else None,
            }
        }

    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/channel/analytics")
def get_channel_analytics(db: Session = Depends(get_db)):
    """Channel-wide analytics"""
    try:
        channel = db.query(YouTubeChannel).filter_by(is_connected=True).first()
        if not channel:
            raise HTTPException(status_code=400, detail="YouTube channel bağlı değil")

        # Get channel stats
        stats = youtube_service.get_channel_analytics(
            channel_id=channel.channel_id,
            access_token=channel.access_token,
            refresh_token=channel.refresh_token,
        )

        if stats['success']:
            channel.subscriber_count = stats['subscriber_count']
            channel.video_count = stats['video_count']
            channel.view_count = stats['view_count']
            db.commit()

        # Get videos analytics
        videos = db.query(Video).filter(
            Video.status == VideoStatus.PUBLISHED.value
        ).order_by(Video.actual_publish_date.desc()).limit(10).all()

        total_views = sum(v.view_count for v in videos)
        total_watch_time = sum(v.watch_time_hours for v in videos)
        avg_like_ratio = (sum(v.like_ratio or 0 for v in videos) / len(videos)) if videos else 0

        return {
            "success": True,
            "channel": {
                "name": channel.channel_name,
                "subscriber_count": channel.subscriber_count,
                "video_count": channel.video_count,
                "total_view_count": channel.view_count,
            },
            "this_month": {
                "total_views": total_views,
                "total_watch_time": total_watch_time,
                "average_like_ratio": avg_like_ratio,
                "total_videos": len(videos),
            }
        }

    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.get("/calendar/{year}/{month}")
def get_publishing_calendar(
    year: int,
    month: int,
    db: Session = Depends(get_db),
):
    """Yayın takvimi al (4 video/ay)"""
    try:
        month_key = f"{year:04d}-{month:02d}"

        # Get schedule for month
        schedule = db.query(PublishSchedule).filter_by(month=month_key).first()

        # Get published videos this month
        videos = db.query(Video).filter(
            Video.scheduled_publish_date.isnot(None),
            Video.scheduled_publish_date >= f"{year:04d}-{month:02d}-01",
            Video.scheduled_publish_date < f"{year:04d}-{month:02d + 1:02d}-01" if month < 12
            else f"{year + 1:04d}-01-01"
        ).order_by(Video.scheduled_publish_date).all()

        scheduled_dates = [
            {
                "date": v.scheduled_publish_date.isoformat() if v.scheduled_publish_date else None,
                "title": v.title,
                "status": v.status,
                "video_id": v.id,
            }
            for v in videos
        ]

        return {
            "success": True,
            "month": month_key,
            "target_count": 4,
            "published_count": len([v for v in videos if v.status == VideoStatus.PUBLISHED.value]),
            "scheduled_count": len([v for v in videos if v.status == VideoStatus.SCHEDULED.value]),
            "scheduled_dates": scheduled_dates,
        }

    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@router.post("/{video_id}/publish")
def publish_video(
    video_id: str,
    db: Session = Depends(get_db),
    background_tasks: BackgroundTasks = BackgroundTasks(),
):
    """Video'yu hemen yayınla"""
    try:
        video = db.query(Video).filter(Video.id == video_id).first()
        if not video:
            raise HTTPException(status_code=404, detail="Video bulunamadı")

        channel = db.query(YouTubeChannel).filter_by(is_connected=True).first()
        if not channel:
            raise HTTPException(status_code=400, detail="YouTube channel bağlı değil")

        video.status = VideoStatus.PUBLISHED.value
        video.actual_publish_date = datetime.utcnow()

        # Background task: upload to YouTube
        background_tasks.add_task(
            scheduler_service.upload_to_youtube,
            video_id=video_id,
            file_path=video.file_path,
            title=video.title,
            description=video.description,
            tags=video.tags.split(','),
            channel_id=channel.id,
            access_token=channel.access_token,
            refresh_token=channel.refresh_token,
            db=db,
        )

        db.commit()

        return {
            "success": True,
            "video_id": video_id,
            "status": "publishing",
            "message": "Video yayınlanıyor...",
        }

    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
