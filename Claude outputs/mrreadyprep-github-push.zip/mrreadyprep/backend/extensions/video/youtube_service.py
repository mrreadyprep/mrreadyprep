# backend/app/services/youtube_service.py
import os
import json
from datetime import datetime, timedelta
from typing import Optional, Dict, List
import google.auth
from google.oauth2.service_account import Credentials
from google.auth.transport.requests import Request
from google.oauth2 import credentials as oauth2_credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
from sqlalchemy.orm import Session
from app.models import YouTubeChannel, Video, AnalyticsSnapshot


class YouTubeService:
    SCOPES = [
        'https://www.googleapis.com/auth/youtube.upload',
        'https://www.googleapis.com/auth/youtube.readonly',
        'https://www.googleapis.com/auth/youtube',
    ]

    def __init__(self, client_id: str, client_secret: str, redirect_uri: str):
        self.client_id = client_id
        self.client_secret = client_secret
        self.redirect_uri = redirect_uri

    def get_oauth_flow(self):
        """OAuth 2.0 flow'unu başlat"""
        client_config = {
            "installed": {
                "client_id": self.client_id,
                "client_secret": self.client_secret,
                "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                "token_uri": "https://oauth2.googleapis.com/token",
                "redirect_uris": [self.redirect_uri],
            }
        }
        flow = InstalledAppFlow.from_client_config(client_config, scopes=self.SCOPES)
        return flow

    def get_youtube_service(self, access_token: str, refresh_token: Optional[str] = None):
        """YouTube API servisi oluştur"""
        creds = oauth2_credentials.Credentials(
            token=access_token,
            refresh_token=refresh_token,
            token_uri="https://oauth2.googleapis.com/token",
            client_id=self.client_id,
            client_secret=self.client_secret,
        )

        if creds.expired and refresh_token:
            creds.refresh(Request())

        return build('youtube', 'v3', credentials=creds)

    def upload_video(
        self,
        file_path: str,
        title: str,
        description: str,
        tags: List[str],
        access_token: str,
        refresh_token: Optional[str] = None,
        privacy_status: str = "private",
        publish_at: Optional[datetime] = None
    ) -> Dict:
        """Video'yu YouTube'a yükle"""
        try:
            youtube = self.get_youtube_service(access_token, refresh_token)

            request_body = {
                'snippet': {
                    'title': title,
                    'description': description,
                    'tags': tags,
                    'categoryId': '27',  # Education category
                    'defaultLanguage': 'tr',
                    'defaultAudioLanguage': 'tr',
                },
                'status': {
                    'privacyStatus': privacy_status,
                    'publishAt': publish_at.isoformat() + 'Z' if publish_at else None,
                    'selfDeclaredMadeForKids': False,
                },
            }

            media = MediaFileUpload(file_path, chunksize=-1, resumable=True)

            request = youtube.videos().insert(
                part='snippet,status',
                body=request_body,
                media_body=media,
                onBehalfOfContentOwner=None,
                onBehalfOfContentOwnerChannel=None,
                autoLanguage=None,
            )

            response = None
            while response is None:
                status, response = request.next_chunk()
                if status:
                    print(f"Yükleniyor... {int(status.progress() * 100)}%")

            return {
                'success': True,
                'video_id': response.get('id'),
                'title': response['snippet']['title'],
                'status': response['status']['uploadStatus'],
            }

        except Exception as e:
            return {
                'success': False,
                'error': str(e),
            }

    def schedule_video(
        self,
        video_id: str,
        publish_at: datetime,
        access_token: str,
        refresh_token: Optional[str] = None,
    ) -> Dict:
        """Video'yu belirli bir tarihte yayınlanmak üzere planla"""
        try:
            youtube = self.get_youtube_service(access_token, refresh_token)

            request_body = {
                'status': {
                    'publishAt': publish_at.isoformat() + 'Z',
                    'privacyStatus': 'public',
                }
            }

            request = youtube.videos().update(
                part='status',
                body=request_body,
            )
            response = request.execute()

            return {
                'success': True,
                'scheduled_at': publish_at.isoformat(),
                'status': response['status'].get('uploadStatus'),
            }

        except Exception as e:
            return {
                'success': False,
                'error': str(e),
            }

    def get_channel_info(self, access_token: str, refresh_token: Optional[str] = None) -> Dict:
        """Channel bilgisini al"""
        try:
            youtube = self.get_youtube_service(access_token, refresh_token)

            request = youtube.channels().list(
                part='snippet,statistics,contentDetails',
                mine=True,
            )
            response = request.execute()

            if response['items']:
                channel = response['items'][0]
                return {
                    'success': True,
                    'channel_id': channel['id'],
                    'channel_name': channel['snippet']['title'],
                    'channel_description': channel['snippet']['description'],
                    'channel_url': channel['snippet']['customUrl'],
                    'subscriber_count': int(channel['statistics'].get('subscriberCount', 0)),
                    'video_count': int(channel['statistics'].get('videoCount', 0)),
                    'view_count': int(channel['statistics'].get('viewCount', 0)),
                    'thumbnail_url': channel['snippet']['thumbnails']['default']['url'],
                }
            return {'success': False, 'error': 'Channel bulunamadı'}

        except Exception as e:
            return {'success': False, 'error': str(e)}

    def get_video_analytics(
        self,
        video_id: str,
        access_token: str,
        refresh_token: Optional[str] = None,
        start_date: Optional[str] = None,
        end_date: Optional[str] = None,
    ) -> Dict:
        """Video analytics'i YouTube Analytics API'den al"""
        try:
            youtube = self.get_youtube_service(access_token, refresh_token)

            # Video istatistikleri
            request = youtube.videos().list(
                part='statistics,snippet',
                id=video_id,
            )
            response = request.execute()

            if response['items']:
                video = response['items'][0]
                stats = video['statistics']

                return {
                    'success': True,
                    'video_id': video_id,
                    'title': video['snippet']['title'],
                    'view_count': int(stats.get('viewCount', 0)),
                    'like_count': int(stats.get('likeCount', 0)),
                    'comment_count': int(stats.get('commentCount', 0)),
                    'favorite_count': int(stats.get('favoriteCount', 0)),
                    'published_at': video['snippet']['publishedAt'],
                }

            return {'success': False, 'error': 'Video bulunamadı'}

        except Exception as e:
            return {'success': False, 'error': str(e)}

    def get_channel_analytics(
        self,
        channel_id: str,
        access_token: str,
        refresh_token: Optional[str] = None,
    ) -> Dict:
        """Channel-wide analytics al"""
        try:
            youtube = self.get_youtube_service(access_token, refresh_token)

            request = youtube.channels().list(
                part='statistics',
                id=channel_id,
            )
            response = request.execute()

            if response['items']:
                stats = response['items'][0]['statistics']
                return {
                    'success': True,
                    'subscriber_count': int(stats.get('subscriberCount', 0)),
                    'video_count': int(stats.get('videoCount', 0)),
                    'view_count': int(stats.get('viewCount', 0)),
                    'comment_count': int(stats.get('hiddenSubscriberCount', False)),
                }

            return {'success': False, 'error': 'Channel bulunamadı'}

        except Exception as e:
            return {'success': False, 'error': str(e)}

    def list_uploaded_videos(
        self,
        access_token: str,
        refresh_token: Optional[str] = None,
        max_results: int = 25,
    ) -> Dict:
        """Uploads playlist'indeki video'ları listele"""
        try:
            youtube = self.get_youtube_service(access_token, refresh_token)

            # Uploads playlist'ini al
            channels = youtube.channels().list(
                part='contentDetails',
                mine=True,
            ).execute()

            if not channels['items']:
                return {'success': False, 'error': 'Channel bulunamadı'}

            uploads_playlist = channels['items'][0]['contentDetails']['relatedPlaylists']['uploads']

            # Playlist items'ları al
            request = youtube.playlistItems().list(
                part='snippet',
                playlistId=uploads_playlist,
                maxResults=max_results,
            )

            videos = []
            while request and len(videos) < max_results:
                response = request.execute()

                for item in response.get('items', []):
                    videos.append({
                        'video_id': item['snippet']['resourceId']['videoId'],
                        'title': item['snippet']['title'],
                        'description': item['snippet']['description'],
                        'thumbnail_url': item['snippet']['thumbnails']['default']['url'],
                        'published_at': item['snippet']['publishedAt'],
                    })

                request = youtube.playlistItems().list_next(request, response) if 'nextPageToken' in response else None

            return {
                'success': True,
                'videos': videos,
                'total': len(videos),
            }

        except Exception as e:
            return {'success': False, 'error': str(e)}

    def update_video_metadata(
        self,
        video_id: str,
        title: Optional[str] = None,
        description: Optional[str] = None,
        tags: Optional[List[str]] = None,
        access_token: str = None,
        refresh_token: Optional[str] = None,
    ) -> Dict:
        """Video metadata'sını güncelle"""
        try:
            youtube = self.get_youtube_service(access_token, refresh_token)

            request_body = {
                'id': video_id,
                'snippet': {}
            }

            if title:
                request_body['snippet']['title'] = title
            if description:
                request_body['snippet']['description'] = description
            if tags:
                request_body['snippet']['tags'] = tags

            request = youtube.videos().update(
                part='snippet',
                body=request_body,
            )
            response = request.execute()

            return {
                'success': True,
                'video_id': response['id'],
                'updated_fields': {
                    'title': title,
                    'description': description,
                    'tags': tags,
                }
            }

        except Exception as e:
            return {'success': False, 'error': str(e)}
