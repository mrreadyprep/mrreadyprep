# backend/app/main.py
from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session
from contextlib import asynccontextmanager
from datetime import datetime
import os
import logging

from app.database import Base, engine, get_db
from app.routes import videos
from app.services.youtube_service import YouTubeService
from app.services.email_service import EmailService
from app.services.scheduler_service import VideoSchedulerService

# Logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Environment variables
YOUTUBE_CLIENT_ID = os.getenv("YOUTUBE_CLIENT_ID")
YOUTUBE_CLIENT_SECRET = os.getenv("YOUTUBE_CLIENT_SECRET")
YOUTUBE_REDIRECT_URI = os.getenv("YOUTUBE_REDIRECT_URI", "http://localhost:8000/api/videos/oauth-callback")
SMTP_EMAIL = os.getenv("SMTP_EMAIL")
SMTP_PASSWORD = os.getenv("SMTP_PASSWORD")
FRONTEND_URL = os.getenv("FRONTEND_URL", "http://localhost:3000")

# Services
youtube_service = YouTubeService(YOUTUBE_CLIENT_ID, YOUTUBE_CLIENT_SECRET, YOUTUBE_REDIRECT_URI)
email_service = EmailService(SMTP_EMAIL, SMTP_PASSWORD)
scheduler_service = VideoSchedulerService()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application startup ve shutdown"""
    # Startup
    logger.info("MRReadyPrep Video Management System başlatılıyor...")

    # Create tables
    Base.metadata.create_all(bind=engine)

    # Initialize services
    scheduler_service.initialize(youtube_service, email_service)
    scheduler_service.schedule_analytics_report(db=next(get_db()))
    scheduler_service.schedule_monthly_planning_reminder(db=next(get_db()))

    logger.info("Sistem başarıyla başlatıldı")

    yield

    # Shutdown
    logger.info("Sistem kapatılıyor...")
    scheduler_service.shutdown()
    logger.info("Sistem kapatıldı")


# FastAPI app
app = FastAPI(
    title="MRReadyPrep Video Management API",
    description="TOEFL iBT 2026 preparation - Video content strategy system",
    version="1.0.0",
    lifespan=lifespan,
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=[FRONTEND_URL, "http://localhost:3000", "http://localhost:3001"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Routes
app.include_router(videos.router)


@app.get("/")
def root():
    """Health check"""
    return {
        "status": "ok",
        "service": "MRReadyPrep Video Management API",
        "version": "1.0.0",
        "timestamp": datetime.utcnow().isoformat(),
    }


@app.get("/health")
def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "service": "video-management",
        "timestamp": datetime.utcnow().isoformat(),
    }


@app.get("/api/system/info")
def system_info(db: Session = Depends(get_db)):
    """Sistem bilgisi"""
    try:
        from app.models import Video, YouTubeChannel

        video_count = db.query(Video).count()
        published_count = db.query(Video).filter_by(status="published").count()
        scheduled_count = db.query(Video).filter_by(status="scheduled").count()
        channel = db.query(YouTubeChannel).filter_by(is_connected=True).first()

        return {
            "status": "ok",
            "system": {
                "video_count": video_count,
                "published_videos": published_count,
                "scheduled_videos": scheduled_count,
                "channel_connected": channel is not None,
                "channel_name": channel.channel_name if channel else None,
            },
            "scheduler": {
                "running": scheduler_service.scheduler.running,
                "jobs": len(scheduler_service.get_scheduled_jobs()),
            },
            "timestamp": datetime.utcnow().isoformat(),
        }
    except Exception as e:
        return {
            "status": "error",
            "error": str(e),
            "timestamp": datetime.utcnow().isoformat(),
        }


@app.exception_handler(Exception)
async def global_exception_handler(request, exc):
    """Global exception handler"""
    logger.error(f"Unexpected error: {str(exc)}")
    return JSONResponse(
        status_code=500,
        content={
            "success": False,
            "error": "İç sunucu hatası. Lütfen daha sonra tekrar deneyiniz.",
            "timestamp": datetime.utcnow().isoformat(),
        }
    )


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info",
    )
