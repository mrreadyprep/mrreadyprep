# backend/app/models.py
from sqlalchemy import Column, String, DateTime, Integer, Float, Boolean, Text, JSON
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime
from enum import Enum

Base = declarative_base()


class VideoStatus(str, Enum):
    DRAFT = "draft"
    SCHEDULED = "scheduled"
    PUBLISHED = "published"
    ARCHIVED = "archived"


class Video(Base):
    __tablename__ = "videos"

    id = Column(String, primary_key=True, index=True)
    youtube_id = Column(String, unique=True, nullable=True, index=True)
    title = Column(String, index=True)
    description = Column(Text)
    tags = Column(String)  # Comma-separated
    status = Column(String, default=VideoStatus.DRAFT)

    # Upload and scheduling
    file_path = Column(String, nullable=True)
    upload_date = Column(DateTime, default=datetime.utcnow)
    scheduled_publish_date = Column(DateTime, nullable=True)
    actual_publish_date = Column(DateTime, nullable=True)

    # Metadata
    duration = Column(Integer, nullable=True)  # seconds
    thumbnail_url = Column(String, nullable=True)

    # Analytics
    view_count = Column(Integer, default=0)
    like_count = Column(Integer, default=0)
    comment_count = Column(Integer, default=0)
    average_view_duration = Column(Float, nullable=True)  # seconds
    watch_time_hours = Column(Float, default=0)
    subscriber_gain = Column(Integer, default=0)

    # Engagement metrics
    like_ratio = Column(Float, nullable=True)
    click_through_rate = Column(Float, nullable=True)
    average_percentage_viewed = Column(Float, nullable=True)

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # Publishing metadata
    published_at = Column(DateTime, nullable=True)
    is_notified = Column(Boolean, default=False)
    last_analytics_sync = Column(DateTime, nullable=True)


class YouTubeChannel(Base):
    __tablename__ = "youtube_channels"

    id = Column(String, primary_key=True)
    channel_id = Column(String, unique=True, index=True)
    channel_name = Column(String)
    channel_url = Column(String)

    # OAuth credentials
    access_token = Column(String)
    refresh_token = Column(String)
    token_expiry = Column(DateTime)

    # Channel stats
    subscriber_count = Column(Integer, default=0)
    video_count = Column(Integer, default=0)
    view_count = Column(Integer, default=0)

    # Status
    is_connected = Column(Boolean, default=True)

    # Timestamps
    connected_at = Column(DateTime, default=datetime.utcnow)
    last_synced = Column(DateTime, nullable=True)


class PublishSchedule(Base):
    __tablename__ = "publish_schedules"

    id = Column(String, primary_key=True)
    month = Column(String, index=True)  # YYYY-MM
    target_count = Column(Integer, default=4)
    published_count = Column(Integer, default=0)

    # Scheduled dates
    scheduled_dates = Column(JSON)  # List of datetime objects

    # Status tracking
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class NotificationLog(Base):
    __tablename__ = "notification_logs"

    id = Column(String, primary_key=True)
    video_id = Column(String, index=True)
    notification_type = Column(String)  # upload_reminder, publish_reminder, analytics_report
    recipient_email = Column(String)
    subject = Column(String)
    sent_at = Column(DateTime, default=datetime.utcnow)
    status = Column(String)  # sent, failed, pending
    error_message = Column(Text, nullable=True)


class AnalyticsSnapshot(Base):
    __tablename__ = "analytics_snapshots"

    id = Column(String, primary_key=True)
    video_id = Column(String, index=True)
    youtube_id = Column(String, index=True)

    # Metrics
    view_count = Column(Integer)
    watch_time_hours = Column(Float)
    average_view_duration = Column(Float)
    like_count = Column(Integer)
    comment_count = Column(Integer)
    subscriber_gain = Column(Integer)
    click_through_rate = Column(Float, nullable=True)
    average_percentage_viewed = Column(Float, nullable=True)

    # Snapshot timestamp
    snapshot_date = Column(DateTime, default=datetime.utcnow)
    recorded_at = Column(DateTime, default=datetime.utcnow)
