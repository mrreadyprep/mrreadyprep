import { useState, useEffect } from 'react'
import './App.css'

function App() {
  const [data, setData] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  // Fix: Proper useEffect usage with null checks
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true)
        const apiUrl = import.meta.env.VITE_API_URL

        // Fix: Check if apiUrl exists before making request
        if (!apiUrl) {
          throw new Error('API URL not configured')
        }

        const response = await fetch(`${apiUrl}/api/data`)

        // Fix: Proper null check before accessing response
        if (!response) {
          throw new Error('No response from server')
        }

        if (!response.ok) {
          throw new Error(`API error: ${response.status}`)
        }

        const result = await response.json()

        // Fix: Verify result is not null before setting state
        if (result) {
          setData(result)
        } else {
          setError('No data received from server')
        }
      } catch (err) {
        setError(err?.message || 'Failed to fetch data')
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  return (
    <div className="container">
      <h1>MR Ready Prep</h1>

      {loading && <p>Loading...</p>}
      {error && <p className="error">Error: {error}</p>}
      {data && (
        <div className="data-display">
          <pre>{JSON.stringify(data, null, 2)}</pre>
        </div>
      )}
    </div>
  )
}

export default App
