# MR Ready Prep - Frontend

This is a React + Vite frontend application for MR Ready Prep.

## Fixes Applied

### 1. Fixed: "Cannot read properties of null (reading 'useEffect')"

**Issue**: This error occurs when React hooks are called outside of a component, or when React is not properly imported.

**Solution** (in `src/App.jsx`):
- Properly imported React hooks: `import { useState, useEffect } from 'react'`
- Implemented proper null checks in useEffect before accessing response data
- Added validation checks before using fetched data
- Properly handled error states with try-catch

**Key Changes**:
```jsx
// Proper hook usage inside component
useEffect(() => {
  const fetchData = async () => {
    try {
      const response = await fetch(`${apiUrl}/api/data`)
      if (!response) {
        throw new Error('No response from server')
      }
      if (!response.ok) {
        throw new Error(`API error: ${response.status}`)
      }
      const result = await response.json()
      if (result) {
        setData(result)
      }
    } catch (err) {
      setError(err?.message || 'Failed to fetch data')
    } finally {
      setLoading(false)
    }
  }
  fetchData()
}, [])
```

### 2. Fixed: "Cannot use 'import.meta' outside a module"

**Issue**: This error occurs when `import.meta` is used in non-ESM (CommonJS) contexts or in regular script tags.

**Solution** (in `src/main.jsx` and `vite.config.js`):
- Ensured `import.meta` is only used in ES module files
- Properly configured Vite to support environment variables
- Used `import.meta.env` only in `.jsx` files (which are modules)
- Configured vite.config.js to properly handle module imports

**Key Changes**:
- `index.html`: Uses `<script type="module" src="/src/main.jsx"></script>` (module context)
- `src/main.jsx`: `const API_URL = import.meta.env.VITE_API_URL` (in module context)
- `vite.config.js`: Properly configured to handle ES modules

### 3. Additional Fixes

- Added proper error handling and fallback values
- Implemented null/undefined checks before accessing object properties
- Added environment variable configuration example (`.env.example`)
- Ensured all imports use proper ES6 module syntax

## Setup

1. Install dependencies:
```bash
npm install
```

2. Create `.env` file from `.env.example`:
```bash
cp .env.example .env
```

3. Update `.env` with your API URL:
```
VITE_API_URL=https://mrreadyprep-api.onrender.com
```

4. Run development server:
```bash
npm run dev
```

5. Build for production:
```bash
npm run build
```

## Environment Configuration

The application uses Vite's environment variable system. Variables prefixed with `VITE_` are exposed to client-side code:

- `VITE_API_URL`: The backend API URL (must be set in `.env` or through Render environment variables)

## Troubleshooting

If you still see "Cannot use 'import.meta' outside a module" errors:
1. Ensure all `.js` files are actually `.jsx` files or have proper ES module configuration
2. Check that `<script>` tags in HTML have `type="module"` attribute
3. Verify Vite config is properly loading the React plugin

If you still see useEffect errors:
1. Ensure React is imported: `import { useEffect } from 'react'`
2. Only call hooks inside React components
3. Check for null checks before accessing object properties
