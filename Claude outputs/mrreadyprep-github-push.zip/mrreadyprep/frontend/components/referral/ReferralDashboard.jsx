/**
 * Referral Dashboard Component
 * Main referral program interface
 *
 * Features:
 * - Referral link with QR code
 * - Share functionality
 * - Stats overview
 * - Leaderboard
 * - History and rewards tracking
 */

import React, { useState, useEffect } from 'react';
import { Copy, Share2, TrendingUp, DollarSign, Users, Award } from 'lucide-react';
import ReferralShareModal from './ReferralShareModal';
import ReferralLeaderboard from './ReferralLeaderboard';
import ReferralHistory from './ReferralHistory';
import RewardsTracker from './RewardsTracker';

const ReferralDashboard = () => {
  const [referralLink, setReferralLink] = useState(null);
  const [stats, setStats] = useState(null);
  const [showShareModal, setShowShareModal] = useState(false);
  const [activeTab, setActiveTab] = useState('overview');
  const [copied, setCopied] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const brandColor = '#701fa1';
  const accentColor = '#10b981';
  const lightBg = '#f9fafb';

  useEffect(() => {
    fetchReferralData();
  }, []);

  const fetchReferralData = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem('token');

      // Fetch referral link
      const linkRes = await fetch('/api/referrals/generate-link', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (!linkRes.ok) throw new Error('Failed to fetch referral link');
      const linkData = await linkRes.json();
      setReferralLink(linkData);

      // Fetch stats
      const statsRes = await fetch('/api/referrals/stats', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (!statsRes.ok) throw new Error('Failed to fetch stats');
      const statsData = await statsRes.json();
      setStats(statsData);

      setError(null);
    } catch (err) {
      console.error('Error fetching referral data:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = async () => {
    if (referralLink?.referral_url) {
      try {
        await navigator.clipboard.writeText(referralLink.referral_url);
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      } catch (err) {
        console.error('Failed to copy:', err);
      }
    }
  };

  if (loading) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', minHeight: '80vh' }}>
        <div style={{ textAlign: 'center' }}>
          <div style={{
            width: '40px',
            height: '40px',
            border: `4px solid ${lightBg}`,
            borderTop: `4px solid ${brandColor}`,
            borderRadius: '50%',
            animation: 'spin 1s linear infinite',
            margin: '0 auto 20px'
          }}></div>
          <p style={{ color: '#666', fontSize: '16px' }}>Loading referral data...</p>
        </div>
      </div>
    );
  }

  return (
    <div style={{
      backgroundColor: '#fff',
      minHeight: '100vh',
      padding: '0',
      position: 'fixed',
      width: '100%',
      height: '100%',
      overflowY: 'auto'
    }}>
      {/* Header */}
      <div style={{
        background: `linear-gradient(135deg, ${brandColor} 0%, #9333ea 100%)`,
        color: '#fff',
        padding: '40px 20px',
        textAlign: 'center'
      }}>
        <h1 style={{ fontSize: '32px', fontWeight: 'bold', margin: '0 0 10px 0' }}>
          Referral Program
        </h1>
        <p style={{ fontSize: '16px', opacity: 0.95, margin: 0 }}>
          Earn $5 for each friend who joins • They get 50% off
        </p>
      </div>

      {/* Main Content */}
      <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '30px 20px' }}>

        {error && (
          <div style={{
            backgroundColor: '#fee2e2',
            border: `1px solid #fca5a5`,
            color: '#dc2626',
            padding: '15px',
            borderRadius: '8px',
            marginBottom: '20px'
          }}>
            {error}
          </div>
        )}

        {/* Referral Link Section */}
        {referralLink && (
          <div style={{
            backgroundColor: lightBg,
            border: `2px solid ${brandColor}`,
            borderRadius: '12px',
            padding: '30px',
            marginBottom: '30px',
            textAlign: 'center'
          }}>
            <h2 style={{ fontSize: '20px', fontWeight: 'bold', color: '#000', marginBottom: '20px' }}>
              Your Referral Link
            </h2>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '30px', marginBottom: '30px' }}>
              {/* Link Section */}
              <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
                <div style={{
                  backgroundColor: '#fff',
                  border: `1px solid #e5e7eb`,
                  borderRadius: '8px',
                  padding: '15px',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  marginBottom: '15px'
                }}>
                  <code style={{
                    fontFamily: 'monospace',
                    fontSize: '14px',
                    color: brandColor,
                    fontWeight: 'bold'
                  }}>
                    {referralLink.referral_url}
                  </code>
                  <button
                    onClick={copyToClipboard}
                    style={{
                      background: 'none',
                      border: 'none',
                      cursor: 'pointer',
                      padding: '5px',
                      color: brandColor,
                      fontSize: '18px',
                      display: 'flex',
                      alignItems: 'center'
                    }}
                    title={copied ? 'Copied!' : 'Copy to clipboard'}
                  >
                    <Copy size={20} />
                  </button>
                </div>

                <button
                  onClick={() => setShowShareModal(true)}
                  style={{
                    background: `linear-gradient(135deg, ${brandColor} 0%, #9333ea 100%)`,
                    color: '#fff',
                    border: 'none',
                    borderRadius: '8px',
                    padding: '12px 24px',
                    fontSize: '16px',
                    fontWeight: 'bold',
                    cursor: 'pointer',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    gap: '8px',
                    transition: 'transform 0.2s'
                  }}
                  onMouseEnter={(e) => e.target.style.transform = 'translateY(-2px)'}
                  onMouseLeave={(e) => e.target.style.transform = 'translateY(0)'}
                >
                  <Share2 size={18} />
                  Share with Friends
                </button>

                {copied && (
                  <p style={{
                    color: accentColor,
                    fontSize: '14px',
                    marginTop: '10px',
                    fontWeight: 'bold'
                  }}>
                    ✓ Copied to clipboard!
                  </p>
                )}
              </div>

              {/* QR Code Section */}
              {referralLink.qr_code_url && (
                <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                  <div style={{
                    backgroundColor: '#fff',
                    padding: '15px',
                    borderRadius: '8px',
                    border: `1px solid #e5e7eb`
                  }}>
                    <img
                      src={referralLink.qr_code_url}
                      alt="Referral QR Code"
                      style={{
                        width: '180px',
                        height: '180px',
                        borderRadius: '4px'
                      }}
                    />
                    <p style={{
                      fontSize: '12px',
                      color: '#666',
                      marginTop: '10px',
                      textAlign: 'center'
                    }}>
                      Scan to share
                    </p>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Stats Cards */}
        {stats && (
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
            gap: '20px',
            marginBottom: '30px'
          }}>
            {/* Total Referrals */}
            <div style={{
              backgroundColor: '#fff',
              border: `1px solid #e5e7eb`,
              borderRadius: '12px',
              padding: '20px',
              boxShadow: '0 1px 3px rgba(0,0,0,0.1)'
            }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '10px' }}>
                <h3 style={{ fontSize: '14px', color: '#666', margin: 0, fontWeight: '600' }}>
                  Total Referrals
                </h3>
                <Users size={20} style={{ color: brandColor }} />
              </div>
              <p style={{ fontSize: '32px', fontWeight: 'bold', margin: '0', color: '#000' }}>
                {stats.total_referrals}
              </p>
              <p style={{ fontSize: '12px', color: '#999', margin: '5px 0 0 0' }}>
                {stats.converted_referrals} converted
              </p>
            </div>

            {/* Earnings */}
            <div style={{
              backgroundColor: '#fff',
              border: `1px solid #e5e7eb`,
              borderRadius: '12px',
              padding: '20px',
              boxShadow: '0 1px 3px rgba(0,0,0,0.1)'
            }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '10px' }}>
                <h3 style={{ fontSize: '14px', color: '#666', margin: 0, fontWeight: '600' }}>
                  Total Earnings
                </h3>
                <DollarSign size={20} style={{ color: accentColor }} />
              </div>
              <p style={{ fontSize: '32px', fontWeight: 'bold', margin: '0', color: '#000' }}>
                ${stats.total_earnings.toFixed(2)}
              </p>
              <p style={{ fontSize: '12px', color: '#999', margin: '5px 0 0 0' }}>
                Available credit
              </p>
            </div>

            {/* Available Credit */}
            <div style={{
              backgroundColor: '#fff',
              border: `1px solid #e5e7eb`,
              borderRadius: '12px',
              padding: '20px',
              boxShadow: '0 1px 3px rgba(0,0,0,0.1)'
            }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '10px' }}>
                <h3 style={{ fontSize: '14px', color: '#666', margin: 0, fontWeight: '600' }}>
                  Available Credit
                </h3>
                <Award size={20} style={{ color: '#f59e0b' }} />
              </div>
              <p style={{ fontSize: '32px', fontWeight: 'bold', margin: '0', color: '#000' }}>
                ${stats.available_credit.toFixed(2)}
              </p>
              <p style={{ fontSize: '12px', color: '#999', margin: '5px 0 0 0' }}>
                Ready to redeem
              </p>
            </div>

            {/* Conversion Rate */}
            <div style={{
              backgroundColor: '#fff',
              border: `1px solid #e5e7eb`,
              borderRadius: '12px',
              padding: '20px',
              boxShadow: '0 1px 3px rgba(0,0,0,0.1)'
            }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '10px' }}>
                <h3 style={{ fontSize: '14px', color: '#666', margin: 0, fontWeight: '600' }}>
                  Conversion Rate
                </h3>
                <TrendingUp size={20} style={{ color: '#3b82f6' }} />
              </div>
              <p style={{ fontSize: '32px', fontWeight: 'bold', margin: '0', color: '#000' }}>
                {stats.conversion_rate.toFixed(1)}%
              </p>
              <p style={{ fontSize: '12px', color: '#999', margin: '5px 0 0 0' }}>
                of referrals
              </p>
            </div>
          </div>
        )}

        {/* Tabs */}
        <div style={{
          borderBottom: `2px solid #e5e7eb`,
          marginBottom: '20px',
          display: 'flex',
          gap: '0'
        }}>
          {['overview', 'leaderboard', 'history', 'rewards'].map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              style={{
                background: 'none',
                border: 'none',
                padding: '15px 20px',
                fontSize: '16px',
                fontWeight: activeTab === tab ? 'bold' : '500',
                color: activeTab === tab ? brandColor : '#666',
                cursor: 'pointer',
                borderBottom: activeTab === tab ? `3px solid ${brandColor}` : 'none',
                textTransform: 'capitalize',
                transition: 'all 0.3s'
              }}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <div>
          {activeTab === 'overview' && stats && (
            <div>
              <p style={{ color: '#666', fontSize: '16px', marginBottom: '20px' }}>
                Welcome to your referral dashboard! Share your unique link to earn $5 for each friend who signs up. Your friends get 50% off their first month too!
              </p>
            </div>
          )}
          {activeTab === 'leaderboard' && <ReferralLeaderboard />}
          {activeTab === 'history' && <ReferralHistory />}
          {activeTab === 'rewards' && <RewardsTracker onRefresh={fetchReferralData} />}
        </div>
      </div>

      {/* Share Modal */}
      {showShareModal && referralLink && (
        <ReferralShareModal
          referralLink={referralLink.referral_url}
          shareText={referralLink.share_text}
          onClose={() => setShowShareModal(false)}
        />
      )}

      <style>{`
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
};

export default ReferralDashboard;
