/**
 * Referral History Component
 * Display detailed referral tracking
 */

import React, { useState, useEffect } from 'react';
import { CheckCircle, Clock, XCircle, ChevronLeft, ChevronRight } from 'lucide-react';

const ReferralHistory = () => {
  const [history, setHistory] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [page, setPage] = useState(1);
  const [statusFilter, setStatusFilter] = useState(null);

  const brandColor = '#701fa1';

  const statusConfig = {
    pending: {
      icon: Clock,
      color: '#f59e0b',
      label: 'Pending',
      bgColor: '#fef3c7'
    },
    converted: {
      icon: CheckCircle,
      color: '#10b981',
      label: 'Converted',
      bgColor: '#f0fdf4'
    },
    paid: {
      icon: CheckCircle,
      color: '#0ea5e9',
      label: 'Paid',
      bgColor: '#f0f9ff'
    }
  };

  useEffect(() => {
    fetchHistory();
  }, [page, statusFilter]);

  const fetchHistory = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem('token');
      const params = new URLSearchParams({
        page,
        per_page: 10
      });

      if (statusFilter) {
        params.append('status_filter', statusFilter);
      }

      const res = await fetch(`/api/referrals/history?${params}`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });

      if (!res.ok) throw new Error('Failed to fetch history');
      const data = await res.json();
      setHistory(data);
      setError(null);
    } catch (err) {
      console.error('Error fetching history:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const getStatusInfo = (status) => {
    return statusConfig[status] || statusConfig.pending;
  };

  if (loading) {
    return (
      <div style={{ textAlign: 'center', padding: '40px 20px' }}>
        <div style={{
          display: 'inline-block',
          width: '40px',
          height: '40px',
          border: `4px solid #f0f0f0`,
          borderTop: `4px solid ${brandColor}`,
          borderRadius: '50%',
          animation: 'spin 1s linear infinite'
        }}></div>
      </div>
    );
  }

  if (error) {
    return (
      <div style={{
        backgroundColor: '#fee2e2',
        border: `1px solid #fca5a5`,
        color: '#dc2626',
        padding: '15px',
        borderRadius: '8px'
      }}>
        Error: {error}
      </div>
    );
  }

  return (
    <div>
      {/* Filters */}
      <div style={{
        display: 'flex',
        gap: '10px',
        marginBottom: '20px',
        flexWrap: 'wrap'
      }}>
        <button
          onClick={() => {
            setStatusFilter(null);
            setPage(1);
          }}
          style={{
            padding: '8px 16px',
            borderRadius: '6px',
            border: statusFilter === null ? `2px solid ${brandColor}` : `1px solid #e5e7eb`,
            backgroundColor: statusFilter === null ? `${brandColor}20` : '#fff',
            color: statusFilter === null ? brandColor : '#666',
            fontWeight: '600',
            cursor: 'pointer',
            fontSize: '14px',
            transition: 'all 0.3s'
          }}
        >
          All
        </button>

        {['pending', 'converted', 'paid'].map((status) => (
          <button
            key={status}
            onClick={() => {
              setStatusFilter(status);
              setPage(1);
            }}
            style={{
              padding: '8px 16px',
              borderRadius: '6px',
              border: statusFilter === status ? `2px solid ${brandColor}` : `1px solid #e5e7eb`,
              backgroundColor: statusFilter === status ? `${brandColor}20` : '#fff',
              color: statusFilter === status ? brandColor : '#666',
              fontWeight: '600',
              cursor: 'pointer',
              fontSize: '14px',
              textTransform: 'capitalize',
              transition: 'all 0.3s'
            }}
          >
            {status}
          </button>
        ))}
      </div>

      {/* History List */}
      {history?.referrals && history.referrals.length > 0 ? (
        <div>
          <div style={{
            display: 'grid',
            gap: '12px',
            marginBottom: '20px'
          }}>
            {history.referrals.map((referral) => {
              const statusInfo = getStatusInfo(referral.status);
              const StatusIcon = statusInfo.icon;

              return (
                <div
                  key={referral.id}
                  style={{
                    backgroundColor: statusInfo.bgColor,
                    border: `1px solid #e5e7eb`,
                    borderRadius: '8px',
                    padding: '15px',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center'
                  }}
                >
                  {/* Left Side */}
                  <div style={{ flex: 1 }}>
                    <div style={{
                      display: 'flex',
                      alignItems: 'center',
                      gap: '12px',
                      marginBottom: '8px'
                    }}>
                      <StatusIcon size={18} style={{ color: statusInfo.color }} />
                      <div>
                        <p style={{
                          margin: 0,
                          fontSize: '14px',
                          fontWeight: '600',
                          color: '#000'
                        }}>
                          {referral.referred_user_email || 'Unknown User'}
                        </p>
                        <p style={{
                          margin: '4px 0 0 0',
                          fontSize: '12px',
                          color: '#666'
                        }}>
                          {referral.status === 'converted' && referral.conversion_date
                            ? `Converted on ${formatDate(referral.conversion_date)}`
                            : `Referred on ${formatDate(referral.created_at)}`}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Status */}
                  <div style={{
                    textAlign: 'right',
                    marginRight: '20px'
                  }}>
                    <p style={{
                      margin: 0,
                      fontSize: '12px',
                      fontWeight: '600',
                      color: statusInfo.color,
                      textTransform: 'capitalize'
                    }}>
                      {statusInfo.label}
                    </p>
                    {referral.is_paid && (
                      <p style={{
                        margin: '4px 0 0 0',
                        fontSize: '12px',
                        color: '#666'
                      }}>
                        {referral.is_paid ? 'Paid out' : 'Pending payout'}
                      </p>
                    )}
                  </div>

                  {/* Reward Amount */}
                  <div style={{
                    textAlign: 'right',
                    minWidth: '80px'
                  }}>
                    <p style={{
                      margin: 0,
                      fontSize: '18px',
                      fontWeight: 'bold',
                      color: brandColor
                    }}>
                      ${parseFloat(referral.reward_amount).toFixed(2)}
                    </p>
                    <p style={{
                      margin: '4px 0 0 0',
                      fontSize: '11px',
                      color: '#999'
                    }}>
                      reward
                    </p>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Pagination */}
          {history.total_pages > 1 && (
            <div style={{
              display: 'flex',
              justifyContent: 'center',
              alignItems: 'center',
              gap: '15px',
              marginTop: '30px'
            }}>
              <button
                onClick={() => setPage(Math.max(1, page - 1))}
                disabled={page === 1}
                style={{
                  background: page === 1 ? '#f0f0f0' : '#fff',
                  border: `1px solid #e5e7eb`,
                  borderRadius: '6px',
                  padding: '8px 12px',
                  cursor: page === 1 ? 'not-allowed' : 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  color: page === 1 ? '#999' : '#333',
                  opacity: page === 1 ? 0.5 : 1
                }}
              >
                <ChevronLeft size={18} />
              </button>

              <div style={{
                display: 'flex',
                gap: '8px',
                alignItems: 'center'
              }}>
                {Array.from({ length: Math.min(5, history.total_pages) }, (_, i) => {
                  const pageNum = i + 1;
                  return (
                    <button
                      key={pageNum}
                      onClick={() => setPage(pageNum)}
                      style={{
                        backgroundColor: pageNum === page ? brandColor : '#fff',
                        color: pageNum === page ? '#fff' : '#333',
                        border: `1px solid ${pageNum === page ? brandColor : '#e5e7eb'}`,
                        borderRadius: '4px',
                        padding: '6px 10px',
                        cursor: 'pointer',
                        fontWeight: pageNum === page ? 'bold' : '500',
                        fontSize: '14px'
                      }}
                    >
                      {pageNum}
                    </button>
                  );
                })}
              </div>

              <button
                onClick={() => setPage(Math.min(history.total_pages, page + 1))}
                disabled={page === history.total_pages}
                style={{
                  background: page === history.total_pages ? '#f0f0f0' : '#fff',
                  border: `1px solid #e5e7eb`,
                  borderRadius: '6px',
                  padding: '8px 12px',
                  cursor: page === history.total_pages ? 'not-allowed' : 'pointer',
                  display: 'flex',
                  alignItems: 'center',
                  color: page === history.total_pages ? '#999' : '#333',
                  opacity: page === history.total_pages ? 0.5 : 1
                }}
              >
                <ChevronRight size={18} />
              </button>
            </div>
          )}

          {/* Summary */}
          <div style={{
            backgroundColor: '#f9fafb',
            border: `1px solid #e5e7eb`,
            borderRadius: '8px',
            padding: '15px',
            marginTop: '20px',
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))',
            gap: '15px'
          }}>
            <div>
              <p style={{ fontSize: '12px', color: '#666', margin: 0, marginBottom: '5px' }}>
                Total Referrals
              </p>
              <p style={{ fontSize: '18px', fontWeight: 'bold', margin: 0, color: '#000' }}>
                {history.total_count}
              </p>
            </div>
            <div>
              <p style={{ fontSize: '12px', color: '#666', margin: 0, marginBottom: '5px' }}>
                Page {page} of {history.total_pages}
              </p>
              <p style={{ fontSize: '18px', fontWeight: 'bold', margin: 0, color: '#000' }}>
                {history.referrals.length} shown
              </p>
            </div>
          </div>
        </div>
      ) : (
        <div style={{
          textAlign: 'center',
          padding: '40px 20px',
          backgroundColor: '#f9fafb',
          borderRadius: '8px'
        }}>
          <p style={{ fontSize: '16px', color: '#666', margin: 0 }}>
            No referrals found. Share your link to start earning!
          </p>
        </div>
      )}

      <style>{`
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
};

export default ReferralHistory;
