/**
 * Referral Share Modal Component
 * Social sharing interface (WhatsApp, Email, Twitter, LinkedIn, Copy)
 */

import React, { useState } from 'react';
import { X, Copy, Mail, MessageCircle, Heart, Linkedin } from 'lucide-react';

const ReferralShareModal = ({ referralLink, shareText, onClose }) => {
  const [copied, setCopied] = useState(false);
  const brandColor = '#701fa1';

  const shareOptions = [
    {
      id: 'email',
      name: 'Email',
      icon: Mail,
      action: () => {
        const subject = encodeURIComponent('Join MRReadyPrep - 50% Off TOEFL Prep');
        const body = encodeURIComponent(`${shareText}\n\n${referralLink}`);
        window.location.href = `mailto:?subject=${subject}&body=${body}`;
      },
      color: '#ea4335'
    },
    {
      id: 'whatsapp',
      name: 'WhatsApp',
      icon: MessageCircle,
      action: () => {
        const text = encodeURIComponent(`${shareText}\n\n${referralLink}`);
        window.open(`https://wa.me/?text=${text}`, '_blank');
      },
      color: '#25d366'
    },
    {
      id: 'twitter',
      name: 'Twitter',
      icon: Heart,
      action: () => {
        const text = encodeURIComponent(`${shareText} ${referralLink}`);
        window.open(`https://twitter.com/intent/tweet?text=${text}`, '_blank');
      },
      color: '#1da1f2'
    },
    {
      id: 'linkedin',
      name: 'LinkedIn',
      icon: Linkedin,
      action: () => {
        const text = encodeURIComponent(`${shareText}`);
        const url = encodeURIComponent(referralLink);
        window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${url}`, '_blank');
      },
      color: '#0a66c2'
    }
  ];

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(`${shareText}\n\n${referralLink}`);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      backgroundColor: 'rgba(0, 0, 0, 0.5)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 1000,
      padding: '20px'
    }}>
      <div style={{
        backgroundColor: '#fff',
        borderRadius: '12px',
        width: '100%',
        maxWidth: '500px',
        boxShadow: '0 20px 25px rgba(0, 0, 0, 0.15)',
        overflow: 'hidden'
      }}>
        {/* Header */}
        <div style={{
          background: `linear-gradient(135deg, ${brandColor} 0%, #9333ea 100%)`,
          color: '#fff',
          padding: '20px',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center'
        }}>
          <h2 style={{ margin: 0, fontSize: '20px', fontWeight: 'bold' }}>
            Share Your Referral Link
          </h2>
          <button
            onClick={onClose}
            style={{
              background: 'none',
              border: 'none',
              color: '#fff',
              cursor: 'pointer',
              fontSize: '24px',
              display: 'flex',
              alignItems: 'center',
              padding: '0'
            }}
          >
            <X size={24} />
          </button>
        </div>

        {/* Content */}
        <div style={{ padding: '30px' }}>
          {/* Referral Link Display */}
          <div style={{ marginBottom: '30px' }}>
            <p style={{ fontSize: '14px', color: '#666', marginBottom: '10px', fontWeight: '600' }}>
              Your Referral Link:
            </p>
            <div style={{
              backgroundColor: '#f9fafb',
              border: `1px solid #e5e7eb`,
              borderRadius: '8px',
              padding: '12px',
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
              gap: '10px'
            }}>
              <code style={{
                fontFamily: 'monospace',
                fontSize: '12px',
                color: '#333',
                wordBreak: 'break-all',
                flex: 1
              }}>
                {referralLink}
              </code>
              <button
                onClick={copyToClipboard}
                style={{
                  background: 'none',
                  border: 'none',
                  cursor: 'pointer',
                  color: brandColor,
                  display: 'flex',
                  alignItems: 'center',
                  fontSize: '18px',
                  flexShrink: 0
                }}
              >
                <Copy size={18} />
              </button>
            </div>
            {copied && (
              <p style={{
                fontSize: '12px',
                color: '#10b981',
                marginTop: '8px',
                fontWeight: '600'
              }}>
                ✓ Copied!
              </p>
            )}
          </div>

          {/* Share Options */}
          <div>
            <p style={{ fontSize: '14px', color: '#666', marginBottom: '15px', fontWeight: '600' }}>
              Share on Social Media:
            </p>
            <div style={{
              display: 'grid',
              gridTemplateColumns: 'repeat(2, 1fr)',
              gap: '15px',
              marginBottom: '20px'
            }}>
              {shareOptions.map((option) => {
                const Icon = option.icon;
                return (
                  <button
                    key={option.id}
                    onClick={option.action}
                    style={{
                      backgroundColor: '#f9fafb',
                      border: `2px solid ${option.color}`,
                      borderRadius: '8px',
                      padding: '15px',
                      cursor: 'pointer',
                      display: 'flex',
                      flexDirection: 'column',
                      alignItems: 'center',
                      gap: '8px',
                      transition: 'all 0.3s',
                      fontSize: '14px',
                      fontWeight: '600',
                      color: option.color
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.backgroundColor = option.color;
                      e.currentTarget.style.color = '#fff';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.backgroundColor = '#f9fafb';
                      e.currentTarget.style.color = option.color;
                    }}
                  >
                    <Icon size={24} />
                    {option.name}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Share Text Preview */}
          <div style={{
            backgroundColor: '#f0fdf4',
            border: `1px solid #86efac`,
            borderRadius: '8px',
            padding: '15px',
            marginTop: '20px'
          }}>
            <p style={{ fontSize: '12px', color: '#666', marginBottom: '8px', fontWeight: '600' }}>
              Message Preview:
            </p>
            <p style={{
              fontSize: '14px',
              color: '#333',
              margin: 0,
              lineHeight: '1.6',
              fontStyle: 'italic'
            }}>
              "{shareText}"
            </p>
          </div>

          {/* Close Button */}
          <button
            onClick={onClose}
            style={{
              width: '100%',
              backgroundColor: '#f9fafb',
              border: `1px solid #e5e7eb`,
              borderRadius: '8px',
              padding: '12px',
              marginTop: '20px',
              fontSize: '16px',
              fontWeight: '600',
              color: '#666',
              cursor: 'pointer',
              transition: 'all 0.3s'
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.backgroundColor = '#f3f4f6';
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.backgroundColor = '#f9fafb';
            }}
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};

export default ReferralShareModal;
