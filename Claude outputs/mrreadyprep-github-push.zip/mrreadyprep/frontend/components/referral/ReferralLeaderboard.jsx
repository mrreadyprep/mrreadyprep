/**
 * Referral Leaderboard Component
 * Display top referrers
 */

import React, { useState, useEffect } from 'react';
import { Trophy, Award, TrendingUp } from 'lucide-react';

const ReferralLeaderboard = () => {
  const [leaderboard, setLeaderboard] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const brandColor = '#701fa1';
  const medalColors = {
    1: '#fbbf24', // gold
    2: '#d1d5db', // silver
    3: '#d97706'  // bronze
  };

  useEffect(() => {
    fetchLeaderboard();
  }, []);

  const fetchLeaderboard = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem('token');
      const res = await fetch('/api/referrals/leaderboard?limit=20', {
        headers: { 'Authorization': `Bearer ${token}` }
      });

      if (!res.ok) throw new Error('Failed to fetch leaderboard');
      const data = await res.json();
      setLeaderboard(data);
      setError(null);
    } catch (err) {
      console.error('Error fetching leaderboard:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div style={{ textAlign: 'center', padding: '40px 20px' }}>
        <div style={{
          display: 'inline-block',
          width: '40px',
          height: '40px',
          border: `4px solid #f0f0f0`,
          borderTop: `4px solid ${brandColor}`,
          borderRadius: '50%',
          animation: 'spin 1s linear infinite'
        }}></div>
      </div>
    );
  }

  if (error) {
    return (
      <div style={{
        backgroundColor: '#fee2e2',
        border: `1px solid #fca5a5`,
        color: '#dc2626',
        padding: '15px',
        borderRadius: '8px'
      }}>
        Error: {error}
      </div>
    );
  }

  return (
    <div>
      {leaderboard?.entries && leaderboard.entries.length > 0 ? (
        <div>
          {/* User's Rank */}
          {leaderboard.user_rank && (
            <div style={{
              backgroundColor: '#f0fdf4',
              border: `2px solid #22c55e`,
              borderRadius: '12px',
              padding: '20px',
              marginBottom: '30px'
            }}>
              <div style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'space-between'
              }}>
                <div>
                  <p style={{ fontSize: '14px', color: '#666', margin: 0, marginBottom: '5px' }}>
                    Your Ranking
                  </p>
                  <h3 style={{
                    fontSize: '28px',
                    fontWeight: 'bold',
                    color: '#22c55e',
                    margin: 0
                  }}>
                    #{leaderboard.user_rank} of {leaderboard.entries.length}
                  </h3>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <p style={{ fontSize: '14px', color: '#666', margin: 0, marginBottom: '5px' }}>
                    Your Earnings
                  </p>
                  <p style={{
                    fontSize: '24px',
                    fontWeight: 'bold',
                    color: '#22c55e',
                    margin: 0
                  }}>
                    ${leaderboard.user_earnings.toFixed(2)}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Leaderboard Table */}
          <div style={{
            backgroundColor: '#fff',
            border: `1px solid #e5e7eb`,
            borderRadius: '12px',
            overflow: 'hidden'
          }}>
            <div style={{
              display: 'grid',
              gridTemplateColumns: '60px 1fr 120px 120px',
              gap: '0',
              backgroundColor: '#f9fafb',
              padding: '15px 20px',
              borderBottom: `1px solid #e5e7eb`,
              fontWeight: '600',
              fontSize: '14px',
              color: '#666'
            }}>
              <div>Rank</div>
              <div>User</div>
              <div style={{ textAlign: 'right' }}>Referrals</div>
              <div style={{ textAlign: 'right' }}>Earnings</div>
            </div>

            {leaderboard.entries.map((entry, index) => (
              <div
                key={entry.user_id}
                style={{
                  display: 'grid',
                  gridTemplateColumns: '60px 1fr 120px 120px',
                  gap: '0',
                  padding: '15px 20px',
                  borderBottom: index < leaderboard.entries.length - 1 ? `1px solid #f0f0f0` : 'none',
                  alignItems: 'center',
                  backgroundColor: entry.rank <= 3 ? `${medalColors[entry.rank]}15` : '#fff'
                }}
              >
                {/* Rank */}
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '8px',
                  fontSize: '16px',
                  fontWeight: 'bold'
                }}>
                  {entry.rank <= 3 ? (
                    <Trophy size={20} style={{ color: medalColors[entry.rank] }} />
                  ) : (
                    <span style={{ color: '#999' }}>#{entry.rank}</span>
                  )}
                </div>

                {/* User Info */}
                <div style={{
                  display: 'flex',
                  alignItems: 'center',
                  gap: '12px'
                }}>
                  {entry.user_avatar ? (
                    <img
                      src={entry.user_avatar}
                      alt={entry.user_name}
                      style={{
                        width: '40px',
                        height: '40px',
                        borderRadius: '50%',
                        objectFit: 'cover'
                      }}
                    />
                  ) : (
                    <div style={{
                      width: '40px',
                      height: '40px',
                      borderRadius: '50%',
                      backgroundColor: brandColor,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      color: '#fff',
                      fontWeight: 'bold',
                      fontSize: '18px'
                    }}>
                      {entry.user_name.charAt(0).toUpperCase()}
                    </div>
                  )}
                  <div>
                    <p style={{ margin: 0, fontWeight: '600', fontSize: '14px' }}>
                      {entry.user_name}
                    </p>
                    <p style={{ margin: '4px 0 0 0', fontSize: '12px', color: '#999' }}>
                      {entry.conversion_rate.toFixed(1)}% conversion
                    </p>
                  </div>
                </div>

                {/* Referrals Count */}
                <div style={{
                  textAlign: 'right',
                  fontWeight: '600',
                  fontSize: '16px',
                  color: '#000'
                }}>
                  {entry.total_referrals}
                </div>

                {/* Earnings */}
                <div style={{
                  textAlign: 'right',
                  fontWeight: '600',
                  fontSize: '16px',
                  color: brandColor
                }}>
                  ${entry.total_earnings.toFixed(2)}
                </div>
              </div>
            ))}
          </div>

          {/* Footer Stats */}
          <div style={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            gap: '20px',
            marginTop: '30px'
          }}>
            <div style={{
              backgroundColor: '#f9fafb',
              border: `1px solid #e5e7eb`,
              borderRadius: '8px',
              padding: '20px',
              textAlign: 'center'
            }}>
              <Award size={24} style={{ color: brandColor, marginBottom: '10px', margin: '0 auto 10px auto', display: 'block' }} />
              <p style={{ fontSize: '12px', color: '#666', margin: '0 0 5px 0' }}>
                Top Referrer
              </p>
              <p style={{
                fontSize: '18px',
                fontWeight: 'bold',
                margin: 0,
                color: '#000'
              }}>
                {leaderboard.entries[0]?.user_name}
              </p>
              <p style{{
                fontSize: '14px',
                color: brandColor,
                margin: '5px 0 0 0',
                fontWeight: '600'
              }}>
                {leaderboard.entries[0]?.total_referrals} referrals
              </p>
            </div>

            <div style={{
              backgroundColor: '#f9fafb',
              border: `1px solid #e5e7eb`,
              borderRadius: '8px',
              padding: '20px',
              textAlign: 'center'
            }}>
              <TrendingUp size={24} style={{ color: '#10b981', marginBottom: '10px', margin: '0 auto 10px auto', display: 'block' }} />
              <p style={{ fontSize: '12px', color: '#666', margin: '0 0 5px 0' }}>
                Program Total
              </p>
              <p style={{
                fontSize: '18px',
                fontWeight: 'bold',
                margin: 0,
                color: '#000'
              }}>
                ${leaderboard.entries.reduce((sum, e) => sum + e.total_earnings, 0).toFixed(2)}
              </p>
              <p style={{
                fontSize: '14px',
                color: '#10b981',
                margin: '5px 0 0 0',
                fontWeight: '600'
              }}>
                distributed
              </p>
            </div>
          </div>
        </div>
      ) : (
        <div style={{
          textAlign: 'center',
          padding: '40px 20px',
          backgroundColor: '#f9fafb',
          borderRadius: '8px'
        }}>
          <Trophy size={32} style={{ color: '#999', margin: '0 auto 15px auto', display: 'block' }} />
          <p style={{ fontSize: '16px', color: '#666' }}>
            No referrals yet. Be the first to start earning!
          </p>
        </div>
      )}

      <style>{`
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
};

export default ReferralLeaderboard;
