/**
 * Rewards Tracker Component
 * Display credit balance and manage payouts
 */

import React, { useState, useEffect } from 'react';
import { DollarSign, TrendingDown, TrendingUp, Send } from 'lucide-react';

const RewardsTracker = ({ onRefresh }) => {
  const [balance, setBalance] = useState(null);
  const [transactions, setTransactions] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showPayoutForm, setShowPayoutForm] = useState(false);
  const [payoutAmount, setPayoutAmount] = useState('');
  const [payoutMethod, setPayoutMethod] = useState('stripe');
  const [payoutLoading, setPayoutLoading] = useState(false);
  const [payoutSuccess, setPayoutSuccess] = useState(false);

  const brandColor = '#701fa1';
  const minPayout = 20;

  useEffect(() => {
    fetchRewardData();
  }, []);

  const fetchRewardData = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem('token');

      // Fetch balance
      const balanceRes = await fetch('/api/referrals/balance', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (!balanceRes.ok) throw new Error('Failed to fetch balance');
      const balanceData = await balanceRes.json();
      setBalance(balanceData);

      // Fetch transactions
      const transRes = await fetch('/api/referrals/transactions?page=1&per_page=50', {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (!transRes.ok) throw new Error('Failed to fetch transactions');
      const transData = await transRes.json();
      setTransactions(transData);

      setError(null);
    } catch (err) {
      console.error('Error fetching reward data:', err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handlePayoutRequest = async () => {
    if (!payoutAmount || parseFloat(payoutAmount) < minPayout) {
      alert(`Minimum payout amount is $${minPayout}`);
      return;
    }

    try {
      setPayoutLoading(true);
      const token = localStorage.getItem('token');

      const res = await fetch('/api/referrals/request-payout', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          amount: parseFloat(payoutAmount),
          payout_method: payoutMethod
        })
      });

      if (!res.ok) throw new Error('Failed to request payout');

      setPayoutSuccess(true);
      setPayoutAmount('');
      setShowPayoutForm(false);
      setTimeout(() => {
        setPayoutSuccess(false);
        fetchRewardData();
        if (onRefresh) onRefresh();
      }, 2000);
    } catch (err) {
      console.error('Error requesting payout:', err);
      alert(`Error: ${err.message}`);
    } finally {
      setPayoutLoading(false);
    }
  };

  const formatDate = (dateString) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getTransactionIcon = (type) => {
    return type === 'credit' ? TrendingUp : TrendingDown;
  };

  const getTransactionColor = (type) => {
    return type === 'credit' ? '#10b981' : '#ef4444';
  };

  if (loading) {
    return (
      <div style={{ textAlign: 'center', padding: '40px 20px' }}>
        <div style={{
          display: 'inline-block',
          width: '40px',
          height: '40px',
          border: `4px solid #f0f0f0`,
          borderTop: `4px solid ${brandColor}`,
          borderRadius: '50%',
          animation: 'spin 1s linear infinite'
        }}></div>
      </div>
    );
  }

  return (
    <div>
      {error && (
        <div style={{
          backgroundColor: '#fee2e2',
          border: `1px solid #fca5a5`,
          color: '#dc2626',
          padding: '15px',
          borderRadius: '8px',
          marginBottom: '20px'
        }}>
          Error: {error}
        </div>
      )}

      {payoutSuccess && (
        <div style={{
          backgroundColor: '#f0fdf4',
          border: `1px solid #86efac`,
          color: '#22c55e',
          padding: '15px',
          borderRadius: '8px',
          marginBottom: '20px'
        }}>
          ✓ Payout request submitted successfully! You'll receive your funds within 5-7 business days.
        </div>
      )}

      {/* Balance Cards */}
      {balance && (
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(220px, 1fr))',
          gap: '20px',
          marginBottom: '30px'
        }}>
          {/* Current Balance */}
          <div style={{
            backgroundColor: `linear-gradient(135deg, ${brandColor} 0%, #9333ea 100%)`,
            color: '#fff',
            borderRadius: '12px',
            padding: '25px',
            boxShadow: '0 4px 15px rgba(0,0,0,0.1)'
          }}>
            <p style={{ fontSize: '13px', margin: '0 0 10px 0', opacity: 0.9 }}>
              Current Balance
            </p>
            <h2 style={{
              fontSize: '36px',
              fontWeight: 'bold',
              margin: '0 0 10px 0'
            }}>
              ${balance.balance.toFixed(2)}
            </h2>
            <p style={{ fontSize: '12px', margin: 0, opacity: 0.8 }}>
              Ready to withdraw
            </p>
          </div>

          {/* Total Earned */}
          <div style={{
            backgroundColor: '#fff',
            border: `2px solid #10b981`,
            borderRadius: '12px',
            padding: '25px'
          }}>
            <p style={{ fontSize: '13px', margin: '0 0 10px 0', color: '#666', fontWeight: '600' }}>
              Total Earned
            </p>
            <h2 style={{
              fontSize: '36px',
              fontWeight: 'bold',
              margin: '0 0 10px 0',
              color: '#10b981'
            }}>
              ${balance.total_earned.toFixed(2)}
            </h2>
            <p style={{ fontSize: '12px', margin: 0, color: '#999' }}>
              All time
            </p>
          </div>

          {/* Reserved Amount */}
          <div style={{
            backgroundColor: '#fff',
            border: `2px solid #f59e0b`,
            borderRadius: '12px',
            padding: '25px'
          }}>
            <p style={{ fontSize: '13px', margin: '0 0 10px 0', color: '#666', fontWeight: '600' }}>
              Reserved
            </p>
            <h2 style={{
              fontSize: '36px',
              fontWeight: 'bold',
              margin: '0 0 10px 0',
              color: '#f59e0b'
            }}>
              ${balance.reserved_amount.toFixed(2)}
            </h2>
            <p style={{ fontSize: '12px', margin: 0, color: '#999' }}>
              Pending payout
            </p>
          </div>
        </div>
      )}

      {/* Payout Section */}
      <div style={{
        backgroundColor: '#f9fafb',
        border: `1px solid #e5e7eb`,
        borderRadius: '12px',
        padding: '25px',
        marginBottom: '30px'
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '20px' }}>
          <h3 style={{ fontSize: '18px', fontWeight: 'bold', margin: 0 }}>
            Request Payout
          </h3>
          <p style={{ fontSize: '12px', color: '#999', margin: 0 }}>
            Minimum: ${minPayout}
          </p>
        </div>

        {!showPayoutForm ? (
          <button
            onClick={() => setShowPayoutForm(true)}
            disabled={!balance || balance.balance < minPayout}
            style={{
              background: balance && balance.balance >= minPayout
                ? `linear-gradient(135deg, ${brandColor} 0%, #9333ea 100%)`
                : '#ccc',
              color: '#fff',
              border: 'none',
              borderRadius: '8px',
              padding: '12px 24px',
              fontSize: '16px',
              fontWeight: 'bold',
              cursor: balance && balance.balance >= minPayout ? 'pointer' : 'not-allowed',
              display: 'flex',
              alignItems: 'center',
              gap: '8px',
              transition: 'transform 0.2s'
            }}
            onMouseEnter={(e) => {
              if (balance && balance.balance >= minPayout) {
                e.target.style.transform = 'translateY(-2px)';
              }
            }}
            onMouseLeave={(e) => {
              e.target.style.transform = 'translateY(0)';
            }}
          >
            <Send size={18} />
            Request Payout
          </button>
        ) : (
          <div style={{
            backgroundColor: '#fff',
            border: `1px solid #e5e7eb`,
            borderRadius: '8px',
            padding: '20px'
          }}>
            <div style={{ marginBottom: '20px' }}>
              <label style={{
                display: 'block',
                fontSize: '14px',
                fontWeight: '600',
                marginBottom: '8px',
                color: '#333'
              }}>
                Payout Amount (USD)
              </label>
              <input
                type="number"
                min={minPayout}
                max={balance?.balance || 0}
                step="0.01"
                value={payoutAmount}
                onChange={(e) => setPayoutAmount(e.target.value)}
                placeholder="Enter amount"
                style={{
                  width: '100%',
                  padding: '10px',
                  border: `1px solid #d1d5db`,
                  borderRadius: '6px',
                  fontSize: '16px',
                  boxSizing: 'border-box'
                }}
              />
              <p style={{
                fontSize: '12px',
                color: '#666',
                margin: '8px 0 0 0'
              }}>
                Available: ${balance?.balance.toFixed(2) || '0.00'}
              </p>
            </div>

            <div style={{ marginBottom: '20px' }}>
              <label style={{
                display: 'block',
                fontSize: '14px',
                fontWeight: '600',
                marginBottom: '8px',
                color: '#333'
              }}>
                Payout Method
              </label>
              <select
                value={payoutMethod}
                onChange={(e) => setPayoutMethod(e.target.value)}
                style={{
                  width: '100%',
                  padding: '10px',
                  border: `1px solid #d1d5db`,
                  borderRadius: '6px',
                  fontSize: '16px',
                  backgroundColor: '#fff'
                }}
              >
                <option value="stripe">Stripe (Fastest)</option>
                <option value="paypal">PayPal</option>
                <option value="bank_transfer">Bank Transfer</option>
                <option value="credit">Account Credit</option>
              </select>
            </div>

            <div style({
              display: 'flex',
              gap: '10px'
            }}>
              <button
                onClick={handlePayoutRequest}
                disabled={payoutLoading || !payoutAmount}
                style={{
                  flex: 1,
                  background: `linear-gradient(135deg, ${brandColor} 0%, #9333ea 100%)`,
                  color: '#fff',
                  border: 'none',
                  borderRadius: '6px',
                  padding: '10px',
                  fontSize: '14px',
                  fontWeight: 'bold',
                  cursor: payoutLoading || !payoutAmount ? 'not-allowed' : 'pointer',
                  opacity: payoutLoading || !payoutAmount ? 0.6 : 1
                }}
              >
                {payoutLoading ? 'Processing...' : 'Submit Payout Request'}
              </button>
              <button
                onClick={() => setShowPayoutForm(false)}
                style={{
                  flex: 1,
                  background: '#f0f0f0',
                  color: '#666',
                  border: '1px solid #e5e7eb',
                  borderRadius: '6px',
                  padding: '10px',
                  fontSize: '14px',
                  fontWeight: 'bold',
                  cursor: 'pointer'
                }}
              >
                Cancel
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Transaction History */}
      {transactions?.transactions && transactions.transactions.length > 0 && (
        <div>
          <h3 style={{ fontSize: '18px', fontWeight: 'bold', marginBottom: '15px' }}>
            Transaction History
          </h3>

          <div style={{
            display: 'grid',
            gap: '12px'
          }}>
            {transactions.transactions.map((transaction) => {
              const TIcon = getTransactionIcon(transaction.type);
              const color = getTransactionColor(transaction.type);

              return (
                <div
                  key={transaction.id}
                  style={{
                    backgroundColor: '#fff',
                    border: `1px solid #e5e7eb`,
                    borderRadius: '8px',
                    padding: '15px',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center'
                  }}
                >
                  <div style={{ display: 'flex', alignItems: 'center', gap: '12px', flex: 1 }}>
                    <div style={{
                      width: '40px',
                      height: '40px',
                      borderRadius: '50%',
                      backgroundColor: `${color}20`,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center'
                    }}>
                      <TIcon size={20} style={{ color }} />
                    </div>
                    <div>
                      <p style={{
                        margin: 0,
                        fontSize: '14px',
                        fontWeight: '600',
                        color: '#000',
                        textTransform: 'capitalize'
                      }}>
                        {transaction.type}
                      </p>
                      <p style={{
                        margin: '4px 0 0 0',
                        fontSize: '12px',
                        color: '#666'
                      }}>
                        {transaction.description || formatDate(transaction.created_at)}
                      </p>
                    </div>
                  </div>

                  <div style={{ textAlign: 'right', minWidth: '100px' }}>
                    <p style={{
                      margin: 0,
                      fontSize: '16px',
                      fontWeight: 'bold',
                      color: color
                    }}>
                      {transaction.type === 'credit' ? '+' : '-'}${parseFloat(transaction.amount).toFixed(2)}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>

          {transactions.total_pages > 1 && (
            <p style={{
              textAlign: 'center',
              fontSize: '12px',
              color: '#999',
              marginTop: '20px'
            }}>
              Showing {transactions.transactions.length} of {transactions.total_count} transactions
            </p>
          )}
        </div>
      )}

      <style>{`
        @keyframes spin {
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
};

export default RewardsTracker;
