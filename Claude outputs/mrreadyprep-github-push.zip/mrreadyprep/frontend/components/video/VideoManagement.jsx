// frontend/src/pages/VideoManagement.jsx
import React, { useState, useEffect } from 'react';
import VideoUploadForm from '../components/VideoUploadForm';
import VideoScheduler from '../components/VideoScheduler';
import VideoAnalyticsDashboard from '../components/VideoAnalyticsDashboard';
import ContentCalendar from '../components/ContentCalendar';
import VideoList from '../components/VideoList';

export default function VideoManagement() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [videos, setVideos] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [refresh, setRefresh] = useState(0);

  useEffect(() => {
    fetchVideos();
  }, [refresh]);

  const fetchVideos = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await fetch(`${process.env.REACT_APP_API_URL}/api/videos/list`);
      if (!response.ok) throw new Error('Video listesi yüklenemedi');
      const data = await response.json();
      setVideos(data.videos || []);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const styles = {
    container: {
      display: 'flex',
      height: '100vh',
      backgroundColor: '#fff',
    },
    sidebar: {
      width: '250px',
      background: 'linear-gradient(135deg, #1e3c72 0%, #2a5298 100%)',
      color: 'white',
      padding: '30px 20px',
      overflowY: 'auto',
      boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
    },
    logo: {
      fontSize: '18px',
      fontWeight: 'bold',
      marginBottom: '40px',
      display: 'flex',
      alignItems: 'center',
      gap: '10px',
    },
    navItem: {
      padding: '12px 15px',
      margin: '8px 0',
      borderRadius: '6px',
      cursor: 'pointer',
      transition: 'all 0.3s',
      fontSize: '14px',
      backgroundColor: 'rgba(255, 255, 255, 0)',
      border: 'none',
      color: 'inherit',
      width: '100%',
      textAlign: 'left',
    },
    navItemActive: {
      backgroundColor: 'rgba(255, 255, 255, 0.2)',
      borderLeft: '3px solid #4a9eff',
      paddingLeft: '12px',
    },
    mainContent: {
      flex: 1,
      display: 'flex',
      flexDirection: 'column',
      overflow: 'hidden',
    },
    header: {
      background: 'white',
      borderBottom: '1px solid #e0e0e0',
      padding: '20px 30px',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
    },
    headerTitle: {
      fontSize: '24px',
      fontWeight: '600',
      color: '#333',
    },
    content: {
      flex: 1,
      overflowY: 'auto',
      padding: '30px',
      backgroundColor: '#f5f5f5',
    },
    buttonPrimary: {
      background: '#4a9eff',
      color: 'white',
      border: 'none',
      padding: '10px 20px',
      borderRadius: '6px',
      cursor: 'pointer',
      fontSize: '14px',
      transition: 'all 0.3s',
      fontWeight: '600',
    },
    errorMessage: {
      background: '#fee',
      border: '1px solid #fcc',
      color: '#c33',
      padding: '15px',
      borderRadius: '6px',
      marginBottom: '20px',
    },
    loadingMessage: {
      textAlign: 'center',
      padding: '40px',
      color: '#999',
    },
  };

  return (
    <div style={styles.container}>
      {/* Sidebar */}
      <div style={styles.sidebar}>
        <div style={styles.logo}>🎥 MRReadyPrep</div>
        <button
          style={{
            ...styles.navItem,
            ...(activeTab === 'dashboard' ? styles.navItemActive : {}),
          }}
          onClick={() => setActiveTab('dashboard')}
        >
          📊 Dashboard
        </button>
        <button
          style={{
            ...styles.navItem,
            ...(activeTab === 'upload' ? styles.navItemActive : {}),
          }}
          onClick={() => setActiveTab('upload')}
        >
          📹 Video Yükle
        </button>
        <button
          style={{
            ...styles.navItem,
            ...(activeTab === 'calendar' ? styles.navItemActive : {}),
          }}
          onClick={() => setActiveTab('calendar')}
        >
          📅 Yayın Takvimi
        </button>
        <button
          style={{
            ...styles.navItem,
            ...(activeTab === 'analytics' ? styles.navItemActive : {}),
          }}
          onClick={() => setActiveTab('analytics')}
        >
          📈 Analytics
        </button>
        <button
          style={{
            ...styles.navItem,
            ...(activeTab === 'videos' ? styles.navItemActive : {}),
          }}
          onClick={() => setActiveTab('videos')}
        >
          🎬 Videolar
        </button>
      </div>

      {/* Main Content */}
      <div style={styles.mainContent}>
        <div style={styles.header}>
          <div style={styles.headerTitle}>
            {activeTab === 'dashboard' && 'Video İçerik Yönetimi'}
            {activeTab === 'upload' && 'Yeni Video Yükle'}
            {activeTab === 'calendar' && 'Yayın Takvimi'}
            {activeTab === 'analytics' && 'Video Analytics'}
            {activeTab === 'videos' && 'Tüm Videolar'}
          </div>
          {activeTab === 'dashboard' && (
            <button
              style={styles.buttonPrimary}
              onClick={() => setActiveTab('upload')}
              onMouseEnter={(e) => e.target.style.background = '#357abd'}
              onMouseLeave={(e) => e.target.style.background = '#4a9eff'}
            >
              + Yeni Video Yükle
            </button>
          )}
        </div>

        <div style={styles.content}>
          {error && <div style={styles.errorMessage}>⚠️ {error}</div>}

          {loading && <div style={styles.loadingMessage}>Yükleniyor...</div>}

          {!loading && (
            <>
              {activeTab === 'dashboard' && (
                <div
                  style={{
                    display: 'grid',
                    gridTemplateColumns: '1fr 1fr',
                    gap: '30px',
                  }}
                >
                  <VideoUploadForm onUploadSuccess={() => setRefresh(r => r + 1)} />
                  <VideoScheduler videos={videos} onScheduleSuccess={() => setRefresh(r => r + 1)} />
                  <VideoAnalyticsDashboard style={{ gridColumn: '1 / -1' }} />
                </div>
              )}

              {activeTab === 'upload' && (
                <div style={{ maxWidth: '600px', margin: '0 auto' }}>
                  <VideoUploadForm onUploadSuccess={() => setRefresh(r => r + 1)} />
                </div>
              )}

              {activeTab === 'calendar' && (
                <ContentCalendar videos={videos} onScheduleSuccess={() => setRefresh(r => r + 1)} />
              )}

              {activeTab === 'analytics' && (
                <VideoAnalyticsDashboard />
              )}

              {activeTab === 'videos' && (
                <VideoList videos={videos} onRefresh={() => setRefresh(r => r + 1)} />
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
