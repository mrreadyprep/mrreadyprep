// frontend/src/components/VideoAnalyticsDashboard.jsx
import React, { useState, useEffect } from 'react';

export default function VideoAnalyticsDashboard() {
  const [analytics, setAnalytics] = useState({
    channel: {
      name: '',
      subscriber_count: 0,
      video_count: 0,
      total_view_count: 0,
    },
    this_month: {
      total_views: 0,
      total_watch_time: 0,
      average_like_ratio: 0,
      total_videos: 0,
    },
  });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchAnalytics();
    const interval = setInterval(fetchAnalytics, 60000); // Her 1 dakika
    return () => clearInterval(interval);
  }, []);

  const fetchAnalytics = async () => {
    try {
      const response = await fetch(
        `${process.env.REACT_APP_API_URL}/api/videos/channel/analytics`
      );
      if (!response.ok) throw new Error('Analytics alınamadı');
      const data = await response.json();
      if (data.success) {
        setAnalytics(data);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const formatNumber = (num) => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
  };

  const styles = {
    card: {
      background: 'white',
      borderRadius: '10px',
      border: '1px solid #e0e0e0',
      padding: '25px',
      boxShadow: '0 2px 8px rgba(0, 0, 0, 0.05)',
    },
    cardTitle: {
      fontSize: '18px',
      fontWeight: '600',
      marginBottom: '25px',
      display: 'flex',
      alignItems: 'center',
      gap: '10px',
      color: '#333',
    },
    section: {
      marginBottom: '30px',
    },
    sectionTitle: {
      fontSize: '14px',
      fontWeight: '600',
      marginBottom: '15px',
      color: '#333',
      textTransform: 'uppercase',
      letterSpacing: '0.5px',
    },
    statsGrid: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))',
      gap: '15px',
      marginBottom: '20px',
    },
    statCard: {
      background: 'linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%)',
      padding: '20px',
      borderRadius: '8px',
      textAlign: 'center',
    },
    statLabel: {
      fontSize: '12px',
      color: '#666',
      marginBottom: '8px',
      textTransform: 'uppercase',
      letterSpacing: '0.5px',
    },
    statValue: {
      fontSize: '28px',
      fontWeight: 'bold',
      color: '#1e3c72',
    },
    statSubtext: {
      fontSize: '11px',
      color: '#999',
      marginTop: '6px',
    },
    errorMessage: {
      background: '#fee',
      border: '1px solid #fcc',
      color: '#c33',
      padding: '15px',
      borderRadius: '6px',
      marginBottom: '20px',
    },
    loadingMessage: {
      textAlign: 'center',
      padding: '40px',
      color: '#999',
    },
  };

  if (loading) {
    return (
      <div style={styles.card}>
        <div style={styles.cardTitle}>📊 YouTube Analytics</div>
        <div style={styles.loadingMessage}>Veriler yükleniyor...</div>
      </div>
    );
  }

  return (
    <div style={styles.card}>
      <div style={styles.cardTitle}>📊 YouTube Analytics</div>

      {error && <div style={styles.errorMessage}>⚠️ {error}</div>}

      {/* Channel Stats */}
      <div style={styles.section}>
        <div style={styles.sectionTitle}>Kanal İstatistikleri</div>
        <div style={styles.statsGrid}>
          <div style={styles.statCard}>
            <div style={styles.statLabel}>Abone</div>
            <div style={styles.statValue}>{formatNumber(analytics.channel.subscriber_count)}</div>
            <div style={styles.statSubtext}>Toplam abone</div>
          </div>
          <div style={styles.statCard}>
            <div style={styles.statLabel}>Video</div>
            <div style={styles.statValue}>{analytics.channel.video_count}</div>
            <div style={styles.statSubtext}>Toplam yayınlanan</div>
          </div>
          <div style={styles.statCard}>
            <div style={styles.statLabel}>İzleme</div>
            <div style={styles.statValue}>{formatNumber(analytics.channel.total_view_count)}</div>
            <div style={styles.statSubtext}>Tüm zamanların toplamı</div>
          </div>
        </div>
      </div>

      {/* This Month Stats */}
      <div style={styles.section}>
        <div style={styles.sectionTitle}>Bu Ayın Performansı</div>
        <div style={styles.statsGrid}>
          <div style={styles.statCard}>
            <div style={styles.statLabel}>İzleme</div>
            <div style={styles.statValue}>{formatNumber(analytics.this_month.total_views)}</div>
            <div style={styles.statSubtext}>Bu ayın toplamı</div>
          </div>
          <div style={styles.statCard}>
            <div style={styles.statLabel}>İzleme Saati</div>
            <div style={styles.statValue}>{formatNumber(analytics.this_month.total_watch_time)}</div>
            <div style={styles.statSubtext}>Saat cinsinden</div>
          </div>
          <div style={styles.statCard}>
            <div style={styles.statLabel}>Like Oranı</div>
            <div style={styles.statValue}>{analytics.this_month.average_like_ratio.toFixed(1)}%</div>
            <div style={styles.statSubtext}>Ortalama oran</div>
          </div>
          <div style={styles.statCard}>
            <div style={styles.statLabel}>Video</div>
            <div style={styles.statValue}>{analytics.this_month.total_videos}</div>
            <div style={styles.statSubtext}>Yayınlanan</div>
          </div>
        </div>
      </div>

      {/* Performance Insights */}
      <div style={styles.section}>
        <div style={styles.sectionTitle}>Performans İçgörüleri</div>
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            gap: '15px',
          }}
        >
          <div
            style={{
              background: '#f0f8ff',
              borderLeft: '4px solid #4a9eff',
              padding: '15px',
              borderRadius: '6px',
            }}
          >
            <div style={{ fontWeight: '600', color: '#1e3c72', marginBottom: '8px' }}>
              ✓ Başarı Göstergeleri
            </div>
            <ul style={{ fontSize: '13px', color: '#333', margin: '0', paddingLeft: '20px' }}>
              <li>Abone artışı devam etmektedir</li>
              <li>İzleme süresi istikrarlıdır</li>
              <li>Like oranı yeterli seviyededir</li>
            </ul>
          </div>
          <div
            style={{
              background: '#fff8e1',
              borderLeft: '4px solid #ffc107',
              padding: '15px',
              borderRadius: '6px',
            }}
          >
            <div style={{ fontWeight: '600', color: '#856404', marginBottom: '8px' }}>
              💡 Öneriler
            </div>
            <ul style={{ fontSize: '13px', color: '#333', margin: '0', paddingLeft: '20px' }}>
              <li>Daha fazla başlık varyasyonu deneyin</li>
              <li>Thumbnail tasarımını güzelleştirin</li>
              <li>Açıklamalarda CTA (Call-to-Action) ekleyin</li>
            </ul>
          </div>
        </div>
      </div>

      {/* Update Info */}
      <div style={{ marginTop: '25px', paddingTop: '15px', borderTop: '1px solid #e0e0e0' }}>
        <div style={{ fontSize: '12px', color: '#999', textAlign: 'center' }}>
          Son güncelleme: {new Date().toLocaleTimeString('tr-TR')} | Veriler otomatik olarak güncellenmektedir
        </div>
      </div>
    </div>
  );
}
