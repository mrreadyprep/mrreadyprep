// frontend/src/components/VideoScheduler.jsx
import React, { useState, useEffect } from 'react';

export default function VideoScheduler({ videos, onScheduleSuccess }) {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [scheduling, setScheduling] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [monthStats, setMonthStats] = useState({
    target_count: 4,
    published_count: 0,
    scheduled_count: 0,
  });

  useEffect(() => {
    fetchMonthStats();
  }, [currentDate]);

  const fetchMonthStats = async () => {
    try {
      const year = currentDate.getFullYear();
      const month = currentDate.getMonth() + 1;
      const response = await fetch(
        `${process.env.REACT_APP_API_URL}/api/videos/calendar/${year}/${month}`
      );
      const data = await response.json();
      if (data.success) {
        setMonthStats(data);
      }
    } catch (err) {
      console.error('Takvim verisi alınamadı:', err);
    }
  };

  const getDaysInMonth = (date) => {
    return new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  };

  const getFirstDayOfMonth = (date) => {
    return new Date(date.getFullYear(), date.getMonth(), 1).getDay();
  };

  const handlePreviousMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1));
  };

  const handleNextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1));
  };

  const handleDateClick = (day) => {
    const scheduled = new Date(
      currentDate.getFullYear(),
      currentDate.getMonth(),
      day,
      14,
      0,
      0
    );
    scheduleVideo(scheduled);
  };

  const scheduleVideo = async (publishDate) => {
    if (monthStats.published_count >= monthStats.target_count) {
      setError(`Bu ayın yayın kotası doldu (${monthStats.published_count}/${monthStats.target_count})`);
      return;
    }

    const unscheduledVideos = videos.filter(v => v.status === 'draft');
    if (unscheduledVideos.length === 0) {
      setError('Planlanacak video bulunmamaktadır');
      return;
    }

    setScheduling(true);
    setError(null);
    setSuccess(null);

    try {
      const response = await fetch(
        `${process.env.REACT_APP_API_URL}/api/videos/schedule`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            video_id: unscheduledVideos[0].id,
            publish_date: publishDate.toISOString(),
          }),
        }
      );

      const data = await response.json();
      if (!response.ok) throw new Error(data.detail || 'Planlama başarısız oldu');

      setSuccess(`Video ${publishDate.toLocaleDateString('tr-TR')} tarihine planlandı`);
      fetchMonthStats();
      if (onScheduleSuccess) onScheduleSuccess();
    } catch (err) {
      setError(err.message);
    } finally {
      setScheduling(false);
    }
  };

  const styles = {
    card: {
      background: 'white',
      borderRadius: '10px',
      border: '1px solid #e0e0e0',
      padding: '25px',
      boxShadow: '0 2px 8px rgba(0, 0, 0, 0.05)',
    },
    cardTitle: {
      fontSize: '18px',
      fontWeight: '600',
      marginBottom: '15px',
      display: 'flex',
      alignItems: 'center',
      gap: '10px',
      color: '#333',
    },
    scheduleInfo: {
      background: '#fff8e1',
      borderLeft: '4px solid #ffc107',
      padding: '12px',
      borderRadius: '4px',
      marginBottom: '15px',
      fontSize: '13px',
      color: '#856404',
    },
    monthHeader: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: '20px',
      padding: '15px',
      background: '#f0f8ff',
      borderRadius: '6px',
    },
    monthTitle: {
      fontSize: '16px',
      fontWeight: '600',
      color: '#1e3c72',
    },
    navButton: {
      background: '#4a9eff',
      color: 'white',
      border: 'none',
      padding: '8px 12px',
      borderRadius: '4px',
      cursor: 'pointer',
      fontSize: '12px',
      transition: 'all 0.3s',
    },
    calendarHeader: {
      display: 'grid',
      gridTemplateColumns: 'repeat(7, 1fr)',
      gap: '8px',
      marginBottom: '15px',
      fontWeight: '600',
      textAlign: 'center',
      fontSize: '12px',
      color: '#666',
    },
    calendarGrid: {
      display: 'grid',
      gridTemplateColumns: 'repeat(7, 1fr)',
      gap: '8px',
      marginBottom: '20px',
    },
    calendarDay: {
      aspectRatio: '1',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      borderRadius: '6px',
      background: '#f9f9f9',
      fontSize: '12px',
      border: '1px solid #e0e0e0',
      cursor: 'pointer',
      transition: 'all 0.3s',
      color: '#333',
    },
    calendarDayScheduled: {
      background: '#4a9eff',
      color: 'white',
      fontWeight: 'bold',
    },
    calendarDayHover: {
      background: '#e6f3ff',
      borderColor: '#4a9eff',
    },
    statsGrid: {
      display: 'grid',
      gridTemplateColumns: 'repeat(3, 1fr)',
      gap: '12px',
      marginBottom: '20px',
    },
    statCard: {
      background: 'linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%)',
      padding: '12px',
      borderRadius: '6px',
      textAlign: 'center',
    },
    statLabel: {
      fontSize: '11px',
      color: '#666',
      marginBottom: '6px',
    },
    statValue: {
      fontSize: '20px',
      fontWeight: 'bold',
      color: '#1e3c72',
    },
    errorMessage: {
      background: '#fee',
      border: '1px solid #fcc',
      color: '#c33',
      padding: '12px',
      borderRadius: '6px',
      marginBottom: '12px',
      fontSize: '12px',
    },
    successMessage: {
      background: '#efe',
      border: '1px solid #cfc',
      color: '#3c3',
      padding: '12px',
      borderRadius: '6px',
      marginBottom: '12px',
      fontSize: '12px',
    },
  };

  const daysInMonth = getDaysInMonth(currentDate);
  const firstDay = getFirstDayOfMonth(currentDate);
  const monthName = currentDate.toLocaleDateString('tr-TR', { month: 'long', year: 'numeric' });

  const calendarDays = [];
  for (let i = 0; i < firstDay; i++) {
    calendarDays.push(null);
  }
  for (let i = 1; i <= daysInMonth; i++) {
    calendarDays.push(i);
  }

  const scheduledDates = monthStats.scheduled_dates || [];
  const scheduledDays = scheduledDates.map(d => new Date(d.date).getDate());

  return (
    <div style={styles.card}>
      <div style={styles.cardTitle}>📅 Yayın Planı (4 video/ay)</div>

      {error && <div style={styles.errorMessage}>⚠️ {error}</div>}
      {success && <div style={styles.successMessage}>✓ {success}</div>}

      <div style={styles.scheduleInfo}>
        ✓ Bu ay {monthStats.published_count} video yayınlandı.
        {monthStats.published_count < monthStats.target_count && (
          ` Sonraki: ${monthStats.target_count - monthStats.published_count} video daha gerekli`
        )}
      </div>

      {/* Stats */}
      <div style={styles.statsGrid}>
        <div style={styles.statCard}>
          <div style={styles.statLabel}>Hedef</div>
          <div style={styles.statValue}>{monthStats.target_count}</div>
        </div>
        <div style={styles.statCard}>
          <div style={styles.statLabel}>Yayınlanan</div>
          <div style={styles.statValue}>{monthStats.published_count}</div>
        </div>
        <div style={styles.statCard}>
          <div style={styles.statLabel}>Planlanan</div>
          <div style={styles.statValue}>{monthStats.scheduled_count}</div>
        </div>
      </div>

      {/* Month Navigation */}
      <div style={styles.monthHeader}>
        <button
          style={styles.navButton}
          onClick={handlePreviousMonth}
          onMouseEnter={(e) => e.target.style.background = '#357abd'}
          onMouseLeave={(e) => e.target.style.background = '#4a9eff'}
        >
          ← Önceki
        </button>
        <div style={styles.monthTitle}>{monthName}</div>
        <button
          style={styles.navButton}
          onClick={handleNextMonth}
          onMouseEnter={(e) => e.target.style.background = '#357abd'}
          onMouseLeave={(e) => e.target.style.background = '#4a9eff'}
        >
          Sonraki →
        </button>
      </div>

      {/* Calendar Header */}
      <div style={styles.calendarHeader}>
        <div>Pzt</div>
        <div>Sal</div>
        <div>Çar</div>
        <div>Per</div>
        <div>Cum</div>
        <div>Cmt</div>
        <div>Paz</div>
      </div>

      {/* Calendar Grid */}
      <div style={styles.calendarGrid}>
        {calendarDays.map((day, index) => (
          <div
            key={index}
            style={{
              ...styles.calendarDay,
              ...(scheduledDays.includes(day) && styles.calendarDayScheduled),
              ...(day !== null && {
                cursor: 'pointer',
              }),
            }}
            onClick={() => day !== null && handleDateClick(day)}
            onMouseEnter={(e) => {
              if (day !== null && !scheduledDays.includes(day)) {
                e.target.style.background = '#e6f3ff';
                e.target.style.borderColor = '#4a9eff';
              }
            }}
            onMouseLeave={(e) => {
              if (day !== null && !scheduledDays.includes(day)) {
                e.target.style.background = '#f9f9f9';
                e.target.style.borderColor = '#e0e0e0';
              }
            }}
          >
            {day}
          </div>
        ))}
      </div>

      <div style={{ fontSize: '12px', color: '#666', textAlign: 'center' }}>
        Mavi: Planlanan yayın günleri | Tıklayarak yeni tarih seçebilirsiniz
      </div>
    </div>
  );
}
