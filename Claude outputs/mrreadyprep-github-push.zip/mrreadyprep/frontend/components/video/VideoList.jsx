// frontend/src/components/VideoList.jsx
import React, { useState } from 'react';

export default function VideoList({ videos, onRefresh }) {
  const [expandedId, setExpandedId] = useState(null);
  const [viewingAnalytics, setViewingAnalytics] = useState(null);
  const [analyticsData, setAnalyticsData] = useState(null);

  const getStatusColor = (status) => {
    switch (status) {
      case 'published':
        return '#4a9eff';
      case 'scheduled':
        return '#ffc107';
      case 'draft':
        return '#999';
      case 'archived':
        return '#ccc';
      default:
        return '#999';
    }
  };

  const getStatusLabel = (status) => {
    switch (status) {
      case 'published':
        return 'Yayında';
      case 'scheduled':
        return 'Planlanan';
      case 'draft':
        return 'Taslak';
      case 'archived':
        return 'Arşivlenmiş';
      default:
        return status;
    }
  };

  const fetchAnalytics = async (videoId) => {
    try {
      const response = await fetch(
        `${process.env.REACT_APP_API_URL}/api/videos/analytics/${videoId}`
      );
      const data = await response.json();
      if (data.success) {
        setAnalyticsData(data.analytics);
        setViewingAnalytics(videoId);
      }
    } catch (err) {
      console.error('Analytics alınamadı:', err);
    }
  };

  const handlePublish = async (videoId) => {
    if (!window.confirm('Video'yu hemen yayınlamak istediğinize emin misiniz?')) {
      return;
    }

    try {
      const response = await fetch(
        `${process.env.REACT_APP_API_URL}/api/videos/${videoId}/publish`,
        { method: 'POST' }
      );
      if (response.ok) {
        onRefresh();
      }
    } catch (err) {
      console.error('Yayın işlemi başarısız:', err);
    }
  };

  const styles = {
    container: {
      background: 'white',
      borderRadius: '10px',
      border: '1px solid #e0e0e0',
      boxShadow: '0 2px 8px rgba(0, 0, 0, 0.05)',
      overflow: 'hidden',
    },
    header: {
      padding: '25px',
      borderBottom: '1px solid #e0e0e0',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
    },
    title: {
      fontSize: '18px',
      fontWeight: '600',
      color: '#333',
      display: 'flex',
      alignItems: 'center',
      gap: '10px',
    },
    videoItem: {
      display: 'flex',
      gap: '15px',
      padding: '15px 25px',
      borderBottom: '1px solid #f0f0f0',
      alignItems: 'center',
      cursor: 'pointer',
      transition: 'background 0.3s',
    },
    thumbnail: {
      width: '80px',
      height: '60px',
      background: '#e0e0e0',
      borderRadius: '4px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: '#999',
      fontSize: '20px',
      flexShrink: 0,
    },
    videoInfo: {
      flex: 1,
    },
    videoTitle: {
      fontWeight: '600',
      color: '#333',
      marginBottom: '4px',
      fontSize: '14px',
    },
    videoMeta: {
      fontSize: '12px',
      color: '#666',
      display: 'flex',
      gap: '15px',
      marginBottom: '6px',
    },
    statusBadge: {
      display: 'inline-block',
      padding: '4px 10px',
      borderRadius: '3px',
      fontSize: '11px',
      fontWeight: '600',
      color: 'white',
      marginTop: '6px',
    },
    actions: {
      display: 'flex',
      gap: '8px',
    },
    button: {
      padding: '6px 12px',
      border: '1px solid #d0d0d0',
      background: 'white',
      borderRadius: '4px',
      cursor: 'pointer',
      fontSize: '12px',
      transition: 'all 0.3s',
      color: '#333',
    },
    details: {
      padding: '20px',
      background: '#f9f9f9',
      borderTop: '1px solid #e0e0e0',
    },
    analyticsGrid: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit, minmax(120px, 1fr))',
      gap: '12px',
      marginTop: '15px',
    },
    analyticsCard: {
      background: 'white',
      padding: '12px',
      borderRadius: '6px',
      textAlign: 'center',
      border: '1px solid #e0e0e0',
    },
    analyticsLabel: {
      fontSize: '11px',
      color: '#666',
      marginBottom: '6px',
    },
    analyticsValue: {
      fontSize: '18px',
      fontWeight: 'bold',
      color: '#1e3c72',
    },
  };

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <div style={styles.title}>🎬 Tüm Videolar ({videos.length})</div>
      </div>

      {videos.length === 0 ? (
        <div style={{ padding: '40px', textAlign: 'center', color: '#999' }}>
          Henüz video bulunmamaktadır
        </div>
      ) : (
        videos.map((video) => (
          <div key={video.id}>
            <div
              style={{
                ...styles.videoItem,
                background: expandedId === video.id ? '#f9f9f9' : 'white',
              }}
              onClick={() => setExpandedId(expandedId === video.id ? null : video.id)}
              onMouseEnter={(e) => e.currentTarget.style.background = '#f9f9f9'}
              onMouseLeave={(e) => e.currentTarget.style.background = expandedId === video.id ? '#f9f9f9' : 'white'}
            >
              <div style={styles.thumbnail}>🎥</div>

              <div style={styles.videoInfo}>
                <div style={styles.videoTitle}>{video.title}</div>
                <div style={styles.videoMeta}>
                  <span>Oluşturulma: {new Date(video.created_at).toLocaleDateString('tr-TR')}</span>
                  {video.actual_publish_date && (
                    <span>Yayın: {new Date(video.actual_publish_date).toLocaleDateString('tr-TR')}</span>
                  )}
                  {video.scheduled_publish_date && (
                    <span>Planlanan: {new Date(video.scheduled_publish_date).toLocaleDateString('tr-TR')}</span>
                  )}
                </div>
                <div style={styles.videoMeta}>
                  <span>{video.view_count.toLocaleString('tr-TR')} izleme</span>
                  {video.like_count > 0 && <span>{video.like_count} beğenme</span>}
                  {video.comment_count > 0 && <span>{video.comment_count} yorum</span>}
                </div>
                <span
                  style={{
                    ...styles.statusBadge,
                    backgroundColor: getStatusColor(video.status),
                  }}
                >
                  {getStatusLabel(video.status)}
                </span>
              </div>

              <div style={styles.actions}>
                <button
                  style={styles.button}
                  onClick={(e) => {
                    e.stopPropagation();
                    fetchAnalytics(video.id);
                  }}
                  onMouseEnter={(e) => e.target.style.background = '#f0f8ff'}
                  onMouseLeave={(e) => e.target.style.background = 'white'}
                >
                  📊 Analytics
                </button>
                {video.status === 'draft' && (
                  <button
                    style={styles.button}
                    onClick={(e) => {
                      e.stopPropagation();
                      handlePublish(video.id);
                    }}
                    onMouseEnter={(e) => e.target.style.background = '#e6f3ff'}
                    onMouseLeave={(e) => e.target.style.background = 'white'}
                  >
                    ▶️ Yayınla
                  </button>
                )}
              </div>
            </div>

            {expandedId === video.id && (
              <div style={styles.details}>
                <div style={{ marginBottom: '15px' }}>
                  <p style={{ margin: '0 0 8px 0', fontSize: '12px', fontWeight: '600', color: '#333' }}>
                    Açıklama:
                  </p>
                  <p
                    style={{
                      margin: '0',
                      fontSize: '13px',
                      color: '#666',
                      lineHeight: '1.5',
                    }}
                  >
                    {video.description}
                  </p>
                </div>

                {video.tags && (
                  <div style={{ marginBottom: '15px' }}>
                    <p style={{ margin: '0 0 8px 0', fontSize: '12px', fontWeight: '600', color: '#333' }}>
                      Etiketler:
                    </p>
                    <div style={{ display: 'flex', gap: '8px', flexWrap: 'wrap' }}>
                      {video.tags.split(',').map((tag, i) => (
                        <span
                          key={i}
                          style={{
                            background: '#f0f8ff',
                            color: '#4a9eff',
                            padding: '4px 10px',
                            borderRadius: '3px',
                            fontSize: '12px',
                          }}
                        >
                          {tag.trim()}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {viewingAnalytics === video.id && analyticsData && (
                  <div>
                    <p style={{ margin: '0 0 12px 0', fontSize: '12px', fontWeight: '600', color: '#333' }}>
                      Analytics:
                    </p>
                    <div style={styles.analyticsGrid}>
                      <div style={styles.analyticsCard}>
                        <div style={styles.analyticsLabel}>İzleme</div>
                        <div style={styles.analyticsValue}>{analyticsData.view_count.toLocaleString('tr-TR')}</div>
                      </div>
                      <div style={styles.analyticsCard}>
                        <div style={styles.analyticsLabel}>Beğenme</div>
                        <div style={styles.analyticsValue}>{analyticsData.like_count.toLocaleString('tr-TR')}</div>
                      </div>
                      <div style={styles.analyticsCard}>
                        <div style={styles.analyticsLabel}>Yorum</div>
                        <div style={styles.analyticsValue}>{analyticsData.comment_count.toLocaleString('tr-TR')}</div>
                      </div>
                      <div style={styles.analyticsCard}>
                        <div style={styles.analyticsLabel}>Like Oranı</div>
                        <div style={styles.analyticsValue}>{(analyticsData.like_ratio || 0).toFixed(1)}%</div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>
        ))
      )}
    </div>
  );
}
