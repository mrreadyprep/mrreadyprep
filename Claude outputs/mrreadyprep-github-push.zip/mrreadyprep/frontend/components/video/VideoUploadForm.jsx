// frontend/src/components/VideoUploadForm.jsx
import React, { useState } from 'react';

export default function VideoUploadForm({ onUploadSuccess }) {
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    tags: '',
    scheduled_date: '',
  });
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [dragActive, setDragActive] = useState(false);

  const styles = {
    card: {
      background: 'white',
      borderRadius: '10px',
      border: '1px solid #e0e0e0',
      padding: '25px',
      boxShadow: '0 2px 8px rgba(0, 0, 0, 0.05)',
    },
    cardTitle: {
      fontSize: '18px',
      fontWeight: '600',
      marginBottom: '20px',
      display: 'flex',
      alignItems: 'center',
      gap: '10px',
      color: '#333',
    },
    uploadZone: {
      border: '2px dashed #4a9eff',
      borderRadius: '8px',
      padding: '40px 20px',
      textAlign: 'center',
      background: dragActive ? '#e6f3ff' : '#f0f8ff',
      cursor: 'pointer',
      transition: 'all 0.3s',
      marginBottom: '20px',
    },
    uploadIcon: {
      fontSize: '40px',
      marginBottom: '10px',
    },
    uploadText: {
      color: '#666',
      fontSize: '14px',
    },
    formGroup: {
      marginBottom: '20px',
    },
    formLabel: {
      display: 'block',
      fontSize: '13px',
      fontWeight: '600',
      marginBottom: '8px',
      color: '#333',
    },
    formInput: {
      width: '100%',
      padding: '10px',
      border: '1px solid #d0d0d0',
      borderRadius: '6px',
      fontSize: '14px',
      fontFamily: 'inherit',
      transition: 'all 0.3s',
      boxSizing: 'border-box',
    },
    formInputFocus: {
      borderColor: '#4a9eff',
      boxShadow: '0 0 0 3px rgba(74, 158, 255, 0.1)',
      outline: 'none',
    },
    buttonPrimary: {
      width: '100%',
      background: '#4a9eff',
      color: 'white',
      border: 'none',
      padding: '12px',
      borderRadius: '6px',
      cursor: 'pointer',
      fontSize: '14px',
      fontWeight: '600',
      transition: 'all 0.3s',
    },
    errorMessage: {
      background: '#fee',
      border: '1px solid #fcc',
      color: '#c33',
      padding: '12px',
      borderRadius: '6px',
      marginBottom: '15px',
      fontSize: '13px',
    },
    successMessage: {
      background: '#efe',
      border: '1px solid #cfc',
      color: '#3c3',
      padding: '12px',
      borderRadius: '6px',
      marginBottom: '15px',
      fontSize: '13px',
    },
    fileName: {
      fontSize: '13px',
      color: '#666',
      marginTop: '8px',
    },
  };

  const handleDragEnter = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    const files = e.dataTransfer.files;
    if (files.length > 0) {
      const videoFile = files[0];
      if (videoFile.type.startsWith('video/')) {
        setFile(videoFile);
        setError(null);
      } else {
        setError('Lütfen bir video dosyası seçiniz');
      }
    }
  };

  const handleFileChange = (e) => {
    const videoFile = e.target.files[0];
    if (videoFile) {
      if (videoFile.type.startsWith('video/')) {
        setFile(videoFile);
        setError(null);
      } else {
        setError('Lütfen bir video dosyası seçiniz');
      }
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!file) {
      setError('Lütfen bir video dosyası seçiniz');
      return;
    }

    if (!formData.title || !formData.description || !formData.tags) {
      setError('Lütfen tüm alanları doldurunuz');
      return;
    }

    setUploading(true);
    setError(null);
    setSuccess(null);

    try {
      const uploadFormData = new FormData();
      uploadFormData.append('file', file);
      uploadFormData.append('title', formData.title);
      uploadFormData.append('description', formData.description);
      uploadFormData.append('tags', formData.tags);
      if (formData.scheduled_date) {
        uploadFormData.append('scheduled_date', formData.scheduled_date);
      }

      const response = await fetch(`${process.env.REACT_APP_API_URL}/api/videos/upload`, {
        method: 'POST',
        body: uploadFormData,
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.detail || 'Upload başarısız oldu');
      }

      setSuccess(`Video "${formData.title}" başarıyla yüklendi!`);
      setFormData({ title: '', description: '', tags: '', scheduled_date: '' });
      setFile(null);

      if (onUploadSuccess) {
        onUploadSuccess();
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setUploading(false);
    }
  };

  return (
    <div style={styles.card}>
      <div style={styles.cardTitle}>📹 Video Yükle</div>

      {error && <div style={styles.errorMessage}>⚠️ {error}</div>}
      {success && <div style={styles.successMessage}>✓ {success}</div>}

      <form onSubmit={handleSubmit}>
        {/* Upload Zone */}
        <div
          style={styles.uploadZone}
          onDragEnter={handleDragEnter}
          onDragLeave={handleDragLeave}
          onDragOver={handleDragOver}
          onDrop={handleDrop}
          onClick={() => document.getElementById('file-input').click()}
        >
          <div style={styles.uploadIcon}>📂</div>
          <div style={styles.uploadText}>
            Video dosyasını buraya sürükleyin<br />
            veya tıklayarak seçin
          </div>
          {file && <div style={styles.fileName}>Seçili: {file.name}</div>}
        </div>

        <input
          id="file-input"
          type="file"
          accept="video/*"
          onChange={handleFileChange}
          style={{ display: 'none' }}
        />

        {/* Title */}
        <div style={styles.formGroup}>
          <label style={styles.formLabel}>Video Başlığı</label>
          <input
            type="text"
            name="title"
            value={formData.title}
            onChange={handleInputChange}
            placeholder="TOEFL Reading Tips - Part 1"
            style={styles.formInput}
            maxLength="100"
          />
        </div>

        {/* Description */}
        <div style={styles.formGroup}>
          <label style={styles.formLabel}>Açıklama</label>
          <textarea
            name="description"
            value={formData.description}
            onChange={handleInputChange}
            placeholder="Video hakkında detaylı açıklama..."
            style={{
              ...styles.formInput,
              minHeight: '100px',
              resize: 'vertical',
            }}
            maxLength="5000"
          />
        </div>

        {/* Tags */}
        <div style={styles.formGroup}>
          <label style={styles.formLabel}>Etiketler (virgülle ayrılı)</label>
          <input
            type="text"
            name="tags"
            value={formData.tags}
            onChange={handleInputChange}
            placeholder="toefl, reading, study-tips"
            style={styles.formInput}
          />
        </div>

        {/* Scheduled Date */}
        <div style={styles.formGroup}>
          <label style={styles.formLabel}>Planlanan Yayın Tarihi (isteğe bağlı)</label>
          <input
            type="datetime-local"
            name="scheduled_date"
            value={formData.scheduled_date}
            onChange={handleInputChange}
            style={styles.formInput}
          />
        </div>

        {/* Submit Button */}
        <button
          type="submit"
          style={styles.buttonPrimary}
          disabled={uploading}
          onMouseEnter={(e) => !uploading && (e.target.style.background = '#357abd')}
          onMouseLeave={(e) => !uploading && (e.target.style.background = '#4a9eff')}
        >
          {uploading ? '⏳ Yükleniyor...' : 'Yükle ve Planla'}
        </button>
      </form>
    </div>
  );
}
