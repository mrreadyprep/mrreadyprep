// frontend/src/components/ContentCalendar.jsx
import React, { useState } from 'react';

export default function ContentCalendar({ videos, onScheduleSuccess }) {
  const [selectedMonth, setSelectedMonth] = useState(new Date());

  const styles = {
    container: {
      background: 'white',
      borderRadius: '10px',
      border: '1px solid #e0e0e0',
      boxShadow: '0 2px 8px rgba(0, 0, 0, 0.05)',
      padding: '25px',
    },
    header: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: '25px',
    },
    title: {
      fontSize: '18px',
      fontWeight: '600',
      color: '#333',
      display: 'flex',
      alignItems: 'center',
      gap: '10px',
    },
    monthNav: {
      display: 'flex',
      gap: '10px',
      alignItems: 'center',
    },
    navButton: {
      background: '#4a9eff',
      color: 'white',
      border: 'none',
      padding: '8px 12px',
      borderRadius: '4px',
      cursor: 'pointer',
      fontSize: '12px',
      transition: 'all 0.3s',
    },
    monthDisplay: {
      fontSize: '14px',
      fontWeight: '600',
      color: '#333',
      minWidth: '120px',
      textAlign: 'center',
    },
    calendarGrid: {
      display: 'grid',
      gridTemplateColumns: 'repeat(7, 1fr)',
      gap: '1px',
      background: '#e0e0e0',
      padding: '1px',
      borderRadius: '6px',
      overflow: 'hidden',
    },
    dayHeader: {
      background: '#f0f8ff',
      padding: '12px 8px',
      fontWeight: '600',
      color: '#1e3c72',
      fontSize: '12px',
      textAlign: 'center',
      border: 'none',
    },
    dayCell: {
      background: 'white',
      padding: '12px 8px',
      minHeight: '80px',
      fontSize: '12px',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'flex-start',
      position: 'relative',
    },
    dayNumber: {
      fontWeight: '600',
      color: '#333',
      marginBottom: '4px',
    },
    videoTag: {
      fontSize: '10px',
      background: '#4a9eff',
      color: 'white',
      padding: '2px 4px',
      borderRadius: '2px',
      marginBottom: '2px',
      whiteSpace: 'nowrap',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      maxWidth: '100%',
    },
    legend: {
      display: 'flex',
      gap: '20px',
      marginTop: '20px',
      paddingTop: '20px',
      borderTop: '1px solid #e0e0e0',
      fontSize: '13px',
      color: '#666',
    },
    legendItem: {
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
    },
    legendColor: {
      width: '12px',
      height: '12px',
      borderRadius: '2px',
    },
  };

  const getDaysInMonth = (date) => {
    return new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate();
  };

  const getFirstDayOfMonth = (date) => {
    return new Date(date.getFullYear(), date.getMonth(), 1).getDay();
  };

  const handlePrevMonth = () => {
    setSelectedMonth(new Date(selectedMonth.getFullYear(), selectedMonth.getMonth() - 1));
  };

  const handleNextMonth = () => {
    setSelectedMonth(new Date(selectedMonth.getFullYear(), selectedMonth.getMonth() + 1));
  };

  const getVideosForDay = (day) => {
    return videos.filter(v => {
      if (!v.scheduled_publish_date && !v.actual_publish_date) return false;
      const date = new Date(v.scheduled_publish_date || v.actual_publish_date);
      return (
        date.getDate() === day &&
        date.getMonth() === selectedMonth.getMonth() &&
        date.getFullYear() === selectedMonth.getFullYear()
      );
    });
  };

  const monthName = selectedMonth.toLocaleDateString('tr-TR', {
    month: 'long',
    year: 'numeric',
  });

  const daysInMonth = getDaysInMonth(selectedMonth);
  const firstDay = getFirstDayOfMonth(selectedMonth);

  const dayHeaders = ['Pzt', 'Sal', 'Çar', 'Per', 'Cum', 'Cmt', 'Paz'];
  const calendarDays = [];

  for (let i = 0; i < firstDay; i++) {
    calendarDays.push(null);
  }
  for (let i = 1; i <= daysInMonth; i++) {
    calendarDays.push(i);
  }

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <div style={styles.title}>📅 İçerik Takvimi</div>
        <div style={styles.monthNav}>
          <button
            style={styles.navButton}
            onClick={handlePrevMonth}
            onMouseEnter={(e) => e.target.style.background = '#357abd'}
            onMouseLeave={(e) => e.target.style.background = '#4a9eff'}
          >
            ← Önceki
          </button>
          <div style={styles.monthDisplay}>{monthName}</div>
          <button
            style={styles.navButton}
            onClick={handleNextMonth}
            onMouseEnter={(e) => e.target.style.background = '#357abd'}
            onMouseLeave={(e) => e.target.style.background = '#4a9eff'}
          >
            Sonraki →
          </button>
        </div>
      </div>

      <div style={styles.calendarGrid}>
        {dayHeaders.map((header) => (
          <div key={`header-${header}`} style={styles.dayHeader}>
            {header}
          </div>
        ))}

        {calendarDays.map((day, index) => (
          <div key={index} style={styles.dayCell}>
            {day && (
              <>
                <div style={styles.dayNumber}>{day}</div>
                {getVideosForDay(day).map((video, i) => (
                  <div
                    key={i}
                    style={styles.videoTag}
                    title={video.title}
                  >
                    🎥 {video.title.substring(0, 8)}...
                  </div>
                ))}
              </>
            )}
          </div>
        ))}
      </div>

      <div style={styles.legend}>
        <div style={styles.legendItem}>
          <div style={{ ...styles.legendColor, background: '#4a9eff' }}></div>
          <span>Planlanan / Yayınlanan Video</span>
        </div>
        <div style={styles.legendItem}>
          <span>Hedef: 4 video/ay (haftalık 1 video)</span>
        </div>
      </div>

      {videos.length === 0 && (
        <div
          style={{
            marginTop: '30px',
            padding: '40px',
            textAlign: 'center',
            background: '#f9f9f9',
            borderRadius: '6px',
            color: '#999',
          }}
        >
          Henüz planlanan video bulunmamaktadır
        </div>
      )}
    </div>
  );
}
