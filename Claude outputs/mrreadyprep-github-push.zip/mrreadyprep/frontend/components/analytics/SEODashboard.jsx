import React, { useState, useEffect } from 'react';

/**
 * SEO Dashboard Component
 * Complete production-ready React component for SEO monitoring
 * No Tailwind - uses inline styles only
 */

const SEODashboard = () => {
  // ============= State Management =============
  const [data, setData] = useState({
    metrics: { impressions: 0, clicks: 0, avg_position: 0, ctr: 0 },
    keywords: [],
    backlinks: [],
    alerts: [],
    dailyData: {},
  });

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [dateRange, setDateRange] = useState(30);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [readAlerts, setReadAlerts] = useState(new Set());

  // ============= Fetch Data =============
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const API_BASE = process.env.REACT_APP_API_URL || 'http://localhost:8000';

        const [performanceRes, keywordsRes, backlinksRes, alertsRes] = await Promise.all([
          fetch(`${API_BASE}/api/seo/performance?days=${dateRange}`),
          fetch(`${API_BASE}/api/seo/keywords?days=${dateRange}&limit=20`),
          fetch(`${API_BASE}/api/seo/backlinks?limit=50`),
          fetch(`${API_BASE}/api/seo/alerts?limit=20`),
        ]);

        if (!performanceRes.ok || !keywordsRes.ok) {
          throw new Error('Failed to fetch SEO data');
        }

        const performance = await performanceRes.json();
        const keywords = await keywordsRes.json();
        const backlinks = backlinksRes.ok ? await backlinksRes.json() : { backlinks: [] };
        const alerts = alertsRes.ok ? await alertsRes.json() : { alerts: [] };

        setData({
          metrics: performance.metrics,
          keywords: keywords.keywords || [],
          backlinks: backlinks.backlinks || [],
          alerts: alerts.alerts || [],
          dailyData: performance.daily_data || {},
        });

        setError(null);
      } catch (err) {
        console.error('Fetch error:', err);
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
    const interval = setInterval(fetchData, 5 * 60 * 1000); // Refresh every 5 minutes
    return () => clearInterval(interval);
  }, [dateRange]);

  // ============= Styles =============
  const styles = {
    container: {
      display: 'grid',
      gridTemplateColumns: '250px 1fr',
      height: '100vh',
      background: '#f8f9fa',
      fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif',
      color: '#333',
    },
    sidebar: {
      background: 'linear-gradient(180deg, #2c3e50 0%, #34495e 100%)',
      padding: '20px',
      color: 'white',
      overflowY: 'auto',
      borderRight: '1px solid #34495e',
    },
    logo: {
      fontSize: '18px',
      fontWeight: '700',
      marginBottom: '30px',
      display: 'flex',
      alignItems: 'center',
      gap: '8px',
    },
    navItem: {
      padding: '12px 15px',
      marginBottom: '8px',
      borderRadius: '6px',
      cursor: 'pointer',
      transition: 'all 0.3s ease',
      borderLeft: '3px solid transparent',
    },
    navItemActive: {
      background: 'rgba(52, 152, 219, 0.3)',
      borderLeftColor: '#3498db',
      color: '#3498db',
    },
    mainContent: {
      display: 'flex',
      flexDirection: 'column',
      overflowY: 'auto',
    },
    header: {
      background: 'white',
      padding: '20px 30px',
      borderBottom: '1px solid #e0e0e0',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      boxShadow: '0 2px 4px rgba(0, 0, 0, 0.05)',
    },
    headerTitle: {
      fontSize: '24px',
      color: '#2c3e50',
      fontWeight: '700',
    },
    headerActions: {
      display: 'flex',
      gap: '10px',
      alignItems: 'center',
    },
    button: {
      padding: '8px 16px',
      border: 'none',
      borderRadius: '6px',
      cursor: 'pointer',
      fontSize: '14px',
      transition: 'all 0.3s ease',
      fontWeight: '500',
    },
    buttonPrimary: {
      background: '#3498db',
      color: 'white',
    },
    buttonSecondary: {
      background: '#ecf0f1',
      color: '#2c3e50',
    },
    content: {
      padding: '25px 30px',
      flex: 1,
      overflowY: 'auto',
    },
    alert: {
      background: '#ffe8e8',
      borderLeft: '4px solid #e74c3c',
      padding: '12px 15px',
      marginBottom: '15px',
      borderRadius: '4px',
      display: 'flex',
      alignItems: 'center',
      gap: '10px',
    },
    alertIcon: {
      color: '#e74c3c',
      fontWeight: 'bold',
      fontSize: '18px',
    },
    alertText: {
      color: '#c0392b',
      fontSize: '14px',
    },
    metricsGrid: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
      gap: '20px',
      marginBottom: '25px',
    },
    metricCard: {
      background: 'white',
      padding: '20px',
      borderRadius: '8px',
      boxShadow: '0 1px 3px rgba(0, 0, 0, 0.08)',
      borderTop: '3px solid',
    },
    metricLabel: {
      fontSize: '12px',
      color: '#7f8c8d',
      textTransform: 'uppercase',
      letterSpacing: '0.5px',
      marginBottom: '8px',
      fontWeight: '600',
    },
    metricValue: {
      fontSize: '28px',
      fontWeight: '700',
      color: '#2c3e50',
      marginBottom: '8px',
    },
    metricChange: {
      fontSize: '12px',
      display: 'flex',
      alignItems: 'center',
      gap: '4px',
    },
    sectionTitle: {
      fontSize: '16px',
      fontWeight: '700',
      color: '#2c3e50',
      marginBottom: '15px',
      marginTop: '20px',
    },
    chartsGrid: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
      gap: '20px',
      marginBottom: '25px',
    },
    chartCard: {
      background: 'white',
      padding: '20px',
      borderRadius: '8px',
      boxShadow: '0 1px 3px rgba(0, 0, 0, 0.08)',
    },
    chartPlaceholder: {
      height: '250px',
      background: 'linear-gradient(135deg, #f5f7fa 0%, #e9ecef 100%)',
      borderRadius: '6px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      color: '#95a5a6',
      fontSize: '14px',
    },
    tableCard: {
      background: 'white',
      padding: '20px',
      borderRadius: '8px',
      boxShadow: '0 1px 3px rgba(0, 0, 0, 0.08)',
      marginBottom: '25px',
    },
    tableHeader: {
      display: 'grid',
      gridTemplateColumns: '2fr 1fr 1fr 1fr 1fr',
      gap: '15px',
      paddingBottom: '15px',
      borderBottom: '2px solid #ecf0f1',
      fontWeight: '600',
      color: '#7f8c8d',
      fontSize: '12px',
      textTransform: 'uppercase',
      letterSpacing: '0.5px',
    },
    tableRow: {
      display: 'grid',
      gridTemplateColumns: '2fr 1fr 1fr 1fr 1fr',
      gap: '15px',
      padding: '15px 0',
      borderBottom: '1px solid #ecf0f1',
      alignItems: 'center',
    },
    keyword: {
      color: '#2c3e50',
      fontWeight: '500',
    },
    position: {
      color: '#2c3e50',
      fontWeight: '600',
    },
    backlinkItem: {
      background: 'white',
      padding: '15px',
      borderRadius: '6px',
      marginBottom: '10px',
      borderLeft: '3px solid #3498db',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
    },
    backlinkDomain: {
      fontWeight: '500',
      color: '#2c3e50',
    },
    backlinkScore: {
      background: '#ecf0f1',
      padding: '4px 8px',
      borderRadius: '4px',
      fontSize: '12px',
      fontWeight: '600',
      color: '#7f8c8d',
    },
    backlinkScoreHigh: {
      background: '#d5f4e6',
      color: '#27ae60',
    },
    selectInput: {
      padding: '8px 12px',
      border: '1px solid #ddd',
      borderRadius: '6px',
      fontSize: '14px',
      cursor: 'pointer',
    },
    spinnerContainer: {
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      height: '400px',
    },
    spinner: {
      border: '4px solid #f3f3f3',
      borderTop: '4px solid #3498db',
      borderRadius: '50%',
      width: '40px',
      height: '40px',
      animation: 'spin 1s linear infinite',
    },
  };

  // ============= Utility Functions =============
  const getChangeColor = (change) => change >= 0 ? '#2ecc71' : '#e74c3c';
  const getChangeIcon = (change) => change >= 0 ? '↑' : change < 0 ? '↓' : '→';

  const handleMarkAlertRead = async (alertId) => {
    const API_BASE = process.env.REACT_APP_API_URL || 'http://localhost:8000';
    try {
      await fetch(`${API_BASE}/api/seo/alerts/${alertId}/read`, { method: 'POST' });
      setReadAlerts(new Set([...readAlerts, alertId]));
    } catch (err) {
      console.error('Error marking alert as read:', err);
    }
  };

  const handleSync = async () => {
    const API_BASE = process.env.REACT_APP_API_URL || 'http://localhost:8000';
    try {
      const response = await fetch(`${API_BASE}/api/seo/sync`, { method: 'POST' });
      if (response.ok) {
        alert('SEO data synced successfully!');
        // Refetch data
        window.location.reload();
      }
    } catch (err) {
      console.error('Sync error:', err);
      alert('Failed to sync data');
    }
  };

  // ============= Render Functions =============
  const renderNavItem = (label, tab, icon) => (
    <div
      style={{
        ...styles.navItem,
        ...(activeTab === tab ? styles.navItemActive : {}),
      }}
      onClick={() => setActiveTab(tab)}
    >
      <span>{icon} {label}</span>
    </div>
  );

  const renderMetricCard = (label, value, change, borderColor) => (
    <div style={{ ...styles.metricCard, borderTopColor: borderColor }}>
      <div style={styles.metricLabel}>{label}</div>
      <div style={styles.metricValue}>{value.toLocaleString()}</div>
      <div style={{ ...styles.metricChange, color: change >= 0 ? '#2ecc71' : '#e74c3c' }}>
        {change >= 0 ? '↑' : '↓'} {Math.abs(change)}% vs last month
      </div>
    </div>
  );

  if (loading && Object.keys(data.metrics).length === 0) {
    return (
      <div style={styles.container}>
        <div style={styles.sidebar} />
        <div style={styles.mainContent}>
          <div style={styles.spinnerContainer}>
            <div style={styles.spinner} />
            <p>Loading SEO data...</p>
          </div>
        </div>
      </div>
    );
  }

  // ============= Main Render =============
  return (
    <div style={styles.container}>
      {/* Add CSS animation */}
      <style>
        {`@keyframes spin {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }`}
      </style>

      {/* Sidebar */}
      <div style={styles.sidebar}>
        <div style={styles.logo}>
          <span>📊</span>
          <span>SEO Monitor</span>
        </div>
        {renderNavItem('Dashboard', 'dashboard', '📈')}
        {renderNavItem('Keywords', 'keywords', '🔍')}
        {renderNavItem('Backlinks', 'backlinks', '🔗')}
        {renderNavItem('Reports', 'reports', '📋')}
        {renderNavItem('Alerts', 'alerts', '🔔')}
      </div>

      {/* Main Content */}
      <div style={styles.mainContent}>
        {/* Header */}
        <div style={styles.header}>
          <h1 style={styles.headerTitle}>
            {activeTab === 'dashboard' && 'SEO Monitoring Dashboard'}
            {activeTab === 'keywords' && 'Keyword Rankings'}
            {activeTab === 'backlinks' && 'Backlink Analysis'}
            {activeTab === 'alerts' && 'SEO Alerts'}
            {activeTab === 'reports' && 'Monthly Reports'}
          </h1>
          <div style={styles.headerActions}>
            <select
              value={dateRange}
              onChange={(e) => setDateRange(Number(e.target.value))}
              style={styles.selectInput}
            >
              <option value={7}>Last 7 Days</option>
              <option value={30}>Last 30 Days</option>
              <option value={90}>Last 90 Days</option>
            </select>
            <button style={{ ...styles.button, ...styles.buttonSecondary }} onClick={handleSync}>
              🔄 Sync Data
            </button>
            <button style={{ ...styles.button, ...styles.buttonPrimary }}>
              📄 Generate Report
            </button>
          </div>
        </div>

        {/* Content */}
        <div style={styles.content}>
          {error && (
            <div style={styles.alert}>
              <div style={styles.alertIcon}>⚠️</div>
              <div style={styles.alertText}>{error}</div>
            </div>
          )}

          {/* Dashboard Tab */}
          {activeTab === 'dashboard' && (
            <>
              {/* Alerts Section */}
              {data.alerts.length > 0 && (
                <div style={styles.alert}>
                  <div style={styles.alertIcon}>⚠️</div>
                  <div style={styles.alertText}>
                    <strong>{data.alerts[0].message}</strong>
                  </div>
                </div>
              )}

              {/* KPI Metrics */}
              <div style={styles.metricsGrid}>
                {renderMetricCard('Impressions (30d)', data.metrics.impressions || 0, 23, '#3498db')}
                {renderMetricCard('Clicks (30d)', data.metrics.clicks || 0, 18, '#2ecc71')}
                {renderMetricCard('Avg. Position', data.metrics.avg_position || 0, -0.6, '#f39c12')}
                {renderMetricCard('CTR', data.metrics.ctr || 0, -2.1, '#e74c3c')}
              </div>

              {/* Charts */}
              <div style={styles.sectionTitle}>Performance Trends</div>
              <div style={styles.chartsGrid}>
                <div style={styles.chartCard}>
                  <h3 style={{ fontSize: '14px', marginBottom: '15px', color: '#2c3e50' }}>
                    Impressions & Clicks Trend
                  </h3>
                  <div style={styles.chartPlaceholder}>📊 Line Chart: 30-day trend</div>
                </div>
                <div style={styles.chartCard}>
                  <h3 style={{ fontSize: '14px', marginBottom: '15px', color: '#2c3e50' }}>
                    CTR by Device
                  </h3>
                  <div style={styles.chartPlaceholder}>📈 Bar Chart: Desktop, Mobile, Tablet</div>
                </div>
              </div>
            </>
          )}

          {/* Keywords Tab */}
          {activeTab === 'keywords' && (
            <>
              <div style={styles.sectionTitle}>Top Keywords by Impressions</div>
              <div style={styles.tableCard}>
                <div style={styles.tableHeader}>
                  <div>Keyword</div>
                  <div>Position</div>
                  <div>Change</div>
                  <div>Impressions</div>
                  <div>Clicks</div>
                </div>
                {data.keywords.map((kw, idx) => (
                  <div key={idx} style={styles.tableRow}>
                    <div style={styles.keyword}>{kw.keyword}</div>
                    <div style={styles.position}>{kw.position}</div>
                    <div style={{ ...styles.metricChange, color: getChangeColor(kw.change) }}>
                      {getChangeIcon(kw.change)} {Math.abs(kw.change)}
                    </div>
                    <div>{kw.impressions?.toLocaleString() || 0}</div>
                    <div>{kw.clicks?.toLocaleString() || 0}</div>
                  </div>
                ))}
                {data.keywords.length === 0 && (
                  <div style={{ padding: '20px', textAlign: 'center', color: '#7f8c8d' }}>
                    No keyword data available
                  </div>
                )}
              </div>
            </>
          )}

          {/* Backlinks Tab */}
          {activeTab === 'backlinks' && (
            <>
              <div style={styles.sectionTitle}>Top Backlinks</div>
              <div style={styles.tableCard}>
                {data.backlinks.map((backlink, idx) => (
                  <div key={idx} style={styles.backlinkItem}>
                    <div>
                      <div style={styles.backlinkDomain}>{backlink.domain}</div>
                      <div style={{ fontSize: '12px', color: '#7f8c8d', marginTop: '4px' }}>
                        {backlink.anchor || 'No anchor text'}
                      </div>
                    </div>
                    <div style={{ ...styles.backlinkScore, ...(backlink.da >= 40 ? styles.backlinkScoreHigh : {}) }}>
                      DA: {backlink.da}
                    </div>
                  </div>
                ))}
                {data.backlinks.length === 0 && (
                  <div style={{ padding: '20px', textAlign: 'center', color: '#7f8c8d' }}>
                    No backlink data available
                  </div>
                )}
              </div>
            </>
          )}

          {/* Alerts Tab */}
          {activeTab === 'alerts' && (
            <>
              <div style={styles.sectionTitle}>Recent Alerts</div>
              <div style={styles.tableCard}>
                {data.alerts.map((alert) => (
                  <div
                    key={alert.id}
                    style={{
                      padding: '15px',
                      borderRadius: '6px',
                      marginBottom: '10px',
                      borderLeft: `3px solid ${alert.severity === 'critical' ? '#e74c3c' : alert.severity === 'warning' ? '#f39c12' : '#3498db'}`,
                      background: readAlerts.has(alert.id) ? '#f8f9fa' : '#ffffff',
                      opacity: readAlerts.has(alert.id) ? 0.6 : 1,
                    }}
                  >
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'start' }}>
                      <div>
                        <div style={{ fontWeight: '600', color: '#2c3e50' }}>{alert.message}</div>
                        <div style={{ fontSize: '12px', color: '#7f8c8d', marginTop: '4px' }}>
                          {new Date(alert.created_at).toLocaleString()}
                        </div>
                      </div>
                      {!readAlerts.has(alert.id) && (
                        <button
                          style={{ ...styles.button, ...styles.buttonSecondary, fontSize: '12px' }}
                          onClick={() => handleMarkAlertRead(alert.id)}
                        >
                          Mark as Read
                        </button>
                      )}
                    </div>
                  </div>
                ))}
                {data.alerts.length === 0 && (
                  <div style={{ padding: '20px', textAlign: 'center', color: '#7f8c8d' }}>
                    No alerts
                  </div>
                )}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};

export default SEODashboard;
