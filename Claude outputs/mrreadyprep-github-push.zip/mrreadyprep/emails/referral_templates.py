"""
Email Templates for Referral Program
Generate HTML emails using Resend or SendGrid
"""

from datetime import datetime
from typing import Optional


class ReferralEmailTemplates:
    """Referral program email templates"""

    BRAND_COLOR = "#701fa1"
    ACCENT_COLOR = "#10b981"
    BASE_URL = "https://mrreadyprep.com"

    @staticmethod
    def referral_invitation(
        referrer_name: str,
        referred_email: str,
        referral_code: str,
        discount_percent: int = 50
    ) -> dict:
        """
        Email sent to referred friend
        """
        referral_link = f"{ReferralEmailTemplates.BASE_URL}?ref={referral_code}"

        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style>
                body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; line-height: 1.6; color: #333; }}
                .container {{ max-width: 600px; margin: 0 auto; background-color: #fff; }}
                .header {{ background: linear-gradient(135deg, {ReferralEmailTemplates.BRAND_COLOR} 0%, #9333ea 100%); color: white; padding: 30px 20px; text-align: center; }}
                .header h1 {{ margin: 0; font-size: 28px; font-weight: bold; }}
                .content {{ padding: 30px 20px; }}
                .offer-box {{ background-color: #f0fdf4; border: 2px solid {ReferralEmailTemplates.ACCENT_COLOR}; border-radius: 8px; padding: 25px; text-align: center; margin: 25px 0; }}
                .offer-box h2 {{ color: {ReferralEmailTemplates.ACCENT_COLOR}; font-size: 32px; margin: 10px 0; }}
                .offer-box p {{ color: #666; margin: 10px 0; font-size: 14px; }}
                .button {{ display: inline-block; background: linear-gradient(135deg, {ReferralEmailTemplates.BRAND_COLOR} 0%, #9333ea 100%); color: white; padding: 15px 40px; border-radius: 8px; text-decoration: none; font-weight: bold; margin: 20px 0; font-size: 16px; }}
                .code-box {{ background-color: #f9fafb; border: 1px solid #e5e7eb; border-radius: 6px; padding: 15px; margin: 20px 0; text-align: center; }}
                .code-box code {{ font-family: monospace; font-size: 18px; font-weight: bold; color: {ReferralEmailTemplates.BRAND_COLOR}; }}
                .features {{ margin: 30px 0; }}
                .feature {{ background-color: #f9fafb; padding: 15px; margin: 10px 0; border-radius: 6px; border-left: 4px solid {ReferralEmailTemplates.BRAND_COLOR}; }}
                .feature h3 {{ margin: 0 0 5px 0; color: {ReferralEmailTemplates.BRAND_COLOR}; font-size: 14px; }}
                .feature p {{ margin: 0; color: #666; font-size: 13px; }}
                .footer {{ background-color: #f9fafb; border-top: 1px solid #e5e7eb; padding: 20px; text-align: center; font-size: 12px; color: #999; }}
                .footer a {{ color: {ReferralEmailTemplates.BRAND_COLOR}; text-decoration: none; }}
                .referrer {{ background-color: #f0fdf4; padding: 15px; border-radius: 6px; margin: 20px 0; }}
                .referrer p {{ margin: 5px 0; color: #666; font-size: 14px; }}
            </style>
        </head>
        <body>
            <div class="container">
                <!-- Header -->
                <div class="header">
                    <h1>Your Friend Invited You!</h1>
                    <p style="margin: 10px 0 0 0; opacity: 0.9; font-size: 16px;">Get 50% OFF TOEFL Prep</p>
                </div>

                <!-- Content -->
                <div class="content">
                    <p>Hi there!</p>
                    <p><strong>{referrer_name}</strong> thinks you'd love <strong>MRReadyPrep</strong> for TOEFL iBT preparation and wants to help you save big!</p>

                    <!-- Offer Box -->
                    <div class="offer-box">
                        <p style="color: #666; font-size: 13px; margin: 0 0 10px 0;">EXCLUSIVE REFERRAL OFFER</p>
                        <h2>{discount_percent}% OFF</h2>
                        <p>Your First Month of Premium</p>
                        <p style="color: #999; font-size: 12px; margin: 10px 0 0 0;">Limited time offer • New users only</p>
                    </div>

                    <!-- Features -->
                    <div class="features">
                        <h3 style="color: {ReferralEmailTemplates.BRAND_COLOR}; margin: 0 0 15px 0;">What You Get with Premium:</h3>

                        <div class="feature">
                            <h3>📖 Full Reading Practice</h3>
                            <p>3 reading task types with 100+ passages and questions</p>
                        </div>

                        <div class="feature">
                            <h3>🎧 Complete Listening Module</h3>
                            <p>4 authentic listening scenarios with transcript support</p>
                        </div>

                        <div class="feature">
                            <h3>✍️ Writing & Speaking Feedback</h3>
                            <p>AI-powered instant feedback on all responses</p>
                        </div>

                        <div class="feature">
                            <h3>📊 Progress Tracking</h3>
                            <p>Detailed analytics, score history, and improvement insights</p>
                        </div>

                        <div class="feature">
                            <h3>🧠 900+ Vocabulary Words</h3>
                            <p>Organized by difficulty with interactive learning</p>
                        </div>

                        <div class="feature">
                            <h3>✨ 20 Full Mock Tests</h3>
                            <p>Complete practice exams with scoring & analysis</p>
                        </div>
                    </div>

                    <!-- Referrer Info -->
                    <div class="referrer">
                        <p style="color: #666; font-size: 13px; font-weight: 600; margin: 0 0 8px 0;">Referred by {referrer_name}</p>
                        <p style="font-size: 12px; color: #999;">They're already earning rewards through our referral program!</p>
                    </div>

                    <!-- Referral Code -->
                    <p style="text-align: center; color: #666; font-size: 14px; margin: 20px 0 10px 0;">Use referral code at checkout:</p>
                    <div class="code-box">
                        <code>{referral_code}</code>
                    </div>

                    <!-- CTA Button -->
                    <div style="text-align: center;">
                        <a href="{referral_link}" class="button">Start Your TOEFL Prep</a>
                    </div>

                    <!-- Info -->
                    <div style="background-color: #f0f9ff; border: 1px solid #bfdbfe; border-radius: 6px; padding: 15px; margin: 25px 0;">
                        <p style="margin: 0; font-size: 13px; color: #333;"><strong>How it works:</strong></p>
                        <ol style="margin: 10px 0 0 0; padding-left: 20px; color: #666; font-size: 13px;">
                            <li>Sign up with the referral code</li>
                            <li>You get 50% off your first month</li>
                            <li>{referrer_name} earns $5 in credit</li>
                        </ol>
                    </div>

                    <!-- Questions -->
                    <p style="color: #999; font-size: 13px; margin: 20px 0;">
                        Have questions? Check our <a href="{ReferralEmailTemplates.BASE_URL}/faq" style="color: {ReferralEmailTemplates.BRAND_COLOR}; text-decoration: none;">FAQ</a> or <a href="mailto:support@mrreadyprep.com" style="color: {ReferralEmailTemplates.BRAND_COLOR}; text-decoration: none;">contact support</a>.
                    </p>
                </div>

                <!-- Footer -->
                <div class="footer">
                    <p style="margin: 10px 0;">© 2026 MRReadyPrep. All rights reserved.</p>
                    <p style="margin: 5px 0; font-size: 11px;">You received this because {referred_email} was invited to join MRReadyPrep.</p>
                    <p style="margin: 5px 0;">
                        <a href="{ReferralEmailTemplates.BASE_URL}/terms" style="color: {ReferralEmailTemplates.BRAND_COLOR};">Terms</a> •
                        <a href="{ReferralEmailTemplates.BASE_URL}/privacy" style="color: {ReferralEmailTemplates.BRAND_COLOR};">Privacy</a>
                    </p>
                </div>
            </div>
        </body>
        </html>
        """

        return {
            "to": referred_email,
            "subject": f"{referrer_name} Invited You to MRReadyPrep - 50% Off TOEFL Prep",
            "html": html
        }


    @staticmethod
    def referral_success(
        referrer_name: str,
        referred_name: str,
        referred_email: str,
        reward_amount: float = 5.0
    ) -> dict:
        """
        Email sent to referrer when someone signs up using their link
        """
        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <style>
                body {{ font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; line-height: 1.6; color: #333; }}
                .container {{ max-width: 600px; margin: 0 auto; background-color: #fff; }}
                .header {{ background: linear-gradient(135deg, {ReferralEmailTemplates.BRAND_COLOR} 0%, #9333ea 100%); color: white; padding: 30px 20px; text-align: center; }}
                .header h1 {{ margin: 0; font-size: 28px; font-weight: bold; }}
                .content {{ padding: 30px 20px; }}
                .success-box {{ background-color: #f0fdf4; border: 2px solid {ReferralEmailTemplates.ACCENT_COLOR}; border-radius: 8px; padding: 25px; text-align: center; margin: 25px 0; }}
                .success-box h2 {{ color: {ReferralEmailTemplates.ACCENT_COLOR}; font-size: 28px; margin: 10px 0; }}
                .success-box p {{ color: #666; margin: 10px 0; font-size: 14px; }}
                .reward {{ font-size: 32px; font-weight: bold; color: {ReferralEmailTemplates.ACCENT_COLOR}; margin: 15px 0; }}
                .user-info {{ background-color: #f9fafb; border: 1px solid #e5e7eb; border-radius: 6px; padding: 15px; margin: 20px 0; }}
                .user-info p {{ margin: 5px 0; color: #666; font-size: 14px; }}
                .button {{ display: inline-block; background: linear-gradient(135deg, {ReferralEmailTemplates.BRAND_COLOR} 0%, #9333ea 100%); color: white; padding: 15px 40px; border-radius: 8px; text-decoration: none; font-weight: bold; margin: 20px 0; font-size: 16px; }}
                .footer {{ background-color: #f9fafb; border-top: 1px solid #e5e7eb; padding: 20px; text-align: center; font-size: 12px; color: #999; }}
                .footer a {{ color: {ReferralEmailTemplates.BRAND_COLOR}; text-decoration: none; }}
            </style>
        </head>
        <body>
            <div class="container">
                <!-- Header -->
                <div class="header">
                    <h1>🎉 Referral Successful!</h1>
                </div>

                <!-- Content -->
                <div class="content">
                    <p>Hi {referrer_name}!</p>
                    <p>Great news! Your referral just signed up and you've earned your reward.</p>

                    <!-- Success Box -->
                    <div class="success-box">
                        <p style="color: #666; font-size: 13px; margin: 0 0 10px 0; text-transform: uppercase; letter-spacing: 1px;">REWARD CREDITED</p>
                        <div class="reward">${reward_amount:.2f}</div>
                        <p style="color: #999; font-size: 12px; margin: 10px 0 0 0;">Added to your account</p>
                    </div>

                    <!-- User Info -->
                    <div class="user-info">
                        <p style="color: #999; font-size: 12px; margin: 0 0 8px 0;">Referred User</p>
                        <p style="font-size: 16px; font-weight: bold; margin: 0 0 5px 0;">{referred_name}</p>
                        <p style="font-size: 13px; color: #999; margin: 0;">{referred_email}</p>
                    </div>

                    <!-- Balance Info -->
                    <div style="background-color: #f0fdf4; border: 1px solid #86efac; border-radius: 6px; padding: 15px; margin: 20px 0;">
                        <p style="margin: 0 0 10px 0; color: #666; font-size: 13px; font-weight: 600;">Your Referral Balance</p>
                        <p style="margin: 0; font-size: 14px; color: #666;">
                            You can withdraw or use your credits toward your subscription at any time.
                        </p>
                    </div>

                    <!-- CTA -->
                    <div style="text-align: center;">
                        <a href="{ReferralEmailTemplates.BASE_URL}/dashboard/referrals" class="button">View Your Dashboard</a>
                    </div>

                    <!-- Stats -->
                    <div style="background-color: #f9fafb; border-radius: 6px; padding: 15px; margin: 25px 0; text-align: center;">
                        <p style="margin: 0; color: #666; font-size: 13px;">
                            <strong>Keep sharing!</strong> Earn ${reward_amount:.2f} for every friend who signs up.
                        </p>
                    </div>

                    <!-- Next Steps -->
                    <p style="color: #666; font-size: 14px; margin: 20px 0;">
                        Ready to earn more? Share your referral link on social media, or invite friends via email. Every signup gets you closer to bigger rewards!
                    </p>
                </div>

                <!-- Footer -->
                <div class="footer">
                    <p style="margin: 10px 0;">© 2026 MRReadyPrep. All rights reserved.</p>
                    <p style="margin: 5px 0;">
                        <a href="{ReferralEmailTemplates.BASE_URL}/terms" style="color: {ReferralEmailTemplates.BRAND_COLOR};">Terms</a> •
                        <a href="{ReferralEmailTemplates.BASE_URL}/privacy" style="color: {ReferralEmailTemplates.BRAND_COLOR};">Privacy</a>
                    </p>
                </div>
            </div>
        </body>
        </html>
        """

        return {
            "to": referrer_name,  # Get from user object - use email
            "subject": f"You earned ${reward_amount:.2f}! Referral from {referred_name}",
            "html": html
        }


def send_referral_invitation(
    referrer: dict,
    referred_email: str,
    referral_code: str
) -> bool:
    """
    Send referral invitation email via Resend

    Args:
        referrer: User object with name, email
        referred_email: Email to send invitation to
        referral_code: Unique referral code

    Returns:
        True if successful
    """
    import httpx
    import os

    resend_api_key = os.getenv("RESEND_API_KEY")
    if not resend_api_key:
        print("Error: RESEND_API_KEY not configured")
        return False

    template_data = ReferralEmailTemplates.referral_invitation(
        referrer_name=referrer.get("name", "Your Friend"),
        referred_email=referred_email,
        referral_code=referral_code,
        discount_percent=50
    )

    try:
        client = httpx.Client()
        response = client.post(
            "https://api.resend.com/emails",
            headers={
                "Authorization": f"Bearer {resend_api_key}",
                "Content-Type": "application/json"
            },
            json={
                "from": "referrals@mrreadyprep.com",
                "to": template_data["to"],
                "subject": template_data["subject"],
                "html": template_data["html"]
            }
        )

        return response.status_code == 200
    except Exception as e:
        print(f"Error sending referral email: {str(e)}")
        return False


def send_referral_success_email(
    referrer_email: str,
    referred_name: str,
    referred_email: str,
    reward_amount: float = 5.0
) -> bool:
    """
    Send success email to referrer
    """
    import httpx
    import os

    resend_api_key = os.getenv("RESEND_API_KEY")
    if not resend_api_key:
        print("Error: RESEND_API_KEY not configured")
        return False

    template_data = ReferralEmailTemplates.referral_success(
        referrer_name=referrer_email.split('@')[0],  # Use email prefix as name fallback
        referred_name=referred_name,
        referred_email=referred_email,
        reward_amount=reward_amount
    )

    try:
        client = httpx.Client()
        response = client.post(
            "https://api.resend.com/emails",
            headers={
                "Authorization": f"Bearer {resend_api_key}",
                "Content-Type": "application/json"
            },
            json={
                "from": "referrals@mrreadyprep.com",
                "to": referrer_email,
                "subject": template_data["subject"],
                "html": template_data["html"]
            }
        )

        return response.status_code == 200
    except Exception as e:
        print(f"Error sending referral success email: {str(e)}")
        return False
